// Dashboard + vehicle center
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Bell, MapPin, Activity, Zap, Wrench } from "lucide-react";
import { type FleetDB, statusLabel, statusColor, readiness, openFaults, batteriesNeeding, shiftCoverage, currentShiftName, useNow, fmtTime } from "./store";
import { Glass, Kpi, ChargeRing, StatusDot, ShuttleArt, LevelBar } from "./ui";

export function Dashboard({ db, go }: { db: FleetDB; go: (t: string, id?: string) => void }) {
  const now = useNow();
  const me = db.users.find((u) => u.id === db.currentUser);
  const r = readiness(db);
  const open = openFaults(db);
  const need = batteriesNeeding(db);
  const today = new Date().toISOString().slice(0, 10);
  const cov = shiftCoverage(db, today);
  const ready = db.vehicles.filter((v) => v.status === "ready").length;
  const working = db.vehicles.filter((v) => v.status === "working").length;
  const stopped = db.vehicles.filter((v) => v.status === "stopped").length;
  const maint = db.vehicles.filter((v) => v.status === "maintenance").length;

  const chartData = db.vehicles.map((v) => ({
    name: v.number, hours: v.hours + db.shifts.flatMap((s) => s.ops).filter((o) => o.vehicleId === v.id).length * 8,
    faults: db.faults.filter((f) => f.vehicleId === v.id && f.status !== "closed").length,
  }));
  const pie = [
    { name: "جاهزة", value: ready, color: "#22c55e" },
    { name: "عاملة", value: working, color: "#38bdf8" },
    { name: "متوقفة", value: stopped, color: "#f59e0b" },
    { name: "صيانة", value: maint, color: "#f43f5e" },
  ];

  return (
    <div className="space-y-4">
      {/* control header */}
      <Glass className="p-4 overflow-hidden relative">
        <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(400px 140px at 85% 0%, rgba(56,189,248,0.25), transparent)" }} />
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="text-[12px] text-sky-300 font-bold">SHUTTLE FLEET • CONTROL CENTER</div>
            <h1 className="text-xl font-extrabold mt-0.5">مركز قيادة الشاتل كار</h1>
            <div className="text-[12px] opacity-70 mt-1 tabular-nums">
              {now.toLocaleDateString("ar-EG", { weekday: "long", day: "numeric", month: "long" })} • {now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
            </div>
            <div className="flex flex-wrap gap-2 mt-2 text-[12px]">
              <span className="rounded-full bg-white/10 px-3 py-1">المستخدم: {me?.name} — {me?.role}</span>
              <span className="rounded-full bg-sky-500/20 border border-sky-400/30 px-3 py-1 text-sky-200">الوردية الحالية: {currentShiftName(now)}</span>
              <span className="rounded-full px-3 py-1 border" style={{ borderColor: r >= 70 ? "#22c55e66" : "#f59e0b66", color: r >= 70 ? "#86efac" : "#fcd34d" }}>
                حالة النظام: {r >= 70 ? "مستقر" : r >= 40 ? "يحتاج متابعة" : "حرج"}
              </span>
            </div>
          </div>
          <button onClick={() => go("alerts")} className="relative rounded-2xl border border-white/10 bg-white/10 p-3">
            <Bell className="size-5" />
            {open.length + need.length > 0 && <span className="absolute -top-1 -left-1 min-w-6 h-6 px-1 rounded-full bg-rose-500 text-[12px] font-bold grid place-items-center">{open.length + need.length}</span>}
          </button>
        </div>
        <div className="mt-3">
          <div className="flex justify-between text-[12px] mb-1"><span>جاهزية الأسطول</span><b className="tabular-nums">{r}%</b></div>
          <LevelBar pct={r} color={r >= 70 ? "#22c55e" : r >= 40 ? "#f59e0b" : "#f43f5e"} />
        </div>
      </Glass>

      {/* KPIs */}
      <div className="grid grid-cols-3 gap-2.5">
        <Kpi label="إجمالي العربات" value={db.vehicles.length} sub="5 مسجلة" onClick={() => go("fleet")} />
        <Kpi label="تحت التجربة" value={db.vehicles.filter((x) => x.trial && !x.archived).length} color="#a78bfa" onClick={() => go("fleet")} />
        <Kpi label="غير المتصلة" value={db.vehicles.filter((x) => !x.archived && (db.links.find((l) => l.vehicleId === x.id)?.status ?? "disconnected") !== "connected").length} color="#64748b" onClick={() => go("connect")} />
        <Kpi label="الجاهزة" value={ready} color="#22c55e" onClick={() => go("fleet")} />
        <Kpi label="العاملة" value={working} color="#38bdf8" onClick={() => go("fleet")} />
        <Kpi label="المتوقفة" value={stopped} color="#f59e0b" onClick={() => go("fleet")} />
        <Kpi label="تحت الصيانة" value={maint} color="#f43f5e" onClick={() => go("faults")} />
        <Kpi label="أعطال مفتوحة" value={open.length} color={open.length ? "#f43f5e" : "#22c55e"} onClick={() => go("faults")} />
        <Kpi label="بطاريات تحتاج تدخل" value={need.length} sub={`الحد ${db.settings?.swapThreshold ?? 50}%`} color={need.length ? "#f59e0b" : "#22c55e"} onClick={() => go("batteries")} />
        <Kpi label="تسجيل الورديات" value={`${cov.count}/3`} sub={`${cov.pct}% اليوم`} color={cov.count >= 3 ? "#22c55e" : "#f59e0b"} onClick={() => go("shifts")} />
        <Kpi label="ورديات غير مكتمل" value={db.shifts.filter((s) => !s.handoverDone).length} color="#f59e0b" onClick={() => go("shifts")} />
        <Kpi label="جاهزية الأسطول" value={`${r}%`} color={r >= 70 ? "#22c55e" : "#f59e0b"} onClick={() => go("analytics")} />
      </div>

      {/* charts */}
      <Glass className="p-4">
        <div className="font-bold text-[14px] mb-1">توزيع حالة الأسطول — اضغط للانتقال للتفاصيل</div>
        <div className="text-[12px] opacity-60 mb-2">رسم تفاعلي لحالة العربات الآن</div>
        <div className="h-44" dir="ltr">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={pie} dataKey="value" innerRadius={52} outerRadius={72} paddingAngle={3} onClick={(_, i) => go("fleet")}>
                {pie.map((p) => <Cell key={p.name} fill={p.color} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex flex-wrap gap-2 text-[12px]">
          {pie.map((p) => <span key={p.name} className="rounded-full bg-white/10 px-2.5 py-1"><i className="inline-block size-2 rounded-full ml-1" style={{ background: p.color }} />{p.name}: {p.value}</span>)}
        </div>
      </Glass>

      <Glass className="p-4">
        <div className="font-bold text-[14px]">ساعات التشغيل والأعطال لكل عربة</div>
        <div className="text-[12px] opacity-60 mb-2">اضغط على أي عمود لفتح مركز العربة</div>
        <div className="h-48" dir="ltr">
          <ResponsiveContainer>
            <BarChart data={chartData} onClick={(e: any) => { const n = e?.activeLabel; const v = db.vehicles.find((x) => x.number === n); if (v) go("vehicle", v.id); }}>
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="hours" fill="#38bdf8" radius={[8, 8, 0, 0]} name="ساعات مسجلة" />
              <Bar dataKey="faults" fill="#f43f5e" radius={[8, 8, 0, 0]} name="أعطال مفتوحة" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Glass>

      {/* fleet cards */}
      <div className="flex items-center justify-between">
        <h2 className="font-extrabold">الأسطول — بطاقات تفاعلية</h2>
        <button onClick={() => go("fleet")} className="text-[12px] text-sky-300">عرض الكل</button>
      </div>
      <div className="grid gap-3">
        {db.vehicles.map((v) => {
          const b = db.batteries.find((x) => x.id === v.batteryId);
          return (
            <Glass key={v.id} onClick={() => go("vehicle", v.id)} glow={statusColor[v.status]} className="p-3">
              <ShuttleArt maker={v.maker} status={v.status} />
              <div className="flex items-center justify-between mt-3 gap-2">
                <div>
                  <div className="font-extrabold">{v.number} <span className="font-normal opacity-60 text-[12px]">• {v.maker} • {v.model}</span></div>
                  <div className="text-[12px] opacity-70 flex items-center gap-1 mt-0.5"><MapPin className="size-3.5" />{v.location}</div>
                </div>
                <span className="rounded-full px-3 py-1 text-[12px] font-bold border whitespace-nowrap" style={{ color: statusColor[v.status], borderColor: statusColor[v.status] + "66", background: statusColor[v.status] + "14" }}>
                  <StatusDot status={v.status} /> {statusLabel[v.status]}
                </span>
              </div>
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center gap-2 text-[12px]">
                  <Zap className="size-4 text-amber-300" />
                  {b ? <span>بطارية {b.code} • {b.charge}%</span> : <span className="text-rose-300">بدون بطارية مركبة</span>}
                </div>
                <span className="text-[12px] opacity-60">آخر تحديث: {fmtTime(v.lastUpdate)}</span>
              </div>
              {b && <div className="mt-2"><LevelBar pct={b.charge} color={b.charge > (db.settings?.swapThreshold ?? 50) ? "#22c55e" : b.charge > (db.settings?.lowAlert ?? 30) ? "#f59e0b" : "#f43f5e"} /></div>}
            </Glass>
          );
        })}
      </div>

      <Glass className="p-4">
        <div className="font-bold text-[14px] flex items-center gap-2"><Activity className="size-4" /> أحدث النشاطات</div>
        <div className="mt-2 space-y-1.5 text-[12px]">
          {db.activity.slice(0, 5).map((a) => (
            <div key={a.id} className="flex justify-between gap-2 border-b border-white/5 pb-1.5">
              <span>{a.user} — {a.action}</span><span className="opacity-50 whitespace-nowrap">{fmtTime(a.time)}</span>
            </div>
          ))}
        </div>
        <button onClick={() => go("admin")} className="mt-2 text-[12px] text-sky-300 flex items-center gap-1"><Wrench className="size-3.5" /> سجل التعديلات الكامل والإدارة</button>
      </Glass>
    </div>
  );
}

export function VehicleCenter({ db, id, go, update }: { db: FleetDB; id: string; go: (t: string, v?: string) => void; update: any }) {
  const v = db.vehicles.find((x) => x.id === id) ?? db.vehicles[0];
  const [tab, setTab] = useState("ops");
  if (!v) return null;
  const b = db.batteries.find((x) => x.id === v.batteryId);
  const faults = db.faults.filter((f) => f.vehicleId === v.id);
  const shifts = db.shifts.filter((s) => s.ops.some((o) => o.vehicleId === v.id));
  const maints = db.maints.filter((m) => m.vehicleId === v.id);
  const events: { t: string; txt: string }[] = [
    ...shifts.map((s) => ({ t: s.date + " " + s.start, txt: `وردية ${s.type} — المشغل ${s.ops.find((o) => o.vehicleId === v.id)?.operator ?? ""} — ${s.ops.find((o) => o.vehicleId === v.id)?.room ?? ""}` })),
    ...faults.map((f) => ({ t: f.createdAt.slice(0, 10), txt: `عطل: ${f.type} — ${f.desc} (${f.status})` })),
    ...maints.map((m) => ({ t: m.doneDate || m.dueDate, txt: `${m.kind} — ${m.status === "done" ? "منفذة" : "مجدولة"}` })),
  ].sort((a, b2) => (a.t < b2.t ? 1 : -1));

  const setStatus = (s: any) => update((d: FleetDB) => { d.vehicles.find((x) => x.id === v.id)!.status = s; d.vehicles.find((x) => x.id === v.id)!.lastUpdate = new Date().toISOString(); return d; }, `تغيير حالة ${v.number} إلى ${statusLabel[s]}`);

  return (
    <div className="space-y-3">
      <button onClick={() => go("home")} className="text-[13px] opacity-70">→ رجوع للقيادة</button>
      <Glass glow={statusColor[v.status]} className="p-4">
        <ShuttleArt maker={v.maker} status={v.status} />
        <h1 className="text-xl font-extrabold mt-3">{v.number} — {v.maker}</h1>
        <div className="text-[13px] opacity-70">{v.model} • {v.location}</div>
        <div className="flex items-center gap-3 mt-3">
          {b ? <ChargeRing pct={b.charge} /> : <span className="text-rose-300 text-[13px]">بدون بطارية</span>}
          <div className="text-[13px] space-y-1">
            <div>الحالة: <b style={{ color: statusColor[v.status] }}>{statusLabel[v.status]}</b></div>
            <div>البطارية: {b ? `${b.code} — صحتها ${b.health === "excellent" ? "ممتازة" : b.health === "good" ? "جيدة" : b.health === "fair" ? "متوسطة" : b.health === "poor" ? "ضعيفة" : "عطل"}` : "—"}</div>
            <div>ساعات مسجلة: <b className="tabular-nums">{v.hours + shifts.length * 8}</b> • الأعطال: {faults.filter((f) => f.status !== "closed").length} مفتوحة</div>
          <div className="opacity-80">التسلسلي: {v.serialNo || "—"} • التشغيل: {v.operationDate || "—"}{v.trial ? " • تحت التجربة" : ""}</div>
          <div className="opacity-80">الملحقات: {(v.accessoryIds ?? []).map((a) => db.accessories.find((x) => x.id === a)?.name).filter(Boolean).join("، ") || "—"}</div>
          <button onClick={() => go("connect")} className="text-[12px] text-sky-300 font-bold">فتح إعدادات الاتصال لهذه العربة ←</button>
          </div>
        </div>
        <div className="grid grid-cols-4 gap-2 mt-3">
          {(["ready", "working", "stopped", "maintenance"] as const).map((s) => (
            <button key={s} onClick={() => setStatus(s)} className={`rounded-2xl border px-2 py-2 text-[12px] font-bold ${v.status === s ? "text-white" : "opacity-70"}`}
              style={v.status === s ? { background: statusColor[s] + "33", borderColor: statusColor[s] } : { borderColor: "rgba(255,255,255,0.12)" }}>{statusLabel[s]}</button>
          ))}
        </div>
      </Glass>

      <div className="grid grid-cols-5 gap-2 text-center text-[12px]">
        {[["ops", "التشغيل"], ["faults", "الأعطال"], ["maint", "الصيانة"], ["link", "اللاسلكي"], ["time", "الزمني"]].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`rounded-2xl py-2.5 border font-bold ${tab === k ? "bg-sky-500/25 border-sky-400/50 text-sky-100" : "bg-white/5 border-white/10 opacity-70"}`}>{l}</button>
        ))}
      </div>

      {tab === "ops" && (
        <Glass className="p-4 space-y-2">
          <div className="font-bold">سجل التشغيل اليومي والورديات ({shifts.length})</div>
          {shifts.length === 0 && <div className="text-[13px] opacity-60">لا توجد ورديات مسجلة لهذه العربة بعد — سجل أول وردية من مركز الورديات. لا نعرض أي ساعات تقديرية.</div>}
          {shifts.map((s) => {
            const op = s.ops.find((o) => o.vehicleId === v.id);
            return <div key={s.id} className="rounded-2xl bg-white/5 border border-white/10 p-3 text-[13px]">
              <div className="font-bold">{s.date} — وردية {s.type} ({s.start}–{s.end})</div>
              <div className="opacity-70">المشغل: {op?.operator} • الغرفة: {op?.room} • الشحن {op?.startCharge}% → {op?.endCharge}%</div>
              <div className="opacity-70">التسليم: {s.deliverState} • الاستلام: {s.receiveState} {s.handoverDone ? "• مكتمل ✓" : "• غير مكتمل"}</div>
            </div>;
          })}
        </Glass>
      )}
      {tab === "faults" && (
        <Glass className="p-4 space-y-2">
          <div className="font-bold">سجل الأعطال ({faults.length})</div>
          {faults.map((f) => <div key={f.id} className="rounded-2xl bg-white/5 border border-white/10 p-3 text-[13px]">
            <div className="font-bold">{f.type} — {f.desc}</div>
            <div className="opacity-70">الخطورة: {f.severity} • الحالة: {f.status} • الفني: {f.technician || "—"}</div>
          </div>)}
          {faults.length === 0 && <div className="text-[13px] opacity-60">لا أعطال مسجلة.</div>}
        </Glass>
      )}
      {tab === "link" && (
        <Glass className="p-4 space-y-2">
          <div className="font-bold">سجل الاتصالات اللاسلكية</div>
          {db.readings.filter((r) => r.vehicleId === v.id).slice(0, 10).map((r) => (
            <div key={r.id} className="rounded-2xl bg-white/5 border border-white/10 p-3 text-[13px]">
              <div className="font-bold tabular-nums">{new Date(r.time).toLocaleString("ar-EG")} — {r.source === "live" ? "مباشرة من الشاتل" : r.source === "manual" ? "مسجلة يدوياً" : "قديمة"}</div>
              <div className="opacity-70">بطارية {r.batteryPct ?? "—"}% • {r.opMode || ""} {r.temp || ""}</div>
            </div>
          ))}
          {db.readings.filter((r) => r.vehicleId === v.id).length === 0 && <div className="text-[13px] opacity-60">لا قراءات لاسلكية بعد — من مركز الاتصال.</div>}
          <button onClick={() => go("connect")} className="text-[12px] text-sky-300 font-bold">فتح مركز الاتصال ←</button>
        </Glass>
      )}
      {tab === "maint" && (
        <Glass className="p-4 space-y-2">
          <div className="font-bold">سجل الصيانة ({maints.length})</div>
          {maints.map((m) => <div key={m.id} className="rounded-2xl bg-white/5 border border-white/10 p-3 text-[13px]">
            <div className="font-bold">{m.kind}</div><div className="opacity-70">الاستحقاق: {m.dueDate} • {m.status === "done" ? "منفذة " + m.doneDate : "مجدولة"} • {m.tech}</div>
          </div>)}
        </Glass>
      )}
      {tab === "time" && (
        <Glass className="p-4">
          <div className="font-bold mb-2">الخط الزمني — من التسجيل حتى اليوم</div>
          <div className="relative pr-5 space-y-3 before:absolute before:right-1.5 before:top-1 before:bottom-1 before:w-[2px] before:bg-sky-400/30">
            {events.length === 0 && <div className="text-[13px] opacity-60">اختر أي تاريخ من الورديات وستظهر أحداثه هنا. لا توجد أحداث بعد.</div>}
            {events.map((e, i) => (
              <div key={i} className="relative text-[13px]">
                <span className="absolute -right-5 top-1 size-3 rounded-full bg-sky-400 shadow-[0_0_10px_#38bdf8]" />
                <div className="font-bold tabular-nums">{e.t}</div>
                <div className="opacity-75">{e.txt}</div>
              </div>
            ))}
          </div>
        </Glass>
      )}
    </div>
  );
}
