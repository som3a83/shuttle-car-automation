// System settings center — full control without code
import { useState } from "react";
import { Settings2, Truck, Factory, BatteryCharging, CalendarClock, Wrench, Users, FileText, Bell, Database, Search, Plus, Pencil, Archive, RotateCcw, Eye, EyeOff } from "lucide-react";
import { type FleetDB, uid, canDo } from "./store";
import { Glass, Field, inputCls, btnPrimary, btnGhost } from "./ui";

const SECTIONS = [
  { k: "fleet", l: "العربات", i: Truck },
  { k: "makers", l: "الشركات", i: Factory },
  { k: "batt", l: "البطاريات", i: BatteryCharging },
  { k: "shifts", l: "الورديات", i: CalendarClock },
  { k: "maint", l: "الأعطال والصيانة", i: Wrench },
  { k: "users", l: "المستخدمون", i: Users },
  { k: "reports", l: "التقارير", i: FileText },
  { k: "alerts", l: "التنبيهات", i: Bell },
  { k: "data", l: "البيانات", i: Database },
];

export function SettingsCenter({ db, update }: { db: FleetDB; update: any }) {
  const [sec, setSec] = useState("fleet");
  const [q, setQ] = useState("");
  const [confirmDanger, setConfirmDanger] = useState("");
  const ask = (msg: string) => { const v = prompt(msg + "\nاكتب (تأكيد) للمتابعة"); return v === "تأكيد"; };

  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold flex items-center gap-2"><Settings2 className="size-5" /> إعدادات النظام</h1>
      <Glass className="p-3">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 opacity-50" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث داخل الإعدادات: عربة، شركة، بطارية، وردية…" className={inputCls + " !pr-9"} />
        </div>
      </Glass>
      <div className="grid grid-cols-3 gap-2">
        {SECTIONS.map(({ k, l, i: I }) => (
          <button key={k} onClick={() => setSec(k)} className={`rounded-3xl border p-3 font-bold text-[13px] flex flex-col items-center gap-1.5 min-h-[76px] justify-center ${sec === k ? "bg-sky-500/25 border-sky-400/50" : "bg-white/[0.05] border-white/10"}`}>
            <I className="size-5" />{l}
          </button>
        ))}
      </div>

      {sec === "fleet" && <FleetSettings db={db} update={update} q={q} ask={ask} />}
      {sec === "makers" && <MakersSettings db={db} update={update} q={q} />}
      {sec === "batt" && <BattSettings db={db} update={update} q={q} />}
      {sec === "shifts" && <ShiftSettings db={db} update={update} />}
      {sec === "maint" && <MaintSettings db={db} update={update} />}
      {sec === "users" && <UsersSettings db={db} update={update} q={q} ask={ask} />}
      {sec === "reports" && <ReportSettings db={db} update={update} />}
      {sec === "alerts" && <AlertSettings db={db} update={update} />}
      {sec === "data" && <DataSettings db={db} update={update} confirmDanger={confirmDanger} setConfirmDanger={setConfirmDanger} ask={ask} />}

      <Glass className="p-3 text-[12px] opacity-70 leading-6">
        سجل تغييرات الإعدادات يظهر في سجل التعديلات مع اسم المستخدم والوقت. الحذف النهائي للسجلات التاريخية ممنوع — الأرشفة هي البديل الآمن.
      </Glass>
    </div>
  );
}

function FleetSettings({ db, update, q, ask }: any) {
  const [show, setShow] = useState(false);
  const [edit, setEdit] = useState<any>(null);
  const list = db.vehicles.filter((v: any) => !q || (v.number + v.maker + v.model).includes(q));
  const openNew = () => setEdit({ id: "", number: "", maker: db.makers[0]?.name ?? "", model: "", location: "غرفة التبريد A", status: "ready", assetNo: "", serialNo: "", operationDate: "", trial: false, accessoryIds: [], specs: "", note: "" });
  const saveVeh = () => {
    if (!edit.number) return alert("اكتب الرقم التعريفي");
    if (!edit.id && db.vehicles.some((v: any) => v.number === edit.number)) return alert("هذا الرقم مستخدم — اختر رقماً آخر");
    if (edit.id) {
      update((d: FleetDB) => { Object.assign(d.vehicles.find((x) => x.id === edit.id)!, { number: edit.number, maker: edit.maker, model: edit.model, location: edit.location, assetNo: edit.assetNo, serialNo: edit.serialNo, operationDate: edit.operationDate, trial: !!edit.trial, accessoryIds: edit.accessoryIds ?? [], specs: edit.specs, note: edit.note, image: edit.image, lastUpdate: new Date().toISOString() }); return d; }, `تعديل بيانات ${edit.number}`);
    } else {
      update((d: FleetDB) => { const id = uid("v"); d.vehicles.push({ id, number: edit.number, maker: edit.maker, model: edit.model || edit.maker, location: edit.location, status: "ready", batteryId: null, hours: 0, lastUpdate: new Date().toISOString(), note: edit.note, assetNo: edit.assetNo, serialNo: edit.serialNo, operationDate: edit.operationDate, trial: !!edit.trial, accessoryIds: edit.accessoryIds ?? [], specs: edit.specs, image: edit.image }); d.links.push({ vehicleId: id, connType: "none", deviceName: "", deviceId: "", auth: "غير موثق", autoReconnect: true, status: "disconnected", lastConnect: "", lastReading: "" }); return d; }, `إضافة عربة ${edit.number}`);
    }
    setEdit(null);
  };
  return (
    <Glass className="p-3.5 space-y-2">
      <div className="flex justify-between items-center"><b>إدارة العربات ({db.vehicles.length})</b><button onClick={openNew} className={btnPrimary + " !py-2 flex items-center gap-1"}><Plus className="size-4" /> عربة</button></div>
      {list.map((v: any) => (
        <div key={v.id} className={`rounded-2xl border p-3 text-[13px] ${v.archived ? "opacity-60 border-white/10" : "bg-white/5 border-white/10"}`}>
          <div className="flex justify-between items-center gap-2">
            <b>{v.number} • {v.maker} {v.archived ? "(مؤرشفة)" : v.status === "stopped" ? "(موقوفة مؤقتاً)" : ""}</b>
            <div className="flex gap-1">
              <button onClick={() => setEdit({ ...v })} className={btnGhost + " !py-1.5 !px-3 !text-[12px] flex items-center gap-1"}><Pencil className="size-3.5" /> تعديل</button>
              {!v.archived && <button onClick={() => update((d: FleetDB) => { const x = d.vehicles.find((a) => a.id === v.id)!; x.status = x.status === "stopped" ? "ready" : "stopped"; x.lastUpdate = new Date().toISOString(); return d; }, `${v.status === "stopped" ? "إعادة" : "إيقاف مؤقت"} ${v.number}`)} className={btnGhost + " !py-1.5 !px-3 !text-[12px]"}>{v.status === "stopped" ? "إعادة للخدمة" : "إيقاف مؤقت"}</button>}
            </div>
          </div>
          <div className="opacity-70 text-[12px] mt-1">{v.model} • {v.location} {v.assetNo ? `• أصل ${v.assetNo}` : ""}</div>
          <div className="flex gap-1 mt-2">
            <select value={v.location} onChange={(e) => update((d: FleetDB) => { d.vehicles.find((a) => a.id === v.id)!.location = e.target.value; return d; }, `نقل ${v.number} إلى ${e.target.value}`)} className={inputCls + " !text-[12px] !py-1.5"}>
              {["غرفة التبريد A", "غرفة التبريد B", "غرفة التبريد C", "مخزن الاستلام", "منطقة الشحن", "الورشة", "محطة الشحن"].map((r) => <option key={r}>{r}</option>)}
            </select>
            {!v.archived
              ? <button onClick={() => { if (!canDo(db, "canDelete")) return alert("تحتاج صلاحية الحذف/الأرشفة"); if (ask(`أرشفة ${v.number}؟ يبقى سجلها التاريخي كاملاً.`)) update((d: FleetDB) => { d.vehicles.find((a) => a.id === v.id)!.archived = true; return d; }, `أرشفة ${v.number}`); }} className={btnGhost + " !py-1.5 !text-[12px] flex items-center gap-1"}><Archive className="size-3.5" /> أرشفة</button>
              : <button onClick={() => update((d: FleetDB) => { d.vehicles.find((a) => a.id === v.id)!.archived = false; return d; }, `إلغاء أرشفة ${v.number}`)} className={btnGhost + " !py-1.5 !text-[12px] flex items-center gap-1"}><RotateCcw className="size-3.5" /> استعادة</button>}
          </div>
        </div>
      ))}
      {edit && (
        <div className="fixed inset-0 z-50 bg-black/60 grid place-items-center p-4" onClick={() => setEdit(null)}>
          <div className="w-full max-w-sm rounded-3xl bg-[#0e1a2e] border border-white/10 p-4 space-y-2.5 max-h-[90dvh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <b>{edit.id ? "تعديل عربة" : "إضافة عربة جديدة"}</b>
            <div className="grid grid-cols-2 gap-2">
              <Field label="الرقم التعريفي"><input value={edit.number} onChange={(e) => setEdit({ ...edit, number: e.target.value })} className={inputCls} placeholder="SH-06" /></Field>
              <Field label="رقم الأصل"><input value={edit.assetNo ?? ""} onChange={(e) => setEdit({ ...edit, assetNo: e.target.value })} className={inputCls} placeholder="اختياري" /></Field>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Field label="الرقم التسلسلي"><input value={edit.serialNo ?? ""} onChange={(e) => setEdit({ ...edit, serialNo: e.target.value })} className={inputCls} placeholder="Serial" /></Field>
              <Field label="تاريخ التشغيل"><input type="date" value={edit.operationDate ?? ""} onChange={(e) => setEdit({ ...edit, operationDate: e.target.value })} className={inputCls} /></Field>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => setEdit({ ...edit, trial: !edit.trial })} className={`rounded-2xl border px-3 py-2.5 text-[13px] font-bold ${edit.trial ? "bg-violet-500/20 border-violet-400/50 text-violet-200" : "opacity-60 border-white/15"}`}>تحت التجربة: {edit.trial ? "نعم" : "لا"}</button>
              <Field label="الملحقات"><select multiple value={edit.accessoryIds ?? []} onChange={(e) => setEdit({ ...edit, accessoryIds: [...e.target.selectedOptions].map((o) => o.value) })} className={inputCls + " h-[52px]"}>
                {db.accessories.map((a: any) => <option key={a.id} value={a.id}>{a.name} ({a.code})</option>)}
              </select></Field>
            </div>
            <Field label="الشركة المصنعة"><select value={edit.maker} onChange={(e) => setEdit({ ...edit, maker: e.target.value })} className={inputCls}>{db.makers.map((m: any) => <option key={m.id} value={m.name}>{m.name} — {m.country}</option>)}</select></Field>
            <Field label="الطراز"><input value={edit.model} onChange={(e) => setEdit({ ...edit, model: e.target.value })} className={inputCls} placeholder="اسم الطراز" /></Field>
            <Field label="الموقع / الغرفة"><select value={edit.location} onChange={(e) => setEdit({ ...edit, location: e.target.value })} className={inputCls}>{["غرفة التبريد A", "غرفة التبريد B", "غرفة التبريد C", "مخزن الاستلام", "منطقة الشحن", "الورشة", "محطة الشحن"].map((r) => <option key={r}>{r}</option>)}</select></Field>
            <Field label="مواصفات خاصة"><input value={edit.specs ?? ""} onChange={(e) => setEdit({ ...edit, specs: e.target.value })} className={inputCls} placeholder="حمولة، أبعاد…" /></Field>
            <Field label="صورة العربة (رابط أو صورة)"><input value={edit.image ?? ""} onChange={(e) => setEdit({ ...edit, image: e.target.value })} className={inputCls} placeholder="الصق رابط الصورة" /></Field>
            {edit.image ? <img src={edit.image} alt="معاينة" className="rounded-2xl w-full h-28 object-cover border border-white/10" /> : null}
            <Field label="ملاحظات"><input value={edit.note ?? ""} onChange={(e) => setEdit({ ...edit, note: e.target.value })} className={inputCls} /></Field>
            {db.customFields.filter((c: any) => c.target === "vehicle" && c.enabled).map((c: any) => (
              <Field key={c.id} label={c.label}><input value={edit.custom?.[c.id] ?? ""} onChange={(e) => setEdit({ ...edit, custom: { ...(edit.custom ?? {}), [c.id]: e.target.value } })} className={inputCls} /></Field>
            ))}
            <div className="rounded-2xl bg-white/5 border border-white/10 p-2.5 text-[12px] opacity-80">معاينة قبل الحفظ: {edit.number} • {edit.maker} • {edit.location}</div>
            <div className="flex gap-2"><button onClick={saveVeh} className={btnPrimary + " flex-1"}>حفظ</button><button onClick={() => setEdit(null)} className={btnGhost}>إلغاء</button></div>
          </div>
        </div>
      )}
      {show}
    </Glass>
  );
}

function MakersSettings({ db, update, q }: any) {
  const [form, setForm] = useState({ name: "", country: "", specs: "", batteryType: "", controller: "", protocol: "", sdk: "", authReq: "", androidOk: "", gatewayNeeded: "", docs: "" });
  const list = db.makers.filter((m: any) => !q || m.name.includes(q));
  return (
    <Glass className="p-3.5 space-y-2">
      <b>الشركات المصنعة والطرازات ({db.makers.length})</b>
      {list.map((m: any) => (
        <div key={m.id} className="rounded-2xl bg-white/5 border border-white/10 p-3 text-[13px]">
          <div className="flex justify-between"><b>{m.name}</b><button onClick={() => setForm({ ...m })} className="text-sky-300 text-[12px]">تعديل</button></div>
          <div className="opacity-70 text-[12px]">البلد: {m.country || "—"} • البطارية المتوافقة: {m.batteryType || "—"} • التحكم: {m.controller || "—"}</div>
          <div className="opacity-70 text-[12px]">{m.specs}</div>
          <div className="flex gap-1 mt-1">
            <button onClick={() => { const t = prompt("اسم طراز جديد تابع لـ " + m.name); if (t) update((d: FleetDB) => { const id = uid("v"); d.vehicles.push({ id, number: `SH-${d.vehicles.length + 1}`, maker: m.name, model: t, location: "مخزن الاستلام", status: "ready", batteryId: null, hours: 0, lastUpdate: new Date().toISOString(), trial: false, accessoryIds: [] }); d.links.push({ vehicleId: id, connType: "none", deviceName: "", deviceId: "", auth: "غير موثق", autoReconnect: true, status: "disconnected", lastConnect: "", lastReading: "" }); return d; }, `إضافة طراز ${t}`); }} className={btnGhost + " !py-1.5 !text-[12px]"}>إضافة طراز كعربة</button>
            <button onClick={() => { if (!canDo(db, "canDelete")) return alert("تحتاج صلاحية الحذف"); if (db.vehicles.some((v: any) => v.maker === m.name && !v.archived)) return alert("لا يمكن حذف شركة عليها عربات عاملة — أرشف العربات أولاً"); update((d: FleetDB) => { d.makers = d.makers.filter((x) => x.id !== m.id); return d; }, `حذف شركة ${m.name}`); }} className="text-rose-300 text-[12px] px-2">حذف</button>
          </div>
        </div>
      ))}
      <div className="rounded-2xl border border-dashed border-white/20 p-3 space-y-2">
        <b className="text-[13px]">إضافة / تعديل شركة</b>
        <div className="grid grid-cols-2 gap-2">
          <Field label="اسم الشركة"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} /></Field>
          <Field label="بلد التصنيع"><input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} className={inputCls} /></Field>
          <Field label="نوع البطارية المتوافقة"><input value={form.batteryType} onChange={(e) => setForm({ ...form, batteryType: e.target.value })} className={inputCls} /></Field>
          <Field label="نوع جهاز التحكم"><input value={form.controller} onChange={(e) => setForm({ ...form, controller: e.target.value })} className={inputCls} /></Field>
        </div>
        <Field label="المواصفات"><input value={form.specs} onChange={(e) => setForm({ ...form, specs: e.target.value })} className={inputCls} /></Field>
        <b className="text-[13px]">بيانات الربط والوثائق الفنية</b>
        <div className="grid grid-cols-2 gap-2">
          <Field label="بروتوكول الاتصال"><input value={(form as any).protocol ?? ""} onChange={(e) => setForm({ ...form, protocol: e.target.value })} className={inputCls} placeholder="مثال: BLE GATT" /></Field>
          <Field label="SDK / API"><input value={(form as any).sdk ?? ""} onChange={(e) => setForm({ ...form, sdk: e.target.value })} className={inputCls} /></Field>
          <Field label="المصادقة المطلوبة"><input value={(form as any).authReq ?? ""} onChange={(e) => setForm({ ...form, authReq: e.target.value })} className={inputCls} /></Field>
          <Field label="توافق أندرويد"><input value={(form as any).androidOk ?? ""} onChange={(e) => setForm({ ...form, androidOk: e.target.value })} className={inputCls} /></Field>
          <Field label="بوابة إضافية"><input value={(form as any).gatewayNeeded ?? ""} onChange={(e) => setForm({ ...form, gatewayNeeded: e.target.value })} className={inputCls} /></Field>
          <Field label="الوثائق"><input value={(form as any).docs ?? ""} onChange={(e) => setForm({ ...form, docs: e.target.value })} className={inputCls} /></Field>
        </div>
        <button onClick={() => {
          if (!form.name) return alert("اكتب اسم الشركة");
          const ex = db.makers.find((m: any) => m.name === form.name);
          if (ex) update((d: FleetDB) => { Object.assign(d.makers.find((x) => x.id === ex.id)!, form); return d; }, `تعديل شركة ${form.name}`);
          else update((d: FleetDB) => { d.makers.push({ id: uid("mk"), ...form }); return d; }, `إضافة شركة ${form.name}`);
          setForm({ name: "", country: "", specs: "", batteryType: "", controller: "", protocol: "", sdk: "", authReq: "", androidOk: "", gatewayNeeded: "", docs: "" });
        }} className={btnPrimary + " w-full"}>حفظ الشركة</button>
      </div>
    </Glass>
  );
}

function BattSettings({ db, update, q }: any) {
  const [code, setCode] = useState("");
  const s = db.settings;
  return (
    <Glass className="p-3.5 space-y-2">
      <b>البطاريات والملحقات</b>
      <div className="grid grid-cols-2 gap-2">
        <Field label={`حد استبدال البطارية % (الحالي ${s.swapThreshold})`}><input type="number" value={s.swapThreshold} onChange={(e) => update((d: FleetDB) => { d.settings.swapThreshold = Math.max(10, Math.min(90, +e.target.value || 50)); return d; }, `تعديل حد الاستبدال إلى ${e.target.value}%`)} className={inputCls} /></Field>
        <Field label={`حد التنبيه المنخفض % (الحالي ${s.lowAlert})`}><input type="number" value={s.lowAlert} onChange={(e) => update((d: FleetDB) => { d.settings.lowAlert = +e.target.value || 30; return d; }, "تعديل حد التنبيه")} className={inputCls} /></Field>
      </div>
      <div className="text-[12px] opacity-70">لا يوجد حد ثابت في الكود — كل الشاشات والتقارير والتنبيهات تقرأ هذا الإعداد مباشرة.</div>
      <div className="flex gap-2">
        <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="كود بطارية جديدة BAT-.." className={inputCls} />
        <button onClick={() => {
          if (!code) return alert("اكتب الكود");
          if (db.batteries.some((b: any) => b.code === code)) return alert("الكود مستخدم");
          update((d: FleetDB) => { d.batteries.push({ id: uid("b"), code, location: "مخزن البطاريات", vehicleId: null, charge: 100, health: "excellent", state: "spare", lastCharge: new Date().toISOString().slice(0, 10), lastSwap: new Date().toISOString().slice(0, 10), lastBy: "الإعدادات" }); return d; }, `إضافة بطارية ${code}`);
          setCode("");
        }} className={btnPrimary}>إضافة</button>
      </div>
      {db.batteries.filter((b: any) => !q || b.code.includes(q)).map((b: any) => (
        <div key={b.id} className="flex items-center justify-between rounded-2xl bg-white/5 border border-white/10 px-3 py-2 text-[13px]">
          <span><b>{b.code}</b> — {b.charge}% {b.archived ? "(مؤرشفة)" : ""}</span>
          <div className="flex gap-1">
            <button onClick={() => { const nc = prompt("كود جديد", b.code); if (nc) update((d: FleetDB) => { d.batteries.find((x) => x.id === b.id)!.code = nc; return d; }, `تعديل كود بطارية إلى ${nc}`); }} className="text-sky-300 text-[12px]">تعديل</button>
            <button onClick={() => update((d: FleetDB) => { const x = d.batteries.find((a) => a.id === b.id)!; x.archived = !x.archived; return d; }, `${b.archived ? "استعادة" : "أرشفة"} بطارية ${b.code}`)} className="text-[12px] opacity-70">{b.archived ? "استعادة" : "أرشفة"}</button>
          </div>
        </div>
      ))}
      <b className="text-[13px]">أنواع البطاريات</b>
      {db.battTypes.map((t: any) => <div key={t.id} className="text-[13px] rounded-2xl bg-white/5 border border-white/10 px-3 py-2">{t.name} — {t.capacity}</div>)}
      <button onClick={() => { const n = prompt("اسم نوع بطارية جديد"); if (n) { const c = prompt("السعة (مثال 100Ah)") || ""; update((d: FleetDB) => { d.battTypes.push({ id: uid("bt"), name: n, capacity: c }); return d; }, `إضافة نوع بطارية ${n}`); } }} className={btnGhost + " w-full"}>إضافة نوع بطارية</button>
      <b className="text-[13px]">أجهزة التحكم والملحقات ({db.accessories.length})</b>
      {db.accessories.map((a: any) => <div key={a.id} className="text-[13px] rounded-2xl bg-white/5 border border-white/10 px-3 py-2">{a.name} — {a.kind} — {a.code}</div>)}
      <button onClick={() => { const n = prompt("اسم الجهاز أو الملحق"); if (n) update((d: FleetDB) => { d.accessories.push({ id: uid("ac"), name: n, kind: "ملحق", code: "AC-" + Date.now().toString().slice(-4) }); return d; }, `إضافة ملحق ${n}`); }} className={btnGhost + " w-full"}>إضافة جهاز / ملحق</button>
    </Glass>
  );
}

function ShiftSettings({ db, update }: any) {
  return (
    <Glass className="p-3.5 space-y-2">
      <b>قوالب الورديات ({db.shiftTemplates.length} يومياً)</b>
      {db.shiftTemplates.map((t: any) => (
        <div key={t.id} className="rounded-2xl bg-white/5 border border-white/10 p-3 text-[13px]">
          <div className="flex justify-between"><b>{t.name}</b><button onClick={() => update((d: FleetDB) => { d.shiftTemplates = d.shiftTemplates.filter((x) => x.id !== t.id); return d; }, `حذف قالب وردية ${t.name}`)} className="text-rose-300 text-[12px]">حذف</button></div>
          <div className="grid grid-cols-2 gap-1.5 mt-1">
            <Field label="البداية"><input type="time" value={t.start} onChange={(e) => update((d: FleetDB) => { d.shiftTemplates.find((x) => x.id === t.id)!.start = e.target.value; return d; }, "")} className={inputCls} /></Field>
            <Field label="النهاية"><input type="time" value={t.end} onChange={(e) => update((d: FleetDB) => { d.shiftTemplates.find((x) => x.id === t.id)!.end = e.target.value; return d; }, "")} className={inputCls} /></Field>
          </div>
          <Field label="متطلبات التسجيل"><input value={t.required} onChange={(e) => update((d: FleetDB) => { d.shiftTemplates.find((x) => x.id === t.id)!.required = e.target.value; return d; }, "")} className={inputCls} /></Field>
        </div>
      ))}
      <button onClick={() => { const n = prompt("اسم وردية جديدة (مثال: استثنائية)") || "استثنائية"; update((d: FleetDB) => { d.shiftTemplates.push({ id: uid("st"), name: n, start: "08:00", end: "16:00", supervisors: "", required: "" }); return d; }, `إضافة وردية ${n}`); }} className={btnPrimary + " w-full"}>إضافة وردية / قالب جديد</button>
      <div className="text-[12px] opacity-70">تُستخدم هذه القوالب عند إنشاء وردية جديدة — عدّل الأوقات هنا دون أي تدخل برمجي.</div>
    </Glass>
  );
}

function MaintSettings({ db, update }: any) {
  const addTo = (key: "faultTypes" | "maintKinds" | "spareParts" | "technicians", label: string) => {
    const v = prompt(label);
    if (v) update((d: FleetDB) => { (d as any)[key].push(v); return d; }, `إضافة ${label}: ${v}`);
  };
  const row = (title: string, key: any, items: string[]) => (
    <div>
      <b className="text-[13px]">{title} ({items.length})</b>
      <div className="flex flex-wrap gap-1.5 mt-1">
        {items.map((x) => <span key={x} className="rounded-full bg-white/10 px-3 py-1.5 text-[12px] flex items-center gap-1">{x}<button onClick={() => update((d: FleetDB) => { (d as any)[key] = (d as any)[key].filter((a: string) => a !== x); return d; }, `حذف ${x}`)} className="text-rose-300">×</button></span>)}
        <button onClick={() => addTo(key, title)} className="rounded-full border border-dashed border-white/25 px-3 py-1.5 text-[12px]">+ إضافة</button>
      </div>
    </div>
  );
  return (
    <Glass className="p-3.5 space-y-3">
      <b>أنواع الأعطال والصيانة والفنيين</b>
      {row("أنواع الأعطال", "faultTypes", db.faultTypes)}
      {row("أنواع الصيانة الوقائية", "maintKinds", db.maintKinds)}
      {row("قطع الغيار", "spareParts", db.spareParts)}
      {row("الفنيون", "technicians", db.technicians)}
      <div className="text-[12px] opacity-70">قواعد الاعتماد: لا تعود العربة للعمل إلا بعد تسجيل الإجراء ونتيجة الاختبار واعتماد الفني — تُطبق تلقائياً في مركز الأعطال.</div>
      <b className="text-[13px]">حقول مخصصة جديدة</b>
      {db.customFields.map((c: any) => <div key={c.id} className="flex justify-between text-[13px] rounded-2xl bg-white/5 border border-white/10 px-3 py-2"><span>{c.label} — {c.target === "vehicle" ? "العربة" : "البطارية"} {c.enabled ? "" : "(متوقف)"}</span><button onClick={() => update((d: FleetDB) => { d.customFields.find((x) => x.id === c.id)!.enabled = !c.enabled; return d; }, "")} className="text-[12px] opacity-70">{c.enabled ? "إيقاف" : "تفعيل"}</button></div>)}
      <button onClick={() => { const l = prompt("اسم الحقل (مثال: تاريخ الضمان)"); if (l) { const t = prompt("يظهر في: vehicle للعربة / battery للبطارية", "vehicle") || "vehicle"; update((d: FleetDB) => { d.customFields.push({ id: uid("cf"), label: l, target: t, enabled: true }); return d; }, `إضافة حقل ${l}`); } }} className={btnGhost + " w-full"}>إضافة حقل مخصص</button>
    </Glass>
  );
}

function UsersSettings({ db, update, q, ask }: any) {
  const [name, setName] = useState("");
  const toggle = (u: any, k: string) => update((d: FleetDB) => { (d.users.find((x) => x.id === u.id) as any)[k] = !(u as any)[k]; return d; }, `تعديل صلاحية ${u.name}`);
  return (
    <Glass className="p-3.5 space-y-2">
      <b>المستخدمون والأدوار ({db.users.length})</b>
      {db.users.filter((u: any) => !q || u.name.includes(q)).map((u: any) => (
        <div key={u.id} className={`rounded-2xl border p-3 text-[13px] ${u.active === false ? "opacity-50" : "bg-white/5 border-white/10"}`}>
          <div className="flex justify-between items-center"><b>{u.name}</b>
            <select value={u.role} onChange={(e) => update((d: FleetDB) => { d.users.find((x) => x.id === u.id)!.role = e.target.value; return d; }, `تغيير دور ${u.name} إلى ${e.target.value}`)} className="rounded-full bg-white/10 text-[12px] px-2 py-1">
              {db.roles.map((r: any) => <option key={r.id} value={r.name}>{r.name}</option>)}
            </select>
          </div>
          <div className="flex flex-wrap gap-1.5 mt-2 text-[12px]">
            {[["canAdd", "إضافة"], ["canEdit", "تعديل"], ["canDelete", "حذف"], ["canApprove", "اعتماد"], ["canReport", "تقارير"]].map(([k, l]) => (
              <button key={k} onClick={() => toggle(u, k)} className={`rounded-full px-2.5 py-1 border ${(u as any)[k] ? "bg-emerald-500/20 border-emerald-400/40 text-emerald-200" : "opacity-50 border-white/15"}`}>{l}: {(u as any)[k] ? "نعم" : "لا"}</button>
            ))}
          </div>
          <div className="flex gap-2 mt-2">
            <button onClick={() => { const p = prompt("كلمة مرور جديدة لـ " + u.name + " (تُحفظ مشفرة بسيطة ولا تظهر لأحد)"); if (p) update((d: FleetDB) => { d.users.find((x) => x.id === u.id)!.passHash = "h" + p.length + "." + btoa(p).slice(0, 12); return d; }, `تغيير كلمة مرور ${u.name}`); }} className="text-[12px] text-sky-300">تغيير كلمة المرور</button>
            <button onClick={() => update((d: FleetDB) => { d.users.find((x) => x.id === u.id)!.active = u.active === false ? true : false; return d; }, `${u.active === false ? "تفعيل" : "تعطيل"} ${u.name}`)} className="text-[12px] opacity-70">{u.active === false ? "تفعيل" : "تعطيل"}</button>
          </div>
        </div>
      ))}
      <div className="flex gap-2">
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="اسم مستخدم جديد" className={inputCls} />
        <button onClick={() => { if (!name) return; update((d: FleetDB) => { d.users.push({ id: uid("u"), name, role: d.roles[2]?.name ?? "مشغل الشاتل كار", active: true, canAdd: false, canEdit: false, canDelete: false, canApprove: false, canReport: false }); return d; }, `إضافة مستخدم ${name}`); setName(""); }} className={btnPrimary}>إضافة</button>
      </div>
      <b className="text-[13px]">الأدوار ({db.roles.length})</b>
      {db.roles.map((r: any) => <div key={r.id} className="text-[13px] rounded-2xl bg-white/5 border border-white/10 px-3 py-2">{r.name} — إضافة:{r.canAdd ? "✓" : "—"} تعديل:{r.canEdit ? "✓" : "—"} حذف:{r.canDelete ? "✓" : "—"} اعتماد:{r.canApprove ? "✓" : "—"}</div>)}
      <button onClick={() => { const n = prompt("اسم دور جديد"); if (n) update((d: FleetDB) => { d.roles.push({ id: uid("r"), name: n, pages: ["home"], canAdd: false, canEdit: false, canDelete: false, canApprove: false, canReport: false }); return d; }, `إنشاء دور ${n}`); }} className={btnGhost + " w-full"}>إنشاء دور جديد</button>
      {ask ? null : null}
    </Glass>
  );
}

function ReportSettings({ db, update }: any) {
  const s = db.settings;
  const secToggle = (k: keyof typeof s.sections) => update((d: FleetDB) => { d.settings.sections[k] = !d.settings.sections[k]; return d; }, "تعديل أقسام التقرير");
  return (
    <Glass className="p-3.5 space-y-2">
      <b>هوية التقرير ومحتواه</b>
      <div className="grid grid-cols-2 gap-2">
        <Field label="اسم المنشأة"><input value={s.facility} onChange={(e) => update((d: FleetDB) => { d.settings.facility = e.target.value; return d; }, "")} className={inputCls} /></Field>
        <Field label="الإدارة"><input value={s.dept} onChange={(e) => update((d: FleetDB) => { d.settings.dept = e.target.value; return d; }, "")} className={inputCls} /></Field>
        <Field label="المسؤول عن التقرير"><input value={s.reportOwner} onChange={(e) => update((d: FleetDB) => { d.settings.reportOwner = e.target.value; return d; }, "")} className={inputCls} /></Field>
        <Field label="موعد التقرير اليومي"><input type="time" value={s.reportTime} onChange={(e) => update((d: FleetDB) => { d.settings.reportTime = e.target.value; return d; }, "")} className={inputCls} /></Field>
      </div>
      <Field label="عنوان التقرير"><input value={s.reportTitle} onChange={(e) => update((d: FleetDB) => { d.settings.reportTitle = e.target.value; return d; }, "")} className={inputCls} /></Field>
      <b className="text-[13px]">أقسام التقرير (إظهار / إخفاء)</b>
      {[["summary", "الملخص التنفيذي"], ["vehicles", "حالة العربات"], ["batteries", "البطاريات"], ["faults", "الأعطال والصيانة"], ["shifts", "الورديات"], ["advice", "التوصيات"]].map(([k, l]) => (
        <button key={k} onClick={() => secToggle(k as any)} className="w-full flex justify-between rounded-2xl bg-white/5 border border-white/10 px-3 py-2 text-[13px]">{l}<span>{(s.sections as any)[k] ? <Eye className="size-4 text-emerald-300" /> : <EyeOff className="size-4 opacity-50" />}</span></button>
      ))}
      <Field label="صيغة التصدير"><select value={s.exportFormat} onChange={(e) => update((d: FleetDB) => { d.settings.exportFormat = e.target.value; return d; }, "")} className={inputCls}><option value="txt">ملف قابل للطباعة</option><option value="csv">جدول إلكتروني</option></select></Field>
      <Field label="النطاق الافتراضي"><select value={s.reportScope} onChange={(e) => update((d: FleetDB) => { d.settings.reportScope = e.target.value; return d; }, "")} className={inputCls}><option value="fleet">الأسطول</option><option value="trial">التجربة</option></select></Field>
      <Field label="وضع الاتصال (قراءة فقط دائماً)"><select value={s.connMode} onChange={(e) => update((d: FleetDB) => { d.settings.connMode = "readonly"; return d; }, "")} className={inputCls}><option value="readonly">قراءة فقط — بدون أوامر تحكم</option></select></Field>
      <button onClick={() => update(() => { return 0 as any; }, "حفظ إعدادات التقرير")} className={btnPrimary + " w-full hidden"}>حفظ</button>
      <div className="text-[12px] opacity-70">تُحفظ كل خانة تلقائياً وتنعكس على التقرير الرسمي فوراً.</div>
    </Glass>
  );
}

function AlertSettings({ db, update }: any) {
  const s = db.settings;
  const rows: [string, string][] = [["lowBatt", "انخفاض الشحن"], ["stopped", "توقف عربة"], ["critical", "عطل حرج"], ["maint", "صيانة مستحقة"], ["shiftMiss", "عدم تسجيل وردية"], ["handover", "عدم إتمام التسليم"], ["spare", "بطارية احتياطية غير جاهزة"]];
  return (
    <Glass className="p-3.5 space-y-2">
      <b>التحكم في التنبيهات</b>
      {rows.map(([k, l]) => (
        <div key={k} className="flex items-center justify-between rounded-2xl bg-white/5 border border-white/10 px-3 py-2 text-[13px]">
          <span>{l}</span>
          <div className="flex items-center gap-2">
            <select value={s.alertLevels[k] ?? "high"} onChange={(e) => update((d: FleetDB) => { d.settings.alertLevels[k] = e.target.value; return d; }, `مستوى تنبيه ${l}`)} className="rounded-full bg-white/10 text-[12px] px-2 py-1">
              <option value="critical">حرج</option><option value="high">تدخل</option><option value="watch">متابعة</option>
            </select>
            <button onClick={() => update((d: FleetDB) => { (d.settings.alerts as any)[k] = !(d.settings.alerts as any)[k]; return d; }, `${(s.alerts as any)[k] ? "إيقاف" : "تشغيل"} تنبيه ${l}`)} className={`rounded-full px-3 py-1 text-[12px] font-bold ${(s.alerts as any)[k] ? "bg-emerald-500/20 text-emerald-200" : "opacity-50 border border-white/15"}`}>{(s.alerts as any)[k] ? "يعمل" : "متوقف"}</button>
          </div>
        </div>
      ))}
    </Glass>
  );
}

function DataSettings({ db, update, ask }: any) {
  const exportAll = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(db, null, 2)], { type: "application/json" }));
    a.download = `نسخة-احتياطية-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  };
  const restoreJson = (f: File) => {
    const r = new FileReader();
    r.onload = () => {
      try {
        const d = JSON.parse(String(r.result));
        if (!Array.isArray(d.vehicles) || !Array.isArray(d.batteries)) return alert("ملف غير صالح: ليس نسخة احتياطية للتطبيق");
        const cur = { v: db.vehicles.length, b: db.batteries.length, s: db.shifts.length, f: db.faults.length };
        const nxt = { v: d.vehicles.length, b: d.batteries.length, s: (d.shifts || []).length, f: (d.faults || []).length };
        if (!confirm(`معاينة الاستعادة (تحقق من السلامة ✓):\nالحالي: عربات ${cur.v} • بطاريات ${cur.b} • ورديات ${cur.s} • أعطال ${cur.f}\nالملف: عربات ${nxt.v} • بطاريات ${nxt.b} • ورديات ${nxt.s} • أعطال ${nxt.f}\n\nسيُحفظ نسخة تلقائية من الحالي أولاً. متابعة؟`)) return;
        const a = document.createElement("a");
        a.href = URL.createObjectURL(new Blob([JSON.stringify(db, null, 2)], { type: "application/json" }));
        a.download = `نسخة-تلقائية-قبل-الاستعادة-${new Date().toISOString().slice(0, 10)}.json`;
        a.click();
        if (prompt("اكتب (تأكيد) لاستبدال البيانات الحالية") !== "تأكيد") return;
        update(() => d, "استعادة نسخة احتياطية بعد معاينة ونسخة تلقائية");
      } catch { alert("ملف غير صالح"); }
    };
    r.readAsText(f);
  };
  const importCsv = (f: File) => {
    const r = new FileReader();
    r.onload = () => {
      try {
        const text = String(r.result);
        const lines = text.split("\n").filter((l) => l.trim()).slice(1);
        const seen = new Set(db.vehicles.map((v: any) => v.number));
        const dup: string[] = []; let added = 0;
        const next = structuredClone(db);
        lines.forEach((ln) => {
          const [number, maker, model, location] = ln.split(",");
          if (!number) return;
          if (seen.has(number.trim())) { dup.push(number.trim()); return; }
          next.vehicles.push({ id: uid("v"), number: number.trim(), maker: (maker || "—").trim(), model: (model || maker || "").trim(), location: (location || "مخزن الاستلام").trim(), status: "ready", batteryId: null, hours: 0, lastUpdate: new Date().toISOString() });
          added++;
        });
        if (!confirm(`مراجعة قبل الاستيراد:\nجديد: ${added}\nمكرر (سيُتجاهل): ${dup.join("، ") || "لا يوجد"}\nمتابعة؟`)) return;
        update(() => next, `استيراد ${added} عربات من جدول`);
      } catch { alert("ملف غير صالح"); }
    };
    r.readAsText(f);
  };
  return (
    <Glass className="p-3.5 space-y-2">
      <b>النسخ الاحتياطي والاستيراد</b>
      <div className="grid grid-cols-2 gap-2">
        <button onClick={exportAll} className={btnPrimary}>نسخة احتياطية</button>
        <label className={btnGhost + " text-center cursor-pointer"}>استيراد جدول<input type="file" accept=".csv,.json" className="hidden" onChange={(e) => e.target.files?.[0] && importCsv(e.target.files[0])} /></label>
      </div>
      <label className={btnGhost + " w-full text-center cursor-pointer block"}>استعادة نسخة (معاينة + نسخة تلقائية)<input type="file" accept=".json" className="hidden" onChange={(e) => e.target.files?.[0] && restoreJson(e.target.files[0])} /></label>
      <div className="text-[12px] opacity-70">الاستيراد يكشف المكرر حسب الرقم التعريفي ويعرض مراجعة قبل الحفظ. الأرشفة تحفظ السجل التاريخي.</div>
      <b className="text-[13px]">الحماية من الحذف الخاطئ</b>
      <div className="rounded-2xl border border-rose-400/30 bg-rose-500/10 p-3 text-[13px] space-y-2">
        <div>حذف السجل التشغيلي (الورديات والأعطال) يحتاج تأكيداً صريحاً ولا يمس العربات والبطاريات.</div>
        <button onClick={() => { if (ask("سيتم حذف كل الورديات والأعطال. العربات والبطاريات تبقى.")) update((d: FleetDB) => { d.shifts = []; d.faults = []; return d; }, "حذف جماعي للسجل التشغيلي"); }} className="rounded-full bg-rose-500 px-4 py-2 text-[13px] font-bold text-white">حذف جماعي — بتأكيد</button>
      </div>
      <div className="text-[12px] opacity-70">آخر نشاط: {db.activity[0]?.action} — {db.activity[0]?.time.slice(0, 16).replace("T", " ")}</div>
    </Glass>
  );
}
