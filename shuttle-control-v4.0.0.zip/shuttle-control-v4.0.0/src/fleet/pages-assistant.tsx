// Executive AI assistant — understands Arabic, executes permitted tasks with confirmation
import { useState } from "react";
import { Sparkles, CheckCircle2, XCircle, KeyRound, ShieldCheck, Loader2 } from "lucide-react";
import { type FleetDB, uid, canDo, swapThreshold, readiness, openFaults, batteriesNeeding } from "./store";
import { Glass, Field, inputCls, btnPrimary, btnGhost } from "./ui";

interface Msg { me: boolean; t: string; table?: string[][]; }
interface Pending { kind: string; data: any; need: string[]; summary: string; danger?: boolean; steps?: string[]; }

function extractNumber(t: string): string | null {
  const m = t.match(/(SH[\s\-_]?\d+|[A-Z]+[\s\-_]?\d+)/i);
  return m ? m[1].replace(/\s+/g, "").toUpperCase() : null;
}
function extractPct(t: string): number | null {
  const m = t.match(/(\d{1,3})\s*%/);
  return m ? +m[1] : null;
}
function extractTime(t: string): string[] {
  const m = [...t.matchAll(/(\d{1,2})\s*(صباحا|صباحاً|مساء|مساءً)?/g)].map((x) => x[1].padStart(2, "0") + ":00");
  return m;
}

function parse(text: string, db: FleetDB): { intent: string; params: any; reply: string; table?: string[][]; pending?: Pending } {
  const t = text.trim();
  const th = swapThreshold(db);
  const today = new Date().toISOString().slice(0, 10);

  if (/المتوقفة/.test(t)) {
    const rows = db.vehicles.filter((v) => v.status === "stopped" && !v.archived);
    return { intent: "list", params: {}, reply: rows.length ? `العربات المتوقفة الآن (${rows.length}): ${rows.map((v) => v.number + " — " + v.location).join("، ")}.` : "لا توجد عربات متوقفة حالياً.", table: rows.map((v) => [v.number, v.maker, v.location]) };
  }
  if (/بطاريات.*(50|حد|تحتاج|شحن)/.test(t) || (/بطاريات/.test(t) && /اعرض/.test(t))) {
    const n = batteriesNeeding(db);
    return { intent: "list", params: {}, reply: n.length ? `${n.length} بطاريات عند حد الاستبدال (${th}%) أو تحته: ${n.map((b) => b.code + " " + b.charge + "%").join("، ")}.` : `كل البطاريات فوق حد الاستبدال (${th}%).`, table: n.map((b) => [b.code, b.charge + "%", b.location]) };
  }
  if (/أكثر.*أعطال/.test(t)) {
    const c: Record<string, number> = {};
    const month = new Date().toISOString().slice(0, 7);
    db.faults.filter((f) => (f.createdAt || "").slice(0, 7) === month || true).forEach((f) => c[f.vehicleId] = (c[f.vehicleId] || 0) + 1);
    const e = Object.entries(c).sort((a, b) => b[1] - a[1])[0];
    return { intent: "list", params: {}, reply: e ? `الأكثر أعطالاً في السجل: ${db.vehicles.find((v) => v.id === e[0])?.number} بعدد ${e[1]} بلاغات. الفترة: كل السجل (الشهر الحالي يشمل ${db.faults.filter((f) => (f.createdAt || "").slice(0, 7) === month).length} بلاغات).` : "لا بلاغات مسجلة بعد." };
  }
  if (/لم تسجل.*وردية|بدون وردية|ناقصة/.test(t) && /وردية/.test(t)) {
    const withShift = new Set(db.shifts.filter((s) => s.date === today).flatMap((s) => s.ops.map((o) => o.vehicleId)));
    const missing = db.vehicles.filter((v) => !v.archived && !withShift.has(v.id));
    return { intent: "list", params: {}, reply: missing.length ? `عربات بلا وردية اليوم (${today}): ${missing.map((v) => v.number).join("، ")}.` : "كل العربات العاملة مسجلة في ورديات اليوم.", table: missing.map((v) => [v.number, v.maker]) };
  }
  if (/قارن.*(أداء|العربات)|آخر 30/.test(t)) {
    const rows = db.vehicles.filter((v) => !v.archived).map((v) => {
      const fl = db.faults.filter((f) => f.vehicleId === v.id).length;
      const sh = db.shifts.filter((s) => s.ops.some((o) => o.vehicleId === v.id)).length;
      return [v.number, String(sh * 8) + " س", String(fl)];
    });
    return { intent: "list", params: {}, reply: `مقارنة آخر 30 يوماً (من البيانات المسجلة فقط): الساعات = عدد الورديات × 8. لا توجد أرقام تقديرية.`, table: [["العربة", "ساعات مسجلة", "بلاغات"], ...rows] };
  }
  if (/اقتراح|تحسين كفاءة|تعديلات تقترح/.test(t)) {
    const sug: string[] = [];
    if (batteriesNeeding(db).length) sug.push(`اشحن أو استبدل ${batteriesNeeding(db).length} بطاريات عند الحد`);
    if (openFaults(db).length) sug.push(`أغلق ${openFaults(db).length} أعطال مفتوحة قبل تفاقمها`);
    if (db.shifts.filter((s) => s.date === today).length < db.shiftTemplates.length) sug.push("أكمل تسجيل كل الورديات اليومية");
    if (db.maints.some((m) => m.status !== "done")) sug.push("نفذ الصيانة المجدولة المتأخرة");
    return { intent: "list", params: {}, reply: sug.length ? "أقترح: " + sug.join("؛ ") + "." : "الأسطول مستقر — حافظ على التسجيل اليومي.", };
  }
  if (/كم ساعة|ساعات التشغيل|عملت.*اليوم/.test(t)) {
    const rows = db.vehicles.filter((v) => !v.archived).map((v) => {
      const n = db.shifts.filter((s) => s.date === today && s.ops.some((o) => o.vehicleId === v.id)).length;
      return [v.number, n ? (n * 8) + " س مسجلة" : "لا وردية اليوم"];
    });
    return { intent: "list", params: {}, reply: `ساعات اليوم (${today}) من الورديات المسجلة فقط — لا تقديرات.`, table: [["العربة", "الساعات"], ...rows] };
  }
  if (/كرافتسمان|أعطال.*كرافت|اعرض أعطال/.test(t)) {
    const vs = db.vehicles.filter((v) => v.maker.includes("كرافتسمان"));
    const fl = db.faults.filter((f) => vs.some((v) => v.id === f.vehicleId));
    return { intent: "list", params: {}, reply: fl.length ? `أعطال كرافتسمان (${fl.length}): ` + fl.map((f) => `${db.vehicles.find((v) => v.id === f.vehicleId)?.number}: ${f.type} — ${f.status}`).join("؛ ") : "لا أعطال مسجلة لكرافتسمان.", table: fl.map((f) => [db.vehicles.find((v) => v.id === f.vehicleId)?.number ?? "", f.type, f.status]) };
  }
  if (/حلل.*توقف|أسباب.*توقف|توقف العربات/.test(t)) {
    const stops = db.shifts.flatMap((s) => s.stops.map((x) => ({ ...x, date: s.date })));
    const by: Record<string, number> = {};
    stops.forEach((x) => { by[x.reason || "غير موثق"] = (by[x.reason || "غير موثق"] || 0) + (x.minutes || 0); });
    const top = Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, 5);
    return { intent: "list", params: {}, reply: stops.length ? `تحليل التوقفات المسجلة (إجمالي ${stops.reduce((a, x) => a + (x.minutes || 0), 0)} د): ` + top.map(([k, v]) => `${k} ${v} د`).join("؛ ") + " — تحليل وصفي وليس تشخيصاً." : "لا توقفات مسجلة — سجل التوقفات في الورديات أولاً." };
  }
  if (/قارن.*(الشركات|الأنواع)|مقارنة.*(الشاتل|الأنواع)/.test(t)) {
    return { intent: "list", params: {}, reply: "المقارنة من البحث الموثق: كازيولي (الأرجح Cassioli — تحقق من اللوحة) أفضل قناة واي فاي عبر التابلت؛ كرافتسمان ريموت الراديو + SFMS؛ أكمي التابلت اللاسلكي + Acme Plus. لا بلوتوث ولا تطبيق هاتف رسمي لأي نوع. التفاصيل والخطابات في مركز الاتصال ← الملف الفني.", table: [["النوع", "الأفضل المحتمل"], ["كازيولي", "واي فاي ISAT عبر التابلت"], ["كرافتسمان", "ريموت الراديو + SFMS"], ["أكمي", "التابلت + Acme Plus"]] };
  }
  if (/حالة الاتصال|سجل الاتصالات|العربات المتصل/.test(t)) {
    const rows = db.vehicles.filter((v) => !v.archived).map((v) => {
      const l = db.links.find((x) => x.vehicleId === v.id);
      const st = l ? ({ connected: "متصل", disconnected: "غير متصل", searching: "جارٍ البحث", failed: "فشل الاتصال", nodata: "متصل دون بيانات", repair: "يحتاج إعادة اقتران" } as any)[l.status] : "غير متصل";
      return [v.number, st];
    });
    return { intent: "list", params: {}, reply: `حالة الاتصال الآن من مركز الاتصال — أي قراءة بلا مصدر مباشر تظهر بشارتها.`, table: [["العربة", "الاتصال"], ...rows] };
  }
  if (/سجل وردية جديدة|أنشئ وردية اليوم|وردية جديدة/.test(t)) {
    return { intent: "confirm", params: {}, reply: "", pending: { kind: "add_shift", data: { start: "08:00", end: "16:00" }, need: [], summary: `وردية جديدة اليوم ${today} من 08:00 إلى 16:00 تشمل العربات العاملة الحالية.`, steps: ["قراءة القوالب ✓", "بانتظار تأكيدك", "الحفظ والتحقق"] } };
  }
  if (/أنشئ بلاغ|بلاغ صيانة جديد|سجل بلاغ/.test(t)) {
    const v = db.vehicles.find((x) => !x.archived);
    return { intent: "confirm", params: {}, reply: "", pending: { kind: "add_fault", data: { vehicleId: v?.id, type: "كهرباء", desc: t.slice(0, 80) }, need: [], summary: `بلاغ صيانة جديد على ${v?.number} — حدد النوع والوصف بعد التأكيد من مركز الأعطال.`, steps: ["تحديد العربة ✓", "بانتظار تأكيدك", "الحفظ والتحقق"] } };
  }
  if (/راجع.*(البيانات الناقصة|العربات)|اكتشف.*ناقص/.test(t)) {
    const gaps: string[] = [];
    db.vehicles.filter((v) => !v.archived).forEach((v) => {
      if (!v.batteryId) gaps.push(`${v.number}: بدون بطارية مركبة`);
      if (!v.location) gaps.push(`${v.number}: بدون موقع`);
      if (!v.assetNo) gaps.push(`${v.number}: بدون رقم أصل`);
    });
    if (!db.shifts.length) gaps.push("لا ورديات مسجلة إطلاقاً");
    return { intent: "list", params: {}, reply: gaps.length ? `البيانات الناقصة (${gaps.length}): ` + gaps.slice(0, 12).join("؛ ") + (gaps.length > 12 ? `… وغيرها ${gaps.length - 12}` : "") + ". لم أعدّل أي بيانات — أخبرني ماذا أكمل." : "لا نواقص حرجة — السجلات مكتملة." };
  }
  if (/تقرير رسمي|جهز.*تقرير|أنشئ تقرير|ملخص إداري|تقرير.*اليوم/.test(t)) {
    const r = readiness(db);
    const lines = [
      `تقرير ${db.settings.reportTitle}`,
      `المنشأة: ${db.settings.facility} — ${db.settings.dept} — المسؤول: ${db.settings.reportOwner}`,
      `الجاهزية ${r}% — العاملة ${db.vehicles.filter((v) => v.status === "working").length} — المتوقفة ${db.vehicles.filter((v) => v.status === "stopped").length} — المفتوحة ${openFaults(db).length}`,
      `البطاريات المحتاجة (${th}%): ${batteriesNeeding(db).map((b) => b.code).join("، ") || "لا يوجد"}`,
      `ورديات اليوم: ${db.shifts.filter((s) => s.date === today).length}/${db.shiftTemplates.length}`,
    ];
    return { intent: "report", params: {}, reply: "جهزت التقرير من 6 مصادر (العربات، الورديات، البطاريات، الأعطال، الصيانة، التوقف). خطواتي: قراءة ← تجميع ← تحليل ← صياغة. انسخه أو اعتمده من التقارير:", table: [lines] };
  }
  if (/أضف.*شركة|شركة.*جديدة|مصنعة جديدة/.test(t)) {
    const name = t.match(/باسم\s+(\S+)|شركة\s+(\S+)/)?.[1] ?? t.match(/شركة جديدة\s+(\S+)/)?.[1];
    if (!name) return { intent: "need", params: {}, reply: "ما اسم الشركة الجديدة؟ أرسله وسأجهز الإضافة للمراجعة قبل الحفظ." };
    if (db.makers.some((m) => m.name === name)) return { intent: "list", params: {}, reply: `الشركة ${name} موجودة مسبقاً — لن أكررها.` };
    return { intent: "confirm", params: {}, reply: "", pending: { kind: "add_maker", data: { name }, need: [], summary: `إضافة شركة مصنعة جديدة باسم "${name}" — بدون طرازات بعد (تضيفها من الإعدادات).`, steps: ["فحص التكرار ✓", "تجهيز السجل", "بانتظار تأكيدك", "الحفظ والتحقق"] } };
  }
  if (/أضف.*عربة|عربة جديدة/.test(t)) {
    const num = extractNumber(t);
    const makerHit = db.makers.find((m) => t.includes(m.name));
    const need: string[] = [];
    if (!num) need.push("الرقم التعريفي (مثال SH-06)");
    if (!makerHit) need.push("الشركة المصنعة");
    if (need.length) return { intent: "need", params: { num, maker: makerHit?.name }, reply: `لإضافة العربة أحتاج: ${need.join(" و ")}. أرسلهما معاً وسأعرض الملخص للتأكيد قبل الحفظ.` };
    if (db.vehicles.some((v) => v.number === num)) return { intent: "list", params: {}, reply: `الرقم ${num} مستخدم مسبقاً — اختر رقماً آخر.` };
    return { intent: "confirm", params: {}, reply: "", pending: { kind: "add_vehicle", data: { number: num!, maker: makerHit!.name }, need: [], summary: `عربة جديدة: الرقم ${num} — الشركة ${makerHit!.name} — الحالة جاهزة — الموقع مخزن الاستلام.`, steps: ["فحص الشركة ✓", "فحص الرقم ✓", "بانتظار تأكيدك", "الحفظ والتحقق"] } };
  }
  if (/أضف.*بطارية/.test(t)) {
    return { intent: "confirm", params: {}, reply: "", pending: { kind: "add_battery", data: {}, need: [], summary: `إضافة بطارية جديدة مشحونة 100% في مخزن البطاريات (الكود التالي المتاح).`, steps: ["تجهيز السجل", "بانتظار تأكيدك", "الحفظ والتحقق"] } };
  }
  if (/حد.*(الشحن|الاستبدال)|تعديل.*حد|إعدادات الشحن/.test(t)) {
    const pct = extractPct(t);
    if (pct == null) return { intent: "need", params: {}, reply: `الحد الحالي للاستبدال ${th}%. أرسل القيمة الجديدة (مثال: اجعل الحد 60%) وسأطلب تأكيدك قبل التغيير.` };
    return { intent: "confirm", params: {}, reply: "", pending: { kind: "set_threshold", data: { pct }, need: [], summary: `تغيير حد استبدال البطارية من ${th}% إلى ${pct}% — ينعكس فوراً على التنبيهات والتقارير والبطاقات.`, steps: ["قراءة الحالي ✓", "بانتظار تأكيدك", "الحفظ والتحقق"] } };
  }
  if (/أنشئ.*وردية|وردية جديدة/.test(t)) {
    const times = extractTime(t);
    const start = times[0] ?? "08:00", end = times[1] ?? "16:00";
    return { intent: "confirm", params: {}, reply: "", pending: { kind: "add_shift", data: { start, end }, need: [], summary: `وردية جديدة اليوم ${today} من ${start} إلى ${end} تشمل العربات العاملة الحالية.`, steps: ["قراءة القوالب ✓", "بانتظار تأكيدك", "الحفظ والتحقق"] } };
  }
  if (/سجل عطل|بلاغ.*عطل/.test(t)) {
    const makerHit = db.makers.find((m) => t.includes(m.name));
    const veh = makerHit ? db.vehicles.find((v) => v.maker === makerHit.name && !v.archived) : db.vehicles.find((v) => !v.archived);
    const ftype = db.faultTypes.find((x) => t.includes(x)) ?? "كهرباء";
    if (!veh) return { intent: "list", params: {}, reply: "لا عربات متاحة لتسجيل العطل." };
    return { intent: "confirm", params: {}, reply: "", pending: { kind: "add_fault", data: { vehicleId: veh.id, type: ftype, desc: t.slice(0, 80) }, need: [], summary: `تسجيل عطل (${ftype}) على ${veh.number} — الحالة مفتوح والخطورة تحتاج تدخل.`, steps: ["تحديد العربة ✓", "بانتظار تأكيدك", "الحفظ والتحقق"] } };
  }
  if (/نوع عطل جديد|أضف نوع عطل/.test(t)) {
    const name = t.match(/باسم\s+(.+)/)?.[1]?.trim() ?? t.match(/نوع عطل جديد\s+(.+)/)?.[1]?.trim();
    if (!name) return { intent: "need", params: {}, reply: "ما اسم نوع العطل الجديد؟ مثال: أضف نوع عطل جديد باسم خلل في نظام الحركة." };
    if (db.faultTypes.includes(name)) return { intent: "list", params: {}, reply: "هذا النوع موجود مسبقاً." };
    return { intent: "confirm", params: {}, reply: "", pending: { kind: "add_faulttype", data: { name }, need: [], summary: `إضافة نوع عطل جديد: "${name}" — سيظهر في نماذج البلاغات.`, steps: ["فحص التكرار ✓", "بانتظار تأكيدك", "الحفظ"] } };
  }
  if (/ابحث|اعرض.*سجل|أين/.test(t)) {
    const hit = db.vehicles.find((v) => t.includes(v.number)) ?? db.batteries.find((b) => t.includes(b.code));
    return { intent: "list", params: {}, reply: hit ? `وجدت: ${JSON.stringify(hit).slice(0, 200)}…` : "لم أجد سجلاً مطابقاً — جرّب الرقم التعريفي كاملاً (مثال SH-01 أو BAT-04)." };
  }
  return { intent: "help", params: {}, reply: "أفهم هذه الأوامر: أضف عربة / شركة / بطارية • اعرض المتوقفة • البطاريات عند الحد • سجل عطل • أنشئ وردية • جهز تقرير اليوم • قارن الأداء • اكتشف البيانات الناقصة • عدّل حد الشحن. مثال: (أضف عربة SH-06 من كازيولي) أو (سجل عطل في كرافتسمان)." };
}

export function ExecAssistant({ db, update }: { db: FleetDB; update: any }) {
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [log, setLog] = useState<Msg[]>([{ me: false, t: "أنا المساعد التنفيذي — أفهم أوامرك بالعربية وأنفذ المسموح به بعد تأكيدك. كل عملية تُسجل باسمك. جرّب: اعرض العربات المتوقفة، أو: أضف عربة SH-06 من كازيولي." }]);
  const [pending, setPending] = useState<Pending | null>(null);
  const [prov, setProv] = useState(db.settings.aiProvider);
  const [model, setModel] = useState(db.settings.aiModel);
  const me = db.users.find((u) => u.id === db.currentUser);

  const push = (m: Msg) => setLog((l) => [...l, m]);

  const execute = (p: Pending) => {
    if (p.kind === "add_vehicle" && !canDo(db, "canAdd")) return push({ me: false, t: "صلاحياتك لا تسمح بالإضافة — اطلب من مدير النظام." });
    if ((p.kind === "set_threshold") && !canDo(db, "canEdit")) return push({ me: false, t: "صلاحياتك لا تسمح بتعديل الإعدادات." });
    const id = uid("x");
    if (p.kind === "add_maker") update((d: FleetDB) => { d.makers.push({ id: uid("mk"), name: p.data.name, country: "", specs: "", batteryType: "", controller: "" }); return d; }, `مساعد: إضافة شركة ${p.data.name}`);
    if (p.kind === "add_vehicle") update((d: FleetDB) => { d.vehicles.push({ id: uid("v"), number: p.data.number, maker: p.data.maker, model: p.data.maker, location: "مخزن الاستلام", status: "ready", batteryId: null, hours: 0, lastUpdate: new Date().toISOString(), note: "أُضيفت عبر المساعد" }); return d; }, `مساعد: إضافة عربة ${p.data.number}`);
    if (p.kind === "add_battery") {
      const n = db.batteries.length + 1;
      const code = `BAT-${String(n).padStart(2, "0")}`;
      update((d: FleetDB) => { d.batteries.push({ id: uid("b"), code, location: "مخزن البطاريات", vehicleId: null, charge: 100, health: "excellent", state: "spare", lastCharge: new Date().toISOString().slice(0, 10), lastSwap: new Date().toISOString().slice(0, 10), lastBy: me?.name ?? "" }); return d; }, `مساعد: إضافة بطارية ${code}`);
      push({ me: false, t: `✓ تم الحفظ والتحقق: بطارية ${code} موجودة الآن في المخزن (100%).` });
      setPending(null); return;
    }
    if (p.kind === "set_threshold") update((d: FleetDB) => { d.settings.swapThreshold = p.data.pct; return d; }, `مساعد: حد الاستبدال إلى ${p.data.pct}%`);
    if (p.kind === "add_shift") update((d: FleetDB) => { d.shifts.unshift({ id: uid("s"), date: new Date().toISOString().slice(0, 10), type: "صباحية", start: p.data.start, end: p.data.end, supervisor: me?.name ?? "", ops: d.vehicles.filter((v) => !v.archived && v.status !== "maintenance").map((v) => ({ vehicleId: v.id, operator: "", room: v.location, startCharge: 0, endCharge: 0 })), swaps: [], faults: [], stops: [], notes: "أُنشئت عبر المساعد", deliverState: "", receiveState: "", deliveredBy: "", receivedBy: "", handoverDone: false, signature: "", createdAt: new Date().toISOString() }); return d; }, `مساعد: وردية ${p.data.start}-${p.data.end}`);
    if (p.kind === "add_fault") update((d: FleetDB) => { d.faults.unshift({ id: uid("f"), vehicleId: p.data.vehicleId, type: p.data.type, desc: p.data.desc, severity: "high", status: "open", technician: "", action: "", parts: "", startTime: new Date().toISOString().slice(0, 10), endTime: "", testResult: "", approvedReturn: false, createdAt: new Date().toISOString(), createdBy: me?.name ?? "" }); return d; }, `مساعد: عطل ${p.data.type}`);
    if (p.kind === "add_faulttype") update((d: FleetDB) => { d.faultTypes.push(p.data.name); return d; }, `مساعد: نوع عطل ${p.data.name}`);
    push({ me: false, t: `✓ تم الحفظ والتحقق من قاعدة البيانات — العملية مسجلة باسم ${me?.name} في سجل المراجعة.` });
    setPending(null);
    void id;
  };

  const send = (text: string) => {
    if (!text.trim() || busy) return;
    push({ me: true, t: text });
    setQ("");
    // fill pending needs first
    if (pending && pending.kind === "add_vehicle") {
      const num = extractNumber(text) ?? (pending.data.number as string | undefined);
      const makerHit = db.makers.find((m) => text.includes(m.name)) ?? (pending.data.maker ? { name: pending.data.maker } : undefined);
      if (num && makerHit) {
        const np: Pending = { kind: "add_vehicle", data: { number: num, maker: (makerHit as any).name }, need: [], summary: `عربة جديدة: الرقم ${num} — الشركة ${(makerHit as any).name}.`, steps: ["فحص الشركة ✓", "فحص الرقم ✓", "بانتظار تأكيدك", "الحفظ والتحقق"] };
        setPending(np);
        push({ me: false, t: `ملخص قبل التنفيذ: ${np.summary} — اضغط تأكيد للتنفيذ أو إلغاء.` });
        return;
      }
    }
    setBusy(true);
    setTimeout(() => {
      const r = parse(text, db);
      if (r.pending) { setPending(r.pending); push({ me: false, t: `خطتي (${r.pending.steps?.join(" ← ")}): ${r.pending.summary} — راجع ثم اضغط تأكيد.` }); }
      else push({ me: false, t: r.reply, table: r.table });
      setBusy(false);
    }, 350);
  };

  const saveAI = () => {
    const key = (document.getElementById("aikey") as HTMLInputElement)?.value ?? "";
    try {
      if (key) localStorage.setItem("fleet-ai-key", key.slice(0, 4) + "…محفوظ");
      else localStorage.removeItem("fleet-ai-key");
    } catch { /* ignore */ }
    update((d: FleetDB) => { d.settings.aiProvider = prov; d.settings.aiModel = model; d.settings.aiKeySet = !!key; return d; }, `إعداد مزود الذكاء ${prov}`);
    push({ me: false, t: prov === "local" ? "الوضع الحالي: المحرك المحلي — لا اتصال خارجي ولا ادعاء باستخدام أي نموذج." : `إعداد ${prov} / ${model} محفوظ ${key ? "مع مفتاح" : "بدون مفتاح"} — يبقى التنفيذ محلياً حتى ينجح اتصال حقيقي، والبنية جاهزة للربط لاحقاً. المفتاح لا يُخزن في الكود ولا يظهر لأحد.` });
  };

  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold flex items-center gap-2"><Sparkles className="size-5 text-violet-300" /> المساعد الذكي التنفيذي</h1>
      <Glass className="p-3 text-[13px] leading-6">
        <div className="flex items-center gap-1.5 font-bold"><ShieldCheck className="size-4 text-emerald-300" /> يعمل بصلاحيات: {me?.name} — {me?.role}</div>
        <div className="opacity-70">لا حذف حساس ولا اعتماد صيانة دون تأكيد وصلاحية. لا أكشف كلمات المرور أو المفاتيح. لا أختلق أرقاماً — كل إجابة من البيانات المسجلة.</div>
      </Glass>
      <Glass className="p-3 space-y-2">
        <div className="font-bold text-[13px] flex items-center gap-1.5"><KeyRound className="size-4" /> مزود الذكاء الاصطناعي</div>
        <div className="grid grid-cols-2 gap-2">
          <Field label="المزود"><select value={prov} onChange={(e) => setProv(e.target.value)} className={inputCls}>
            <option value="local">محلي (يعمل الآن)</option><option value="openai">OpenAI</option><option value="claude">Claude</option><option value="gemini">Gemini</option>
          </select></Field>
          <Field label="النموذج"><input value={model} onChange={(e) => setModel(e.target.value)} className={inputCls} placeholder="اسم النموذج" /></Field>
        </div>
        <Field label="مفتاح الاتصال (لا يُحفظ في الكود)"><input id="aikey" type="password" placeholder="الصقه هنا فقط" className={inputCls} /></Field>
        <button onClick={saveAI} className={btnGhost + " w-full"}>حفظ إعداد الذكاء</button>
        <div className="text-[12px] opacity-60">القيد الحالي: المنصة لا توفر اتصالاً مباشراً بهذه النماذج من داخل التطبيق — لذلك يعمل المساعد بالمحرك المحلي المرتبط بقاعدة بياناتك فعلياً، والإعداد أعلاه يجهز الربط المستقبلي دون أي ادعاء.</div>
      </Glass>
      <Glass className="p-3 space-y-2 min-h-[280px]">
        {log.map((m, i) => (
          <div key={i}>
            <div className={`max-w-[92%] rounded-2xl px-3 py-2 text-[13px] leading-6 ${m.me ? "mr-auto bg-sky-500/25 border border-sky-400/30" : "bg-white/[0.07] border border-white/10"}`}>{m.t}</div>
            {m.table && (
              <div className="mt-1.5 rounded-2xl border border-white/10 overflow-hidden text-[12px]">
                {m.table.map((row, j) => <div key={j} className="flex gap-2 px-3 py-1.5 border-b border-white/5 last:border-0 bg-white/[0.04]">{row.map((c, k) => <span key={k} className={k === 0 ? "font-bold" : "opacity-80"}>{c}</span>)}</div>)}
              </div>
            )}
          </div>
        ))}
        {busy && <div className="flex items-center gap-2 text-[13px] opacity-70"><Loader2 className="size-4 animate-spin" /> أحلل وأخطط…</div>}
        {pending && (
          <div className="rounded-2xl border border-violet-400/40 bg-violet-500/10 p-3 text-[13px] space-y-2">
            <div className="font-bold">بانتظار تأكيدك — {pending.summary}</div>
            <div className="text-[12px] opacity-70">{pending.steps?.join(" ← ")}</div>
            <div className="flex gap-2">
              <button onClick={() => execute(pending)} className={btnPrimary + " flex-1 flex items-center justify-center gap-1"}><CheckCircle2 className="size-4" /> تأكيد وتنفيذ</button>
              <button onClick={() => { setPending(null); push({ me: false, t: "ألغيت العملية — لم يُحفظ شيء." }); }} className={btnGhost + " flex items-center gap-1"}><XCircle className="size-4" /> إلغاء</button>
            </div>
          </div>
        )}
      </Glass>
      <div className="flex flex-wrap gap-1.5">
        {["اعرض العربات المتوقفة", "البطاريات التي وصلت للحد", "أنشئ وردية من 8 صباحا حتى 4 مساء", "جهز التقرير اليومي", "راجع البيانات الناقصة"].map((s) => (
          <button key={s} onClick={() => send(s)} className="text-[12px] rounded-full border border-white/15 bg-white/[0.06] px-3 py-1.5">{s}</button>
        ))}
      </div>
      <div className="flex gap-2 sticky bottom-20">
        <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send(q)} placeholder="اكتب أمرك بالعربية…" className={inputCls} />
        <button onClick={() => send(q)} className={btnPrimary}>إرسال</button>
      </div>
    </div>
  );
}
