// Faults + maintenance + alerts
import { useState } from "react";
import { Plus, Camera, TriangleAlert } from "lucide-react";
import { type FleetDB, type FaultSeverity, uid, fmtTime, canDo } from "./store";
import { Glass, Field, inputCls, btnPrimary, btnGhost } from "./ui";

const sevStyle: Record<FaultSeverity, string> = {
  critical: "#f43f5e", high: "#fb923c", watch: "#facc15", fixed: "#22c55e",
};
const sevLabel: Record<FaultSeverity, string> = { critical: "حرج", high: "يحتاج تدخل", watch: "تحت المتابعة", fixed: "تم الإصلاح" };

export function Faults({ db, update }: { db: FleetDB; update: any }) {
  const [show, setShow] = useState(false);
  const [f, setF] = useState<any>({ vehicleId: "v1", type: "كهرباء", desc: "", severity: "high", technician: "" });
  const [filter, setFilter] = useState("all");
  const list = db.faults.filter((x) => filter === "all" ? true : filter === "open" ? x.status !== "closed" : x.status === "closed");
  const create = () => {
    if (!f.desc) return alert("اكتب وصف المشكلة");
    update((d: FleetDB) => {
      d.faults.unshift({ id: uid("f"), vehicleId: f.vehicleId, type: f.type, desc: f.desc, severity: f.severity, status: "open", technician: f.technician, action: "", parts: "", startTime: new Date().toISOString().slice(0, 10), endTime: "", testResult: "", approvedReturn: false, createdAt: new Date().toISOString(), createdBy: d.users.find((u) => u.id === d.currentUser)?.name ?? "", photos: f.photos ?? [] });
      return d;
    }, `بلاغ عطل جديد على ${f.vehicleId}`);
    setF({ ...f, desc: "", photos: [] }); setShow(false);
  };
  const patch = (id: string, p: any, label: string) => update((d: FleetDB) => { Object.assign(d.faults.find((x) => x.id === id)!, p); return d; }, label);
  const open = db.faults.filter((x) => x.status !== "closed");
  const mttr = (() => {
    const closed = db.faults.filter((x) => x.startTime && x.endTime);
    if (!closed.length) return null;
    const hrs = closed.map((x) => (new Date(x.endTime).getTime() - new Date(x.startTime).getTime()) / 36e5).filter((n) => n >= 0);
    if (!hrs.length) return null;
    return (hrs.reduce((a, b) => a + b, 0) / hrs.length);
  })();
  // smart pattern analysis (predictive note, not diagnosis)
  const byType: Record<string, number> = {};
  db.faults.forEach((x) => { byType[x.type] = (byType[x.type] || 0) + 1; });
  const repeated = Object.entries(byType).filter(([, n]) => n >= 2);
  const byVeh: Record<string, number> = {};
  db.faults.forEach((x) => { byVeh[x.vehicleId] = (byVeh[x.vehicleId] || 0) + 1; });
  const worst = Object.entries(byVeh).sort((a, b) => b[1] - a[1])[0];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-extrabold">الأعطال والصيانة الذكية</h1>
        <button onClick={() => setShow(true)} className={btnPrimary + " flex items-center gap-1"}><Plus className="size-4" /> بلاغ</button>
      </div>
      <div className="grid grid-cols-2 gap-2.5">
        <Glass className="p-3"><div className="text-[12px] opacity-70">الأعطال المفتوحة</div><div className="text-2xl font-extrabold text-rose-400">{open.length}</div></Glass>
        <Glass className="p-3"><div className="text-[12px] opacity-70">متوسط زمن الإصلاح</div><div className="text-2xl font-extrabold">{mttr == null ? "—" : `${mttr.toFixed(1)} س`}</div>{mttr == null && <div className="text-[12px] opacity-50">لا بيانات كافية</div>}</Glass>
        <Glass className="p-3"><div className="text-[12px] opacity-70">إجمالي التوقف المسجل</div><div className="text-2xl font-extrabold tabular-nums">{db.shifts.flatMap((s) => s.stops).reduce((a, x) => a + x.minutes, 0)} د</div></Glass>
        <Glass className="p-3"><div className="text-[12px] opacity-70">أكثر عربة أعطالاً</div><div className="text-lg font-extrabold">{worst ? db.vehicles.find((v) => v.id === worst[0])?.number + ` (${worst[1]})` : "—"}</div></Glass>
      </div>
      {(repeated.length > 0 || worst) && (
        <Glass glow="#a78bfa" className="p-3.5 text-[13px] leading-6">
          <div className="font-bold">تحليل ذكي للأعطال <span className="font-normal opacity-60">(تنبؤي — ليس تشخيصاً مؤكداً)</span></div>
          {repeated.length > 0 ? <div>• تكرار ملاحظ في: {repeated.map(([k, n]) => `${k} (${n} مرات)`).join("، ")} — يُنصح بفحص وقائي مركز.</div> : <div>• لا تكرار واضح حتى الآن — استمر في التوثيق الدقيق لكل بلاغ.</div>}
          {worst && <div>• العربة {db.vehicles.find((v) => v.id === worst[0])?.number} سجلت أعلى عدد بلاغات — راقبها في الورديات القادمة.</div>}
        </Glass>
      )}
      <div className="flex gap-2 text-[12px]">
        {[["all", "الكل"], ["open", "المفتوحة"], ["closed", "المغلقة"]].map(([k, l]) => (
          <button key={k} onClick={() => setFilter(k)} className={`px-4 py-2 rounded-full border font-bold ${filter === k ? "bg-sky-500/25 border-sky-400/50" : "bg-white/5 border-white/10 opacity-70"}`}>{l}</button>
        ))}
      </div>
      <div className="grid gap-3">
        {list.map((x) => {
          const v = db.vehicles.find((vv) => vv.id === x.vehicleId);
          return (
            <Glass key={x.id} glow={sevStyle[x.severity]} className="p-3.5 space-y-2">
              <div className="flex justify-between items-start gap-2">
                <div><div className="font-extrabold">{v?.number} — {x.type}</div><div className="text-[13px] opacity-80">{x.desc}</div></div>
                <span className="text-[12px] font-bold rounded-full px-2.5 py-1 whitespace-nowrap" style={{ color: sevStyle[x.severity], border: `1px solid ${sevStyle[x.severity]}66`, background: sevStyle[x.severity] + "14" }}>{sevLabel[x.severity]}</span>
              </div>
              <div className="text-[12px] opacity-70">الحالة: {x.status === "open" ? "مفتوح" : x.status === "in_progress" ? "قيد الإصلاح" : x.status === "monitoring" ? "تحت المتابعة" : "مغلق"} • الفني: {x.technician || "—"} • {fmtTime(x.createdAt)}</div>
              {(x.photos ?? []).length > 0 && (
                <div className="flex gap-1.5 overflow-x-auto">
                  {(x.photos ?? []).map((p, i) => <img key={i} src={p} alt={`صورة العطل ${i + 1}`} className="size-16 rounded-xl object-cover border border-white/20" />)}
                </div>
              )}
              {x.status !== "closed" && (
                <div className="grid gap-1.5">
                  <input value={x.action} onChange={(e) => patch(x.id, { action: e.target.value }, "")} placeholder="الإجراء المتخذ…" className={inputCls + " !text-[12px]"} />
                  <div className="grid grid-cols-2 gap-1.5">
                    <input value={x.parts} onChange={(e) => patch(x.id, { parts: e.target.value }, "")} placeholder="قطع الغيار" className={inputCls + " !text-[12px]"} />
                    <input value={x.testResult} onChange={(e) => patch(x.id, { testResult: e.target.value }, "")} placeholder="نتيجة الاختبار" className={inputCls + " !text-[12px]"} />
                  </div>
                  <div className="grid grid-cols-3 gap-1.5 text-[12px]">
                    <button onClick={() => patch(x.id, { status: "in_progress" }, `بدء إصلاح ${x.id}`)} className={btnGhost}>بدء الإصلاح</button>
                    <button onClick={() => patch(x.id, { status: "monitoring", severity: "watch" }, `وضع تحت المتابعة ${x.id}`)} className={btnGhost}>متابعة</button>
                    <button onClick={() => { if (!x.action) return alert("سجل الإجراء المتخذ أولاً"); if (!x.testResult) return alert("لا عودة للخدمة دون توثيق نتيجة الاختبار"); if (!canDo(db, "canApprove")) return alert("تحتاج صلاحية اعتماد إعادة التشغيل"); const mins = x.startTime ? Math.max(0, Math.round((Date.now() - Date.parse(x.startTime)) / 60000)) : null; if (!confirm(`اعتماد عودة ${v?.number} للخدمة بعد الاختبار؟`)) return; patch(x.id, { status: "closed", severity: "fixed", endTime: new Date().toISOString().slice(0, 10), approvedReturn: true, downtimeMin: mins }, `إغلاق وعودة ${v?.number} للتشغيل`); }} className={btnPrimary}>إصلاح وعودة ✓</button>
                  </div>
                </div>
              )}
              {x.status === "closed" && <div className="text-[12px] text-emerald-300">✓ تم الإصلاح والاختبار {x.testResult ? `— ${x.testResult}` : ""} {x.approvedReturn ? "• معتمد للعودة" : ""}{x.downtimeMin != null ? ` • التوقف ${x.downtimeMin} د` : ""}</div>}
            </Glass>
          );
        })}
        {list.length === 0 && <Glass className="p-4 text-[13px] opacity-60">لا بلاغات هنا.</Glass>}
      </div>
      {show && (
        <div className="fixed inset-0 z-50 bg-black/60 grid place-items-center p-4" onClick={() => setShow(false)}>
          <div className="w-full max-w-sm rounded-3xl bg-[#0e1a2e] border border-white/10 p-4 space-y-3 max-h-[90dvh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="font-extrabold">بلاغ عطل جديد</div>
            <Field label="العربة"><select value={f.vehicleId} onChange={(e) => setF({ ...f, vehicleId: e.target.value })} className={inputCls}>{db.vehicles.map((v) => <option key={v.id} value={v.id}>{v.number} — {v.maker}</option>)}</select></Field>
            <div className="grid grid-cols-2 gap-2">
              <Field label="نوع العطل"><select value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })} className={inputCls}>{db.faultTypes.map((t) => <option key={t}>{t}</option>)}</select></Field>
              <Field label="الخطورة"><select value={f.severity} onChange={(e) => setF({ ...f, severity: e.target.value })} className={inputCls}><option value="critical">حرج — أحمر</option><option value="high">يحتاج تدخل — برتقالي</option><option value="watch">تحت المتابعة — أصفر</option></select></Field>
            </div>
            <Field label="وصف المشكلة"><textarea value={f.desc} onChange={(e) => setF({ ...f, desc: e.target.value })} rows={3} placeholder="اشرح ما حدث بالتفصيل…" className={inputCls} /></Field>
            <Field label="فني الصيانة"><input value={f.technician} onChange={(e) => setF({ ...f, technician: e.target.value })} placeholder="اسم الفني" className={inputCls} /></Field>
            <div className="rounded-2xl border border-dashed border-white/20 p-3 text-[12px] space-y-2">
              <label className="flex items-center gap-2 font-bold cursor-pointer"><Camera className="size-4" /> تصوير العطل وإرفاق الصور (من كاميرا الهاتف)
                <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => {
                  const files = [...(e.target.files ?? [])].slice(0, 3);
                  if (!files.length) return;
                  Promise.all(files.map((fl) => new Promise<string>((res) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.readAsDataURL(fl); }))).then((imgs) => setF({ ...f, photos: [...(f.photos ?? []), ...imgs].slice(0, 3) }));
                }} />
              </label>
              {(f.photos ?? []).length > 0 && <div className="flex gap-1.5">{(f.photos ?? []).map((p: string, i: number) => <img key={i} src={p} alt="معاينة" className="size-14 rounded-xl object-cover border border-white/20" />)}</div>}
              <div className="opacity-60">حتى 3 صور — تُحفظ مع البلاغ على الهاتف.</div>
            </div>
            <div className="flex gap-2"><button onClick={create} className={btnPrimary + " flex-1"}>حفظ البلاغ</button><button onClick={() => setShow(false)} className={btnGhost}>إلغاء</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

export function Maintenance({ db, update }: { db: FleetDB; update: any }) {
  const [show, setShow] = useState(false);
  const [m, setM] = useState({ vehicleId: "v1", kind: "فحص دوري شامل", dueDate: new Date().toISOString().slice(0, 10), tech: "" });
  const today = new Date().toISOString().slice(0, 10);
  const done = (id: string) => update((d: FleetDB) => { const x = d.maints.find((mm) => mm.id === id)!; x.status = "done"; x.doneDate = today; return d; }, `تنفيذ صيانة ${id}`);
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-extrabold">الصيانة الوقائية</h1>
        <button onClick={() => setShow(true)} className={btnPrimary + " flex items-center gap-1"}><Plus className="size-4" /> جدولة</button>
      </div>
      <div className="grid gap-3">
        {db.maints.map((x) => {
          const v = db.vehicles.find((vv) => vv.id === x.vehicleId);
          const late = x.status !== "done" && x.dueDate < today;
          return (
            <Glass key={x.id} glow={x.status === "done" ? "#22c55e" : late ? "#f43f5e" : "#f59e0b"} className="p-3.5">
              <div className="font-extrabold">{x.kind} — {v?.number}</div>
              <div className="text-[12px] opacity-70">الاستحقاق: {x.dueDate} • الفني: {x.tech || "—"} {x.notes ? `• ${x.notes}` : ""}</div>
              <div className="mt-2 flex items-center gap-2">
                <span className={`text-[12px] font-bold rounded-full px-2.5 py-1 ${x.status === "done" ? "text-emerald-300" : late ? "text-rose-300" : "text-amber-300"}`}>{x.status === "done" ? `✓ منفذة ${x.doneDate}` : late ? "⚠ متأخرة — تنبيه" : "مجدولة"}</span>
                {x.status !== "done" && <button onClick={() => done(x.id)} className={btnPrimary + " !py-1.5 !text-[12px]"}>تسجيل التنفيذ</button>}
              </div>
            </Glass>
          );
        })}
      </div>
      <Glass className="p-4">
        <div className="font-bold text-[14px]">التزام كل عربة بالصيانة</div>
        {db.vehicles.map((v) => {
          const all = db.maints.filter((x) => x.vehicleId === v.id);
          const ok = all.filter((x) => x.status === "done").length;
          const pct = all.length ? Math.round((ok / all.length) * 100) : 0;
          return <div key={v.id} className="flex items-center gap-2 mt-2 text-[12px]"><span className="w-16 font-bold">{v.number}</span><div className="flex-1 h-2 rounded-full bg-white/10 overflow-hidden"><div className="h-full rounded-full" style={{ width: `${pct}%`, background: pct >= 70 ? "#22c55e" : "#f59e0b" }} /></div><span className="tabular-nums w-10">{all.length ? pct + "%" : "—"}</span></div>;
        })}
        <div className="text-[12px] opacity-50 mt-1">الشرطة (—) تعني لا مهام مجدولة كافية للحساب.</div>
      </Glass>
      {show && (
        <div className="fixed inset-0 z-50 bg-black/60 grid place-items-center p-4" onClick={() => setShow(false)}>
          <div className="w-full max-w-sm rounded-3xl bg-[#0e1a2e] border border-white/10 p-4 space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="font-extrabold">جدولة صيانة</div>
            <Field label="العربة"><select value={m.vehicleId} onChange={(e) => setM({ ...m, vehicleId: e.target.value })} className={inputCls}>{db.vehicles.map((v) => <option key={v.id} value={v.id}>{v.number}</option>)}</select></Field>
            <Field label="نوع الصيانة"><select value={m.kind} onChange={(e) => setM({ ...m, kind: e.target.value })} className={inputCls}>{db.maintKinds.map((t) => <option key={t}>{t}</option>)}</select></Field>
            <Field label="تاريخ الاستحقاق"><input type="date" value={m.dueDate} onChange={(e) => setM({ ...m, dueDate: e.target.value })} className={inputCls} /></Field>
            <Field label="الفني"><input value={m.tech} onChange={(e) => setM({ ...m, tech: e.target.value })} className={inputCls} /></Field>
            <div className="flex gap-2"><button onClick={() => { update((d: FleetDB) => { d.maints.push({ id: uid("m"), vehicleId: m.vehicleId, kind: m.kind, dueDate: m.dueDate, doneDate: "", status: m.dueDate < today ? "overdue" : "scheduled", tech: m.tech, notes: "" }); return d; }, "جدولة صيانة"); setShow(false); }} className={btnPrimary + " flex-1"}>حفظ</button><button onClick={() => setShow(false)} className={btnGhost}>إلغاء</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

export function Alerts({ db, go }: { db: FleetDB; go: (t: string, id?: string) => void }) {
  const [sev, setSev] = useState("all");
  const today = new Date().toISOString().slice(0, 10);
  const items: { id: string; level: "critical" | "high" | "watch"; title: string; detail: string; target: string; vid?: string }[] = [];
  const al = (db as any).settings?.alerts ?? {};
  const low = (db as any).settings?.lowAlert ?? 30;
  const thr = (db as any).settings?.swapThreshold ?? 50;
  if (al.lowBatt !== false) db.batteries.filter((b) => !b.archived && b.charge <= low).forEach((b) => items.push({ id: "b" + b.id, level: "critical", title: `بطارية ${b.code} منخفضة جداً (${b.charge}%)`, detail: b.location, target: "batteries" }));
  if (al.lowBatt !== false) db.batteries.filter((b) => !b.archived && b.charge > low && b.charge <= thr).forEach((b) => items.push({ id: "b2" + b.id, level: "high", title: `بطارية ${b.code} وصلت حد الاستبدال (${b.charge}%)`, detail: `استبدل عند ${thr}% ولا تنتظر النفاد`, target: "batteries" }));
  if (al.stopped !== false) db.vehicles.filter((v) => !v.archived && v.status === "stopped").forEach((v) => items.push({ id: "s" + v.id, level: "high", title: `العربة ${v.number} متوقفة`, detail: v.location, target: "vehicle", vid: v.id }));
  if (al.critical !== false) db.faults.filter((f) => f.severity === "critical" && f.status !== "closed").forEach((f) => items.push({ id: "f" + f.id, level: "critical", title: `عطل حرج — ${db.vehicles.find((v) => v.id === f.vehicleId)?.number}: ${f.type}`, detail: f.desc, target: "faults" }));
  if (al.maint !== false) db.maints.filter((m) => m.status !== "done" && m.dueDate <= today).forEach((m) => items.push({ id: "m" + m.id, level: "high", title: `صيانة مستحقة: ${m.kind} — ${db.vehicles.find((v) => v.id === m.vehicleId)?.number}`, detail: m.dueDate, target: "maint" }));
  if (al.shiftMiss !== false && db.shifts.filter((s) => s.date === today).length < 3) items.push({ id: "sh", level: "watch", title: `تسجيل الورديات ناقص اليوم (${db.shifts.filter((s) => s.date === today).length}/3)`, detail: "سجل الورديات المتبقية", target: "shifts" });
  if (al.handover !== false && db.shifts.some((s) => !s.handoverDone)) items.push({ id: "ho", level: "watch", title: "تسليم واستلام غير مكتمل", detail: `${db.shifts.filter((s) => !s.handoverDone).length} ورديات بانتظار الاعتماد`, target: "shifts" });
  if (al.spare !== false && !db.batteries.some((b) => !b.archived && !b.vehicleId && b.charge >= 80)) items.push({ id: "sp", level: "high", title: "لا توجد بطارية احتياطية جاهزة (≥80%)", detail: "اشحن الاحتياطية فوراً", target: "batteries" });
  if (al.stopped !== false) db.connEvents.filter((e) => e.kind === "انقطاع").slice(0, 5).forEach((e) => items.push({ id: "c" + e.id, level: "high", title: `انقطاع اتصال ${db.vehicles.find((v) => v.id === e.vehicleId)?.number}`, detail: e.detail, target: "connect" }));
  if (al.critical !== false) db.links.filter((l) => l.status === "failed").forEach((l) => items.push({ id: "cf" + l.vehicleId, level: "critical", title: `فشل اتصال ${db.vehicles.find((v) => v.id === l.vehicleId)?.number}`, detail: "يحتاج إعادة اقتران", target: "connect", vid: undefined }));
  const filtered = items.filter((x) => sev === "all" ? true : x.level === sev);
  const col = (l: string) => l === "critical" ? "#f43f5e" : l === "high" ? "#fb923c" : "#facc15";
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold flex items-center gap-2"><TriangleAlert className="size-5 text-amber-300" /> التنبيهات — {items.length}</h1>
      <div className="flex gap-2 text-[12px]">
        {[["all", `الكل (${items.length})`], ["critical", "حرجة"], ["high", "تحتاج تدخل"], ["watch", "متابعة"]].map(([k, l]) => (
          <button key={k} onClick={() => setSev(k)} className={`px-4 py-2 rounded-full border font-bold ${sev === k ? "bg-sky-500/25 border-sky-400/50" : "bg-white/5 border-white/10 opacity-70"}`}>{l}</button>
        ))}
      </div>
      <div className="grid gap-2.5">
        {filtered.map((a) => (
          <Glass key={a.id} glow={col(a.level)} className="p-3.5" onClick={() => go(a.target, a.vid)}>
            <div className="font-bold text-[14px]">{a.title}</div>
            <div className="text-[12px] opacity-70">{a.detail}</div>
            <div className="text-[12px] mt-1 font-bold" style={{ color: col(a.level) }}>{a.level === "critical" ? "● حرج" : a.level === "high" ? "● يحتاج تدخل" : "● متابعة"}</div>
          </Glass>
        ))}
        {filtered.length === 0 && <Glass className="p-4 text-[13px] opacity-60">لا تنبيهات بهذا التصنيف — الوضع مطمئن.</Glass>}
      </div>
      <div className="text-[12px] opacity-50">تُبنى التنبيهات تلقائياً من البيانات المسجلة فعلياً فقط.</div>
    </div>
  );
}
