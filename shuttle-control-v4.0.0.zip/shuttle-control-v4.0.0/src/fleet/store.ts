// Shuttle Fleet Store — local-first, autosave, backup/restore
import { useEffect, useMemo, useState } from "react";

export type VehicleStatus = "ready" | "working" | "stopped" | "maintenance";
export type BatteryHealth = "excellent" | "good" | "fair" | "poor" | "fault";
export type BatteryState = "mounted" | "spare" | "charging" | "full" | "needs_charge" | "inspect" | "fault";
export type FaultSeverity = "critical" | "high" | "watch" | "fixed";
export type FaultStatus = "open" | "in_progress" | "monitoring" | "closed";

export interface Vehicle {
  id: string;
  number: string;
  maker: string;
  model: string;
  location: string;
  status: VehicleStatus;
  batteryId: string | null;
  hours: number;
  lastUpdate: string;
  note?: string;
  archived?: boolean;
  image?: string;
  assetNo?: string;
  specs?: string;
  custom?: Record<string, string>;
  serialNo?: string;
  operationDate?: string;
  trial?: boolean;
  accessoryIds?: string[];
}
export interface Battery {
  id: string;
  code: string;
  location: string;
  vehicleId: string | null;
  charge: number;
  health: BatteryHealth;
  state: BatteryState;
  lastCharge: string;
  lastSwap: string;
  lastBy: string;
  typeId?: string;
  assetNo?: string;
  archived?: boolean;
}
export interface ShiftOp { vehicleId: string; operator: string; room: string; startCharge: number; endCharge: number; }
export interface Shift {
  id: string; date: string; type: "صباحية" | "مسائية" | "ليلية";
  start: string; end: string; supervisor: string;
  ops: ShiftOp[]; swaps: { batteryId: string; from: string; to: string; by: string; time: string }[];
  faults: string[]; stops: { vehicleId: string; minutes: number; reason: string }[];
  notes: string; deliverState: string; receiveState: string;
  deliveredBy: string; receivedBy: string; handoverDone: boolean; signature: string;
  createdAt: string;
}
export interface Fault {
  id: string; vehicleId: string; type: string; desc: string;
  severity: FaultSeverity; status: FaultStatus;
  technician: string; action: string; parts: string;
  startTime: string; endTime: string; testResult: string; approvedReturn: boolean;
  createdAt: string; createdBy: string;
  downtimeMin?: number | null;
  photos?: string[];
}
export interface Maint {
  id: string; vehicleId: string; kind: string; dueDate: string;
  doneDate: string; status: "scheduled" | "done" | "overdue";
  tech: string; notes: string;
}
export interface Cycle { id: string; batteryCode: string; batteryId?: string; kind: "charge" | "discharge"; startPct: number; endPct: number; startedAt: string; endedAt: string; by: string; }
export interface Activity { id: string; user: string; action: string; time: string; details: string; }
export interface AppUser { id: string; name: string; role: string; active?: boolean; pages?: string[]; canAdd?: boolean; canEdit?: boolean; canDelete?: boolean; canApprove?: boolean; canReport?: boolean; passHash?: string; }
export interface Maker { id: string; name: string; country: string; specs: string; batteryType: string; controller: string; image?: string; protocol?: string; sdk?: string; authReq?: string; androidOk?: string; gatewayNeeded?: string; docs?: string; }
export type ConnType = "bluetooth" | "ble" | "wifi" | "rf" | "vendor" | "gateway" | "api" | "none";
export type ConnStatus = "connected" | "disconnected" | "searching" | "failed" | "nodata" | "repair";
export interface DeviceLink { vehicleId: string; connType: ConnType; deviceName: string; deviceId: string; auth: string; autoReconnect: boolean; signal?: number; status: ConnStatus; lastConnect: string; lastReading: string; notes?: string; }
export interface LiveReading { id: string; vehicleId: string; time: string; source: "live" | "manual" | "old"; batteryPct?: number | null; opMode?: string; running?: string; hours?: number | null; moving?: string; temp?: string; controller?: string; alarms?: string; errors?: string; }
export interface ConnEvent { id: string; vehicleId: string; time: string; kind: string; detail: string; }
export interface BattType { id: string; name: string; capacity: string; }
export interface Accessory { id: string; name: string; kind: string; code: string; }
export interface ShiftTemplate { id: string; name: string; start: string; end: string; supervisors: string; required: string; }
export interface RoleDef { id: string; name: string; pages: string[]; canAdd: boolean; canEdit: boolean; canDelete: boolean; canApprove: boolean; canReport: boolean; }
export interface CustomField { id: string; label: string; target: string; enabled: boolean; }
export interface AppSettings {
  facility: string; dept: string; reportOwner: string; reportTitle: string;
  sections: { summary: boolean; vehicles: boolean; batteries: boolean; faults: boolean; shifts: boolean; advice: boolean };
  exportFormat: string; reportTime: string;
  swapThreshold: number; lowAlert: number;
  alerts: { lowBatt: boolean; stopped: boolean; critical: boolean; maint: boolean; shiftMiss: boolean; handover: boolean; spare: boolean };
  alertLevels: Record<string, string>;
  aiProvider: string; aiModel: string; aiKeySet: boolean;
  connMode: string;
  reportScope: string;
}

export interface FleetDB {
  vehicles: Vehicle[];
  batteries: Battery[];
  shifts: Shift[];
  faults: Fault[];
  maints: Maint[];
  activity: Activity[];
  users: AppUser[];
  currentUser: string;
  seededAt: string;
  makers: Maker[];
  battTypes: BattType[];
  accessories: Accessory[];
  shiftTemplates: ShiftTemplate[];
  faultTypes: string[];
  maintKinds: string[];
  spareParts: string[];
  technicians: string[];
  roles: RoleDef[];
  customFields: CustomField[];
  settings: AppSettings;
  archivedNote?: string;
  cycles: Cycle[];
  links: DeviceLink[];
  readings: LiveReading[];
  connEvents: ConnEvent[];
}

const KEY = "shuttle-fleet-v1";
export const APP_VERSION = "2.1.0";
export const APP_UPDATED = "2026-11-14";
const todayISO = () => new Date().toISOString().slice(0, 10);
const nowISO = () => new Date().toISOString();

export function defaultSettings(): AppSettings {
  return {
    facility: "المخازن المبردة", dept: "إدارة التشغيل", reportOwner: "مدير التشغيل",
    reportTitle: "تقرير أسطول الشاتل كار بالمخازن المبردة",
    sections: { summary: true, vehicles: true, batteries: true, faults: true, shifts: true, advice: true },
    exportFormat: "txt", reportTime: "20:00",
    swapThreshold: 50, lowAlert: 30,
    alerts: { lowBatt: true, stopped: true, critical: true, maint: true, shiftMiss: true, handover: true, spare: true },
    alertLevels: { lowBatt: "high", stopped: "high", critical: "critical", maint: "high", shiftMiss: "watch", handover: "watch", spare: "high" },
    aiProvider: "local", aiModel: "fleet-exec-v1", aiKeySet: false,
    connMode: "readonly",
    reportScope: "fleet",
  };
}
export function defaultMakers(): Maker[] {
  return [
    { id: "mk1", name: "كازيولي", country: "إيطاليا", specs: "شاتل تخزين مبرد — رفوف عالية", batteryType: "ليثيوم 48V", controller: "Cazzoli RC", protocol: "وثائق الشركة المصنعة مطلوبة — لم يثبت بروتوكول بعد", sdk: "يحدد بعد توفر الوثائق", authReq: "اقتران الجهاز + تأكيد هوية العربة", androidOk: "يُختبر على أندرويد عند توفر جهاز", gatewayNeeded: "بوابة صناعية عند الحاجة فقط", docs: "اطلب دليل الاتصال من الوكيل" },
    { id: "mk2", name: "كرافتسمان", country: "تحت التجربة", specs: "وحدة تجريبية — تقييم أداء", batteryType: "ليثيوم 48V", controller: "Craftsman RC", protocol: "وثائق الشركة المصنعة مطلوبة — لم يثبت بروتوكول بعد", sdk: "يحدد بعد توفر الوثائق", authReq: "اقتران الجهاز + تأكيد هوية العربة", androidOk: "يُختبر على أندرويد عند توفر جهاز", gatewayNeeded: "بوابة صناعية عند الحاجة فقط", docs: "اطلب دليل الاتصال من الوكيل" },
    { id: "mk3", name: "أكمي", country: "—", specs: "ACMI Shuttle", batteryType: "ليثيوم 48V", controller: "ACMI RC + تابلت", protocol: "وثائق الشركة المصنعة مطلوبة — لم يثبت بروتوكول بعد", sdk: "يحدد بعد توفر الوثائق", authReq: "اقتران الجهاز + تأكيد هوية العربة", androidOk: "يُختبر على أندرويد عند توفر جهاز", gatewayNeeded: "بوابة صناعية عند الحاجة فقط", docs: "اطلب دليل الاتصال من الوكيل" },
  ];
}

function seed(): FleetDB {
  const t = todayISO();
  const vehicles: Vehicle[] = [
    { id: "v1", number: "SH-01", maker: "كازيولي", model: "Cazzoli Shuttle — إيطالي", location: "غرفة التبريد A", status: "working", batteryId: "b1", hours: 0, lastUpdate: nowISO(), note: "", serialNo: "", operationDate: t, trial: false, accessoryIds: ["ac1"] },
    { id: "v2", number: "SH-02", maker: "كازيولي", model: "Cazzoli Shuttle — إيطالي", location: "غرفة التبريد B", status: "ready", batteryId: "b3", hours: 0, lastUpdate: nowISO(), serialNo: "", operationDate: t, trial: false, accessoryIds: [] },
    { id: "v3", number: "SH-03", maker: "كازيولي", model: "Cazzoli Shuttle — إيطالي", location: "منطقة الشحن", status: "maintenance", batteryId: null, hours: 0, lastUpdate: nowISO(), note: "فحص دوري", serialNo: "", operationDate: t, trial: false, accessoryIds: [] },
    { id: "v4", number: "SH-T1", maker: "كرافتسمان", model: "Craftsman — تحت التجربة", location: "غرفة التبريد C", status: "working", batteryId: "b5", hours: 0, lastUpdate: nowISO(), serialNo: "", operationDate: t, trial: true, accessoryIds: [] },
    { id: "v5", number: "SH-A1", maker: "أكمي", model: "ACMI Shuttle", location: "مخزن الاستلام", status: "stopped", batteryId: "b7", hours: 0, lastUpdate: nowISO(), note: "بانتظار مشغل", serialNo: "", operationDate: t, trial: false, accessoryIds: ["ac2"] },
  ];
  const batteries: Battery[] = [
    { id: "b1", code: "BAT-01", location: "مركبة على SH-01", vehicleId: "v1", charge: 82, health: "good", state: "mounted", lastCharge: t, lastSwap: t, lastBy: "أحمد" },
    { id: "b2", code: "BAT-02", location: "محطة الشحن — خارج غرف التبريد", vehicleId: null, charge: 100, health: "excellent", state: "full", lastCharge: t, lastSwap: t, lastBy: "أحمد" },
    { id: "b3", code: "BAT-03", location: "مركبة على SH-02", vehicleId: "v2", charge: 64, health: "good", state: "mounted", lastCharge: t, lastSwap: t, lastBy: "كريم" },
    { id: "b4", code: "BAT-04", location: "محطة الشحن — خارج غرف التبريد", vehicleId: null, charge: 35, health: "fair", state: "needs_charge", lastCharge: t, lastSwap: t, lastBy: "كريم" },
    { id: "b5", code: "BAT-05", location: "مركبة على SH-T1", vehicleId: "v4", charge: 71, health: "good", state: "mounted", lastCharge: t, lastSwap: t, lastBy: "سامي" },
    { id: "b6", code: "BAT-06", location: "محطة الشحن — خارج غرف التبريد", vehicleId: null, charge: 58, health: "good", state: "charging", lastCharge: t, lastSwap: t, lastBy: "سامي" },
    { id: "b7", code: "BAT-07", location: "مركبة على SH-A1", vehicleId: "v5", charge: 48, health: "fair", state: "mounted", lastCharge: t, lastSwap: t, lastBy: "طارق" },
    { id: "b8", code: "BAT-08", location: "الفحص الفني", vehicleId: null, charge: 20, health: "poor", state: "inspect", lastCharge: t, lastSwap: t, lastBy: "فني الصيانة" },
    { id: "b9", code: "BAT-09", location: "احتياطية — مخزن البطاريات", vehicleId: null, charge: 92, health: "excellent", state: "spare", lastCharge: t, lastSwap: t, lastBy: "أحمد" },
    { id: "b10", code: "BAT-10", location: "احتياطية — مخزن البطاريات", vehicleId: null, charge: 88, health: "good", state: "spare", lastCharge: t, lastSwap: t, lastBy: "أحمد" },
  ];
  return {
    vehicles, batteries,
    shifts: [],
    faults: [
      { id: "f-seed-1", vehicleId: "v3", type: "نظام التوجيه", desc: "ملاحظة أولية من الفحص الدوري — تحتاج توثيق فني", severity: "watch", status: "monitoring", technician: "فني الصيانة", action: "", parts: "", startTime: t, endTime: "", testResult: "", approvedReturn: false, createdAt: nowISO(), createdBy: "النظام" },
    ],
    maints: [
      { id: "m1", vehicleId: "v1", kind: "فحص دوري شامل", dueDate: t, doneDate: "", status: "scheduled", tech: "فني الصيانة", notes: "فحص العربة وأجهزة التحكم" },
      { id: "m2", vehicleId: "v2", kind: "فحص البطاريات", dueDate: t, doneDate: "", status: "scheduled", tech: "فني الصيانة", notes: "" },
      { id: "m3", vehicleId: "v3", kind: "صيانة وقائية", dueDate: t, doneDate: "", status: "scheduled", tech: "فني الصيانة", notes: "العربة متوقفة للفحص" },
    ],
    activity: [{ id: "a0", user: "النظام", action: "تهيئة الأسطول", time: nowISO(), details: "تم تسجيل 5 عربات و10 بطاريات كبيانات أولية" }],
    users: [
      { id: "u1", name: "مدير التشغيل", role: "مدير النظام", active: true, canAdd: true, canEdit: true, canDelete: true, canApprove: true, canReport: true },
      { id: "u2", name: "مشرف الوردية", role: "مشرف الوردية", active: true, canAdd: true, canEdit: true, canDelete: false, canApprove: false, canReport: true },
      { id: "u3", name: "فني الصيانة", role: "فني الصيانة", active: true, canAdd: true, canEdit: true, canDelete: false, canApprove: true, canReport: false },
      { id: "u4", name: "مشغل الشاتل", role: "مشغل الشاتل كار", active: true, canAdd: false, canEdit: false, canDelete: false, canApprove: false, canReport: false },
    ],
    currentUser: "u1",
    seededAt: nowISO(),
    makers: defaultMakers(),
    battTypes: [{ id: "bt1", name: "ليثيوم 48V قياسي", capacity: "100Ah" }],
    accessories: [{ id: "ac1", name: "جهاز تحكم Cazzoli RC", kind: "جهاز تحكم", code: "RC-01" }, { id: "ac2", name: "تابلت ACME", kind: "تابلت", code: "TAB-ACME-01" }],
    shiftTemplates: [
      { id: "st1", name: "صباحية", start: "08:00", end: "16:00", supervisors: "مشرف الوردية", required: "المشرف + المشغل + شحن البداية والنهاية + التسليم" },
      { id: "st2", name: "مسائية", start: "16:00", end: "00:00", supervisors: "مشرف الوردية", required: "المشرف + المشغل + شحن البداية والنهاية + التسليم" },
      { id: "st3", name: "ليلية", start: "00:00", end: "08:00", supervisors: "مشرف الوردية", required: "المشرف + المشغل + شحن البداية والنهاية + التسليم" },
    ],
    faultTypes: ["كهرباء", "بطارية", "توجيه", "تبريد", "ميكانيكا", "تحكم", "أخرى"],
    maintKinds: ["فحص دوري شامل", "فحص البطاريات", "فحص أجهزة التحكم", "فحص العربة", "صيانة وقائية"],
    spareParts: ["فيوز", "حساس", "كابل شحن", "عجلة توجيه"],
    technicians: ["فني الصيانة"],
    roles: [
      { id: "r1", name: "مدير النظام", pages: ["all"], canAdd: true, canEdit: true, canDelete: true, canApprove: true, canReport: true },
      { id: "r2", name: "مدير التشغيل", pages: ["home", "fleet", "shifts", "reports", "analytics"], canAdd: true, canEdit: true, canDelete: false, canApprove: true, canReport: true },
      { id: "r3", name: "مشرف الوردية", pages: ["home", "shifts", "batteries"], canAdd: true, canEdit: true, canDelete: false, canApprove: false, canReport: true },
      { id: "r4", name: "فني الصيانة", pages: ["faults", "maint", "batteries"], canAdd: true, canEdit: true, canDelete: false, canApprove: true, canReport: false },
      { id: "r5", name: "مشغل الشاتل كار", pages: ["home", "fleet"], canAdd: false, canEdit: false, canDelete: false, canApprove: false, canReport: false },
    ],
    customFields: [],
    settings: defaultSettings(),
    cycles: [],
    links: [
      { vehicleId: "v1", connType: "none", deviceName: "", deviceId: "", auth: "غير موثق", autoReconnect: true, status: "disconnected", lastConnect: "", lastReading: "" },
      { vehicleId: "v2", connType: "none", deviceName: "", deviceId: "", auth: "غير موثق", autoReconnect: true, status: "disconnected", lastConnect: "", lastReading: "" },
      { vehicleId: "v3", connType: "none", deviceName: "", deviceId: "", auth: "غير موثق", autoReconnect: true, status: "disconnected", lastConnect: "", lastReading: "" },
      { vehicleId: "v4", connType: "none", deviceName: "", deviceId: "", auth: "غير موثق", autoReconnect: true, status: "disconnected", lastConnect: "", lastReading: "" },
      { vehicleId: "v5", connType: "none", deviceName: "", deviceId: "", auth: "غير موثق", autoReconnect: true, status: "disconnected", lastConnect: "", lastReading: "" },
    ],
    readings: [],
    connEvents: [],
  };
}

export function loadDB(): FleetDB {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) { const s = seed(); localStorage.setItem(KEY, JSON.stringify(s)); return s; }
    const old = JSON.parse(raw) as FleetDB;
    const fresh = seed();
    // migrate: keep every old record, fill only missing setting tables
    const merged: FleetDB = {
      ...fresh, ...old,
      vehicles: old.vehicles ?? fresh.vehicles,
      batteries: old.batteries ?? fresh.batteries,
      shifts: old.shifts ?? [], faults: (old.faults ?? []).map((f: any) => ({ photos: [], ...f })), maints: old.maints ?? [],
      activity: old.activity ?? [], users: (old.users ?? fresh.users).map((u: any) => ({ active: true, canAdd: true, canEdit: true, canDelete: false, canApprove: false, canReport: true, ...u })),
      makers: (old as any).makers ?? fresh.makers,
      battTypes: (old as any).battTypes ?? fresh.battTypes,
      accessories: (() => { const a = (old as any).accessories ?? fresh.accessories; return a.some((x: any) => x.id === "ac2") ? a : [...a, { id: "ac2", name: "تابلت ACME", kind: "تابلت", code: "TAB-ACME-01" }]; })(),
      shiftTemplates: (old as any).shiftTemplates ?? fresh.shiftTemplates,
      faultTypes: (old as any).faultTypes ?? fresh.faultTypes,
      maintKinds: (old as any).maintKinds ?? fresh.maintKinds,
      spareParts: (old as any).spareParts ?? fresh.spareParts,
      technicians: (old as any).technicians ?? fresh.technicians,
      roles: (old as any).roles ?? fresh.roles,
      customFields: (old as any).customFields ?? [],
      cycles: (old as any).cycles ?? [],
      settings: { ...fresh.settings, ...((old as any).settings ?? {}), alerts: { ...(fresh.settings.alerts as any), ...(((old as any).settings ?? {}).alerts ?? {}) } },
      links: (old as any).links ?? fresh.links,
      readings: (old as any).readings ?? [],
      connEvents: (old as any).connEvents ?? [],
    };
    return merged;
  } catch { return seed(); }
}
export function saveDB(db: FleetDB) {
  try { localStorage.setItem(KEY, JSON.stringify(db)); } catch { /* full */ }
}

export function useFleet() {
  const [db, setDb] = useState<FleetDB>(() => loadDB());
  useEffect(() => { saveDB(db); }, [db]);
  const update = (fn: (d: FleetDB) => FleetDB, label?: string) => {
    setDb((prev) => {
      const next = fn(structuredClone(prev));
      if (label) {
        const me = next.users.find((u) => u.id === next.currentUser)?.name ?? "مستخدم";
        next.activity = [{ id: "a" + Date.now(), user: me, action: label, time: nowISO(), details: "" }, ...next.activity].slice(0, 200);
      }
      queueMicrotask(() => saveDB(next));
      return next;
    });
  };
  return { db, update, setDb };
}

// helpers
export const statusLabel: Record<VehicleStatus, string> = { ready: "جاهزة", working: "عاملة", stopped: "متوقفة", maintenance: "تحت الصيانة" };
export const statusColor: Record<VehicleStatus, string> = {
  ready: "#22c55e", working: "#38bdf8", stopped: "#f59e0b", maintenance: "#f43f5e",
};
export const battStateLabel: Record<BatteryState, string> = {
  mounted: "مركبة", spare: "احتياطية", charging: "قيد الشحن", full: "مكتملة الشحن",
  needs_charge: "تحتاج شحن", inspect: "تحت الفحص", fault: "بها عطل",
};
export const severityLabel: Record<FaultSeverity, string> = { critical: "حرج", high: "يحتاج تدخل", watch: "تحت المتابعة", fixed: "تم الإصلاح" };

export function readiness(db: FleetDB) {
  const total = db.vehicles.length || 1;
  const ready = db.vehicles.filter((v) => v.status === "ready" || v.status === "working").length;
  return Math.round((ready / total) * 100);
}
export function swapThreshold(db: FleetDB) { return db.settings?.swapThreshold ?? 50; }
export function openFaults(db: FleetDB) { return db.faults.filter((f) => f.status !== "closed"); }
export function batteriesNeeding(db: FleetDB) { const t = swapThreshold(db); return db.batteries.filter((b) => !b.archived && (b.charge <= t || b.state === "needs_charge" || b.state === "fault")); }
export function activeVehicles(db: FleetDB) { return db.vehicles.filter((v) => !v.archived); }
export const connTypeLabel: Record<string, string> = { bluetooth: "بلوتوث", ble: "بلوتوث منخفض الطاقة BLE", wifi: "واي فاي", rf: "راديو RF", vendor: "وحدة الشركة المصنعة", gateway: "بوابة صناعية", api: "API / SDK رسمي", none: "غير محدد" };
export const connStatusLabel: Record<string, string> = { connected: "متصل", disconnected: "غير متصل", searching: "جارٍ البحث", failed: "فشل الاتصال", nodata: "متصل دون بيانات", repair: "يحتاج إعادة اقتران" };
export const connStatusColor: Record<string, string> = { connected: "#22c55e", disconnected: "#64748b", searching: "#38bdf8", failed: "#f43f5e", nodata: "#f59e0b", repair: "#fb923c" };
export function disconnectedVehicles(db: FleetDB) { return db.vehicles.filter((v) => { const l = db.links.find((x) => x.vehicleId === v.id); return !l || l.status !== "connected"; }); }
export const sourceLabel: Record<string, string> = { live: "بيانات مباشرة من الشاتل", manual: "بيانات مسجلة يدوياً", old: "بيانات قديمة لم تُحدّث" };
export function canDo(db: FleetDB, perm: "canAdd" | "canEdit" | "canDelete" | "canApprove" | "canReport"): boolean {
  const me = db.users.find((u) => u.id === db.currentUser);
  if (!me || me.active === false) return false;
  if (me.role === "مدير النظام") return true;
  const role = db.roles.find((r) => r.name === me.role);
  if (role) return !!role[perm];
  return !!(me as any)[perm];
}
export function shiftCoverage(db: FleetDB, date: string) {
  const list = db.shifts.filter((s) => s.date === date);
  const expected = Math.max(1, (db.shiftTemplates ?? []).length || 3);
  return { count: list.length, expected, pct: Math.round((list.length / expected) * 100) };
}
export function currentShiftName(d = new Date()): string {
  const h = d.getHours();
  if (h >= 7 && h < 15) return "صباحية";
  if (h >= 15 && h < 23) return "مسائية";
  return "ليلية";
}
export function useNow() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => { const i = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(i); }, []);
  return now;
}
export const uid = (p: string) => p + "-" + Math.random().toString(36).slice(2, 8);
export function fmtTime(iso: string) {
  try { return new Date(iso).toLocaleString("ar-EG", { day: "numeric", month: "numeric", hour: "2-digit", minute: "2-digit" }); } catch { return iso; }
}
export function useMemoDB(db: FleetDB) {
  return useMemo(() => ({
    readiness: readiness(db),
    open: openFaults(db),
    needBatt: batteriesNeeding(db),
    totalHours: db.shifts.reduce((a, s) => a + s.ops.length * 8, 0),
  }), [db]);
}
