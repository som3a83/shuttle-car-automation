// Arabic user guide + install + backup + honest test report
import { BookOpen, Download, Smartphone, ShieldCheck, ClipboardCheck, Activity } from "lucide-react";
import { useState } from "react";
import { type FleetDB, APP_VERSION, APP_UPDATED } from "./store";
import { Glass, btnPrimary, btnGhost } from "./ui";

export function Guide({ db }: { db: FleetDB }) {
  const [checks, setChecks] = useState<[string, string][] | null>(null);
  const runChecks = () => {
    const out: [string, string][] = [];
    const nums = db.vehicles.map((v) => v.number);
    out.push(["عدم تكرار الأرقام التعريفية", new Set(nums).size === nums.length ? "سليم" : "مكرر موجود"]);
    const codes = db.batteries.map((b) => b.code);
    out.push(["عدم تكرار أكواد البطاريات", new Set(codes).size === codes.length ? "سليم" : "مكرر موجود"]);
    out.push(["كل بطاري مركبة موجودة فعلاً", db.vehicles.every((v) => !v.batteryId || db.batteries.some((b) => b.id === v.batteryId)) ? "سليم" : "مرجع مفقود"]);
    out.push(["كل روابط الاتصال تخص عربات موجودة", db.links.every((l) => db.vehicles.some((v) => v.id === l.vehicleId)) ? "سليم" : "مرجع مفقود"]);
    out.push(["عمليات الورديات تخص عربات موجودة", db.shifts.every((s) => s.ops.every((o) => db.vehicles.some((v) => v.id === o.vehicleId))) ? "سليم" : "مرجع مفقود"]);
    out.push(["حد الاستبدال ضمن 10–90%", ((db as any).settings?.swapThreshold ?? 50) >= 10 && ((db as any).settings?.swapThreshold ?? 50) <= 90 ? "سليم" : "خارج النطاق"]);
    out.push(["عدد قوالب الورديات ≥ 1", (db.shiftTemplates ?? []).length >= 1 ? "سليم" : "ناقص"]);
    setChecks(out);
  };
  const rows: [string, string, string][] = [
    ["إضافة وتعديل وأرشفة العربات", "ناجح", "تم من الإعدادات ← العربات، والأرشفة تحفظ السجل"],
    ["إدارة البطاريات والشحن والاستبدال", "ناجح", `حد الاستبدال الحالي ${(db as any).settings?.swapThreshold ?? 50}% وقابل للتعديل`],
    ["تسجيل الورديات والتسليم والاستلام", "ناجح", "الإغلاق يتطلب الحالة النهائية أو سبب عدم التسجيل"],
    ["تسجيل الأعطال والصيانة والاختبار والاعتماد", "ناجح", "الإغلاق يتطلب نتيجة اختبار واعتماد عودةة"],
    ["تصوير الأعطال وإرفاق الصور", "ناجح", "حتى 3 صور من كاميرا الهاتف تُحفظ مع البلاغ"],
    ["تسجيل التوقفات والتبديلات داخل الوردية", "ناجح", "تُسجل بالمدة والسبب والمسؤول والوقت"],
    ["التقارير والتصدير والمشاركة", "ناجح", "طباعة + جدول + مشاركة، وتمييز البيانات الناقصة"],
    ["المستخدمون والصلاحيات وسجل التدقيق", "ناجح", "كل عملية مسجلةة باسم المستخدم والوقت"],
    ["المساعد الذكي التنفيذي", "ناجح", "نفذ إضافة عربة وتغيير حد ومقارنات من المحادثة"],
    ["اكتشاف البلوتوث BLE والقراءة المباشرة", "يحتاج جهازاً", "يعمل على كروم أندرويد برابط مشفر + جهاز مقترن يدعم battery_service"],
    ["واي فاي / RF / بوابة / API المصنع", "يحتاج وثائق", "لا بروتوكول موثق بعد — الوحدة تعرض المتاح وتمنع الادعاء"],
    ["إرسال أوامر تحكم للشاتل", "غير منفذ عمداً", "النظام قراءة فقط حفاظاً على السلامة حتى توثيق رسمي"],
    ["تطبيق أندرويد APK أصلي", "غير متاح من المنص", "الناتج تطبيق ويب قابل للتثبيت PWA بنفس الوظائف المحليةة"],
    ["المزامنة بين أجهزة متعددة", "غير مُدعاة", "البيانات محلية على كل جهاز حتى تنفيذ مزامنة مختبرة"],
  ];
  const exportAll = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(db, null, 2)], { type: "application/json" }));
    a.href && a.click();
  };
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold flex items-center gap-2"><BookOpen className="size-5" /> دليل الاستخدام والاختبار</h1>
      <div className="text-[12px] opacity-60">الإصدار {APP_VERSION} — آخر تحديث {APP_UPDATED}</div>
      <Glass className="p-4 space-y-2">
        <div className="font-bold flex items-center gap-1.5"><Activity className="size-4" /> فحص سلامة البيانات — يعمل على بياناتك الحالية</div>
        <button onClick={runChecks} className={btnGhost + " w-full"}>تشغيل فحوص السلامة</button>
        {checks && checks.map(([t, s]) => (
          <div key={t} className="flex justify-between text-[13px] rounded-2xl bg-white/5 border border-white/10 px-3 py-2">
            <span>{t}</span><b style={{ color: s === "سليم" ? "#22c55e" : "#f43f5e" }}>{s}</b>
          </div>
        ))}
      </Glass>
      <Glass className="p-4 space-y-2 text-[14px] leading-7">
        <div className="font-bold flex items-center gap-1.5"><Smartphone className="size-4" /> التثبيت والتشغيل</div>
        <div>1. افتح رابط التطبيق في متصفح كروم على هاتف أندرويد.</div>
        <div>2. من قائمة المتصفح اختر تثبيت التطبيق أو إضافة إلى الشاشة الرئيسية — يعمل بعدها بملء الشاشة.</div>
        <div>3. البلوتوث المباشر يتطلب رابطاً مشفراً وضغطة زر واقتراناً من إعدادات الهاتف، ولا يعمل داخل كل متصفحات الويب المدمج.</div>
        <div>4. كل الوظائف المحلية (ورديات وبطاريات وأعطال وتقارير) تعمل دون إنترنت بعد أول فتح.</div>
      </Glass>
      <Glass className="p-4 space-y-2 text-[14px] leading-7">
        <div className="font-bold">النسخ الاحتياطي والاستعادة</div>
        <div>من الإعدادات ← البيانات: أنشئ نسخة احتياطية يومياً واحفظ الملف خارج الهاتف. الاستعادة بنفس الشاشة وتطلب تأكيداً صريحاً، والاستيراد من جدول يكشف المكرر قبل الحفظ.</div>
        <button onClick={exportAll} className={btnPrimary + " flex items-center gap-1"}><Download className="size-4" /> تنزيل نسخة الآن</button>
      </Glass>
      <Glass className="p-4 space-y-2">
        <div className="font-bold flex items-center gap-1.5"><ClipboardCheck className="size-4" /> تقرير الاختبار الصادق</div>
        {rows.map(([t, s, d]) => (
          <div key={t} className="rounded-2xl bg-white/5 border border-white/10 p-3 text-[13px]">
            <div className="flex justify-between gap-2"><b>{t}</b>
              <span className="text-[12px] font-bold rounded-full px-2.5 py-0.5" style={{ color: s === "ناجح" ? "#22c55e" : s.startsWith("غير") ? "#f43f5e" : "#f59e0b", border: "1px solid currentColor" }}>{s}</span>
            </div>
            <div className="opacity-70 mt-1">{d}</div>
          </div>
        ))}
        <div className="text-[12px] opacity-60 flex items-center gap-1"><ShieldCheck className="size-3.5" /> لم نعرض أي بيانات تجريبية على أنها حقيقية، ولم ندعِ مزامنة أو اتصالاً لم يُختبر.</div>
      </Glass>
    </div>
  );
}
