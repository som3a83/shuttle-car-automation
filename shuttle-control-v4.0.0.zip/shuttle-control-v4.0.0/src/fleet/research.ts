// Per-type technical dossiers — real research results only, no invented specs.
// Last checked: 2026-11-14. Statuses: مثبت رسمياً / غير مثبت / مُختبر فعلياً.
export type MeansStatus = "proven" | "unproven" | "tested";
export interface CommMeans { name: string; status: MeansStatus; detail: string; }
export interface DataRow { item: string; level: "documented" | "needs_unit" | "unsupported" | "unconfirmed"; note: string; }
export interface Dossier {
  maker: string;
  identity: string;
  identityOk: boolean;
  best: string;
  means: CommMeans[];
  data: DataRow[];
  app: string[];
  missing: string[];
  letter: string;
  next: string[];
  sources: string[];
}
export const CHECKED = "2026-11-14";
export const DOSSIERS: Dossier[] = [
  {
    maker: "كازيولي",
    identity: "غير مؤكد رسمياً: لا يوجد اسم Cazzoli أو Kazioli في فهارس الشركات والمعدات. الأقرب هو Cassioli S.r.l الإيطالية (Torrita di Siena) — النطق المصري «كازيولي» يطابقها، وهي تصنع شاتل ISAT. تحقق من لوحة بيانات العربة قبل اعتماد أي اسم.",
    identityOk: false,
    best: "الأفضل المحتمل: واي فاي عبر التابلت الصناعي الخاص بالنظام (موثق رسمياً كقناة بيانات ISAT)، ثم التكامل عبر WMS الخاص بالشركة — بعد تأكيد الهوية ووثائق الوكيل.",
    means: [
      { name: "واي فاي (قناة بيانات ISAT)", status: "proven", detail: "المواصفات الفنية المنشورة لنظام ISAT تذكر Data communication: Wi-Fi بين الشاتل والتابلت ونظام WMS — دون نشر النطاق أو البروتوكول أو الطاقة." },
      { name: "تابلت صناعي بشاشة + ريموت", status: "proven", detail: "وضع شبه آلي: تابلت بشاشة يعرض الحالة لحظياً لعربة واحدة أو عدة عربات (LIFO/FIFO، تحميل/تفريغ، دمج وعد وإعادة ترتيب)، مع مؤشرات LED على العربة." },
      { name: "بلوتوث / BLE عبر الهاتف", status: "unproven", detail: "لا يوجد أي ذكر رسمي للبلوتوث في وثائق ISAT — لا تعتمد عليه." },
      { name: "تطبيق هاتف رسمي", status: "unproven", detail: "لا يوجد تطبيق هاتف عام — التحكم عبر تابلت المشروع المرفق فقط." },
      { name: "API / SDK رسمي", status: "unproven", detail: "التكامل المعلن هو عبر نظام Logis WMS الخاص بالشركة — يحتاج اتفاقية ووثائق من الوكيل." },
      { name: "RF مخصص / بوابة صناعية", status: "unproven", detail: "لا توجد وثيقة منشورة — تُطلب من دليل التشغيل والصيانة." },
    ],
    data: [
      { item: "نسبة شحن البطارية", level: "documented", note: "تظهر على شاشة التابلت لحظياً (بطارية LiFePO4 48V 33A، استقلالية 8–10 ساعات، شحن 2.5 ساعة)." },
      { item: "الحالة والأعطال", level: "documented", note: "شاشة التابلت تعرض ظروف التشغيل لحظياً + وظائف العد والتشخيص — حسب كتالوج ISAT." },
      { item: "وضع التشغيل / الحركة", level: "documented", note: "LIFO/FIFO والتحميل والتفريغ تُدار من التابلت." },
      { item: "ساعات التشغيل والسجل", level: "needs_unit", note: "متاح غالباً عبر WMS أو التابلت — يُؤكد من الدليل." },
      { item: "درجة الحرارة", level: "unconfirmed", note: "نسخة الفريزر تعمل -30 إلى 0 مئوية — قراءة الحرارة من عدمها تُؤكد من الدليل." },
      { item: "قوة الإشارة", level: "unconfirmed", note: "تعتمد على موديل وحدة الواي فاي — غير منشور." },
    ],
    app: ["لا يوجد تطبيق هاتف عام — التحكم عبر تابلت المشروع المرفق من الشركة.", "الاستفادة داخل تطبيقنا حالياً: تسجيل يدوي للقراءات الظاهرة على التابلت + صور، ولصق أي تصدير من WMS لاحقاً.", "لا توجد واجهة تكامل رسمية معلنة — تُطلب من الوكيل."],
    missing: ["تأكيد الهوية: صورة لوحة البيانات (الموديل والسيريال)", "دليل التشغيل والصيانة — فصل Remote Control والبيانات الفنية", "موديل التابلت ووحدة الراديو المدمجة وشهاداته", "النطاق والبروتوكول وقنوات الواي فاي المعتمد", "وثائق التكامل مع WMS والحسابات الفنية المطلوبة"],
    letter: "Subject: Request for ISAT communication and diagnostics documentation\n\nDear Cassioli team,\nWe operate three pallet shuttles believed to be Cassioli ISAT units in our cold storage facility. To monitor them read-only from our own fleet app, please provide:\n1. Use and Maintenance Manual (Remote Control / Technical Data chapter);\n2. The radio module datasheet of the tablet link (band, protocol, TX power, certifications);\n3. The list of live data readable from the tablet (battery %, alarms, hours, temperature);\n4. Any WMS/Logis integration interface or export available to third-party fleet software;\n5. Required technician accounts or licenses.\n\nMachine details (from nameplates) are attached. Thank you.",
    next: ["صوّر لوحة بيانات العربات الثلاث وطابق الاسم مع Cassioli", "اطلب الدليل وفصل الريموت من الوكيل", "سجّل قراءات التابلت يدوياً في التطبيق لحين الربط"],
    sources: ["cassioli.com — صفحة Multi-Depth Automated Warehouse with ISAT Pallet Shuttle", "المواصفات الفنية المنشورة لنظام ISAT (Wi-Fi / LiFePO4 48V / 8–10h)"],
  },
  {
    maker: "كرافتسمان",
    identity: "مؤكد: Craftsman Storage Systems — قسم من Craftsman Automation Ltd، الهند (Coimbatore / Pune).",
    identityOk: true,
    best: "الأفضل المحتمل: الريموت المحمول المرفق (راديو المصنع) للتشغيل اليومي، وبرنامج إدارة الأسطول SFMS مع WMS عبر الوكيل للقراءات المجمعة.",
    means: [
      { name: "ريموت راديو المصنع", status: "proven", detail: "مكوّن رقم 9 في منظومة الشركة: ريموت محمول يأمر الشاتل (تخزين/استرجاع، FIFO/LIFO) — التردد والمدى غير منشورين." },
      { name: "برنامج إدارة الأسطول SFMS + WMS", status: "unproven", detail: "مذكور في مواد الشركة كبرنامج يدير الشاتلات والناقلات — التفاصيل والواجهات تُطلب من الشركة." },
      { name: "بلوتوث / واي فاي عبر الهاتف", status: "unproven", detail: "لا يوجد أي ذكر رسمي — لا تعتمد عليهما." },
      { name: "تطبيق هاتف رسمي", status: "unproven", detail: "لا يوجد تطبيق عام معلن." },
      { name: "API / SDK رسمي", status: "unproven", detail: "غير معلن — يُطلب من الشركة." },
    ],
    data: [
      { item: "نسبة شحن البطارية", level: "needs_unit", note: "بطارية ليثيوم حتى 8 ساعات مع كبح متجدد — القراءة اللحظية عبر الريموت/الشاشة تُؤكد من الدليل." },
      { item: "وضع التشغيل FIFO/LIFO", level: "documented", note: "يُختار من الريموت حسب الموقع الرسمي." },
      { item: "الأعطال والأكواد", level: "needs_unit", note: "تُؤكد من دليل التشخيص." },
      { item: "ساعات التشغيل", level: "unconfirmed", note: "وظيفة عدّ المخزون مذكورة — الساعات تُؤكد من الدليل." },
      { item: "درجة الحرارة", level: "unconfirmed", note: "حلول مثبتة حتى -25 مئوية — قراءة الحرارة تُؤكد من الدليل." },
      { item: "قوة الإشارة", level: "unconfirmed", note: "غير منشورة." },
    ],
    app: ["لا يوجد تطبيق هاتف عام.", "الاستفادة داخل تطبيقنا: تسجيل يدوي لقراءات الريموت + صور، ولصق أي تصدير من SFMS لاحقاً.", "التكامل الرسمي يُطلب من الشركة مباشرة."],
    missing: ["دليل التشغيل والصيانة — فصل الريموت والتشخيص", "التردد والمدى وشهادات وحدة الراديو", "طريقة قراءة البطارية والأعطال والساعات", "وثائق SFMS وإمكانية التصدير والحسابات المطلوبة", "موديل وحدة الاستقبال المطلوبة إن وجدت"],
    letter: "Subject: Request for radio shuttle remote and diagnostics documentation\n\nDear Craftsman Storage Systems team,\nWe operate a Craftsman radio shuttle (trial unit) in our cold store. For read-only monitoring from our fleet app, please provide:\n1. Operation and maintenance manual (remote control / diagnostics chapter);\n2. Radio unit datasheet (frequency, range, certifications) and receiver model;\n3. How to read battery level, alarms and operating hours;\n4. SFMS fleet software details and any data export/API for third-party apps;\n5. Required accounts, licenses and the local agent contact.\n\nNameplate photos are attached. Thank you.",
    next: ["صوّر لوحة البيانات واطلب الدليل من storage@craftsmanautomation.com أو 1800-313-03131", "وثّق وظائف الريموت المتاح فعلياً", "سجّل القراءات يدوياً لحين الربط"],
    sources: ["craftsmanstorage.com/shuttle-racking — المكونات (Remote control / Battery) وخطوات التشغيل", "مواد الشركة: SFMS وWMS (تحتاج تأكيداً رسمياً)"],
  },
  {
    maker: "أكمي",
    identity: "مؤكد: Acme Intralog، الإمارات (JAFZA، دبي) — منتج Namla Radio Shuttle صناعة إماراتية.",
    identityOk: true,
    best: "الأفضل المحتمل: التابلت الصناعي المرفق مع النظام (إدارة المهام لاسلكياً) وتكامل Acme Plus للواقع اللحظي للمخزون — عبر الوكيل.",
    means: [
      { name: "تابلت صناعي لاسلكي (راديو المصنع)", status: "proven", detail: "تابلت صناعي لإدارة المهام السريعة + ريموت لمشغل الفوركلفت — حسب الموقع الرسمي. التردد غير منشور." },
      { name: "تكامل WMS (Acme Plus)", status: "proven", detail: "الشركة تعلن تكامل WMS لرؤية المخزون لحظياً — الواجهة التفصيلية تُطلب من الوكيل." },
      { name: "بلوتوث / واي فاي عبر الهاتف", status: "unproven", detail: "لا يوجد تطبيق هاتف عام ولا اقتران بلوتوث — التحكم عبر تابلت المشروع المرفق فقط." },
      { name: "تطبيق هاتف رسمي", status: "unproven", detail: "لا يوجد على المتاجر العامة." },
      { name: "API / SDK رسمي", status: "unproven", detail: "غير معلن — يُطلب من الوكيل." },
    ],
    data: [
      { item: "نسبة شحن البطارية", level: "needs_unit", note: "بطارية Li-ion حتى 8 ساعات كحد أدنى وقابلة للتبديل — القراءة اللحظية عبر التابلت تُؤكد من الدليل." },
      { item: "وضع التشغيل والمهام", level: "documented", note: "التابلت يدير المهام لاسلكياً حسب الموقع الرسمي." },
      { item: "المخزون لحظياً", level: "documented", note: "عبر تكامل Acme Plus WMS." },
      { item: "الأعطال والأكواد", level: "needs_unit", note: "تُؤكد من دليل التشخيص." },
      { item: "ساعات التشغيل", level: "unconfirmed", note: "تُؤكد من الدليل." },
      { item: "درجة الحرارة", level: "unconfirmed", note: "نسخة Polar تعمل -30 إلى +40 — قراءة الحرارة تُؤكد من الدليل." },
      { item: "الحمولة والسرعة", level: "documented", note: "1500 كجم قياسي (أعلى عند الطلب)؛ Kanghar بسرعة 2.6/1.0 م/ث." },
    ],
    app: ["لا يوجد تطبيق هاتف عام — تابلت المشروع المرفق فقط.", "الاستفادة داخل تطبيقنا: تسجيل يدوي لقراءات التابلت + صور، ولصق أي تصدير من Acme Plus لاحقاً.", "التكامل الرسمي يُطلب من الوكيل."],
    missing: ["دليل التشغيل والتشخيص — فصل التابلت والمهام", "التردد وشهادات الوحدة اللاسلكية وموديلها", "طريقة قراءة البطارية والأعطال والساعات", "وثائق تكامل Acme Plus وإمكانية التصدير والحسابات", "تأكيد موديل الوحدة: Namla أم Kanghar من اللوحة"],
    letter: "Subject: Request for Namla connectivity and data documentation\n\nDear Acme Intralog team,\nWe operate an Acme shuttle in our cold store. For read-only monitoring from our fleet app, please provide:\n1. Operation and diagnostics manual (tablet / task management chapter);\n2. Wireless unit datasheet (frequency, certifications) and tablet model;\n3. How to read battery level, alarms and operating hours;\n4. Acme Plus WMS integration details and any data export/API for third-party apps;\n5. Required accounts, licenses and the agent contact for our region.\n\nNameplate photos are attached. Thank you.",
    next: ["حدد من اللوحة: Namla أم Kanghar", "اطلب الدليل ووثائق Acme Plus من الوكيل", "سجّل قراءات التابلت يدوياً لحين الربط"],
    sources: ["acme-world.com/product/radio-shuttle — التحكم بالتابلت والريموت وAcme Plus", "إعلان الشركة: Namla صناعة إماراتية ونسخة Polar"],
  },
];
export const COMPARISON = [
  ["البند", "كازيولي (الأرجح Cassioli)", "كرافتسمان", "أكمي (Acme Intralog)"],
  ["الهوية", "غير مؤكدة — تحقق من اللوحة", "مؤكدة — الهند", "مؤكدة — الإمارات"],
  ["أفضل وسيلة محتملة", "واي فاي عبر تابلت ISAT", "ريموت الراديو + SFMS", "التابلت اللاسلكي + Acme Plus"],
  ["بلوتوث هاتف", "غير مثبت", "غير مثبت", "غير مثبت"],
  ["تطبيق هاتف رسمي", "لا يوجد", "لا يوجد", "لا يوجد"],
  ["API/SDK معلن", "لا — عبر الوكيل", "لا — عبر الشركة", "لا — عبر الوكيل"],
  ["بطارية الشاتل", "LiFePO4 48V — 8-10 ساعات", "ليثيوم — حتى 8 ساعات", "Li-ion — 8 ساعات على الأقل"],
  ["الفريزر", "نسخة حتى -30", "حلول حتى -25", "نسخة Polar حتى -30"],
  ["قراءة البطارية عن بعد", "عبر التابلت — تُؤكد", "عبر الريموت — تُؤكد", "عبر التابلت — تُؤكد"],
  ["الربط بتطبيقنا", "يدوي الآن + WMS لاحقاً", "يدوي الآن + SFMS لاحقاً", "يدوي الآن + Acme Plus لاحقاً"],
];
