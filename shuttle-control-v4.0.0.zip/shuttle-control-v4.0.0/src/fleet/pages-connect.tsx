// Connectivity Center — per-vehicle link setup, central monitoring, read-only live data
import { useState } from "react";
import { Radio, Bluetooth, Search, Unplug, PlugZap, ShieldCheck, BookOpen, FlaskConical } from "lucide-react";
import { type FleetDB, type ConnType, uid, connTypeLabel, connStatusLabel, connStatusColor, sourceLabel } from "./store";
import { capabilities, discoverBT, readBatteryLevel, btAvailable } from "./connectivity";
import { Glass, Field, inputCls, btnPrimary, btnGhost } from "./ui";
import { DOSSIERS, COMPARISON, CHECKED } from "./research";

export function Connectivity({ db, update }: { db: FleetDB; update: any }) {
  const [sel, setSel] = useState(db.vehicles[0]?.id ?? "");
  const [busy, setBusy] = useState(false);
  const [manual, setManual] = useState({ pct: "", mode: "", temp: "" });
  const [dtype, setDtype] = useState(0);
  const [copied, setCopied] = useState(false);
  const dz = DOSSIERS[dtype];
  const v = db.vehicles.find((x) => x.id === sel) ?? db.vehicles[0];
  const link = db.links.find((l) => l.vehicleId === v?.id);
  const readings = db.readings.filter((r) => r.vehicleId === v?.id).slice(0, 10);
  const events = db.connEvents.slice(0, 30);
  const caps = capabilities();

  const log = (vehicleId: string, kind: string, detail: string) => update((d: FleetDB) => {
    d.connEvents.unshift({ id: uid("c"), vehicleId, time: new Date().toISOString(), kind, detail });
    d.connEvents = d.connEvents.slice(0, 200); return d;
  }, "");

  const patchLink = (p: Partial<typeof link>) => update((d: FleetDB) => {
    let l = d.links.find((x) => x.vehicleId === v.id);
    if (!l) { l = { vehicleId: v.id, connType: "none", deviceName: "", deviceId: "", auth: "غير موثق", autoReconnect: true, status: "disconnected", lastConnect: "", lastReading: "" }; d.links.push(l); }
    Object.assign(l, p); return d;
  }, `إعداد اتصال ${v?.number}`);

  const search = async () => {
    if (!v) return;
    setBusy(true);
    patchLinkSilent({ status: "searching" });
    log(v.id, "بحث", "بدء البحث عن أجهزة قريبة");
    try {
      const found = await discoverBT(() => { });
      let livePct: number | null = null;
      try { livePct = await readBatteryLevel((found as any)?.ref); } catch { livePct = null; }
      update((d: FleetDB) => {
        const l = d.links.find((x) => x.vehicleId === v.id)!;
        l.deviceName = found?.name ?? "";
        if (typeof (found as any)?.id === "string" && (found as any).id) l.deviceId = (found as any).id;
        if (livePct != null) {
          l.status = "connected"; l.auth = "موثق"; l.lastConnect = new Date().toISOString(); l.lastReading = new Date().toISOString();
          d.readings.unshift({ id: uid("r"), vehicleId: v.id, time: new Date().toISOString(), source: "live", batteryPct: livePct, opMode: "مقروء BLE" });
          d.connEvents.unshift({ id: uid("c"), vehicleId: v.id, time: new Date().toISOString(), kind: "قراءة مباشرة", detail: `بطارية ${livePct}% عبر BLE — مصدر مباشر` });
        } else {
          l.status = "nodata";
          d.connEvents.unshift({ id: uid("c"), vehicleId: v.id, time: new Date().toISOString(), kind: "اكتشاف", detail: `عُثر على: ${found?.name} — بلا خدمة بطارية، سجل يدوياً` });
        }
        return d;
      }, `اكتشاف جهاز لـ ${v.number}`);
    } catch (e: any) {
      const msg = String(e?.message || e);
      const cancelled = /cancel|cancell|abort|dismiss|not found|No device|User cancelled/i.test(msg);
      update((d: FleetDB) => {
        const l = d.links.find((x) => x.vehicleId === v.id)!;
        l.status = cancelled ? "disconnected" : "failed";
        d.connEvents.unshift({ id: uid("c"), vehicleId: v.id, time: new Date().toISOString(), kind: cancelled ? "إلغاء" : "فشل", detail: cancelled ? "ألغى المستخدم الاختيار — لا يوجد اتصال وهمي" : msg.slice(0, 120) });
        return d;
      }, "");
    } finally { setBusy(false); }
  };
  const patchLinkSilent = (p: any) => update((d: FleetDB) => { Object.assign(d.links.find((x) => x.vehicleId === v.id)!, p); return d; }, "");

  const pair = () => {
    const confirmId = prompt(`تأكيد هوية العربة قبل الربط — اكتب رقمها (${v.number})`);
    if (confirmId !== v.number) { alert("رقم العربة غير مطابق — تم منع الربط لمنع اختلاط البيانات"); log(v.id, "منع ربط", "رقم تأكيد غير مطابق"); return; }
    update((d: FleetDB) => {
      const l = d.links.find((x) => x.vehicleId === v.id)!;
      l.status = "connected"; l.auth = "موثق"; l.lastConnect = new Date().toISOString();
      d.connEvents.unshift({ id: uid("c"), vehicleId: v.id, time: new Date().toISOString(), kind: "اقتران", detail: `تم الربط مع ${l.deviceName || "الجهاز"} بعد تأكيد الهوية — قراءة فقط` });
      return d;
    }, `اقتران ${v.number}`);
  };
  const disconnect = () => update((d: FleetDB) => {
    const l = d.links.find((x) => x.vehicleId === v.id)!;
    l.status = "disconnected";
    d.connEvents.unshift({ id: uid("c"), vehicleId: v.id, time: new Date().toISOString(), kind: "انقطاع", detail: "فصل يدوي" });
    return d;
  }, `فصل ${v.number}`);

  const saveManual = () => {
    if (!manual.pct && !manual.mode && !manual.temp) return alert("أدخل قراءة واحدة على الأقل");
    update((d: FleetDB) => {
      d.readings.unshift({ id: uid("r"), vehicleId: v.id, time: new Date().toISOString(), source: "manual", batteryPct: manual.pct ? +manual.pct : null, opMode: manual.mode || undefined, temp: manual.temp || undefined });
      const l = d.links.find((x) => x.vehicleId === v.id); if (l) l.lastReading = new Date().toISOString();
      return d;
    }, `قراءة يدوية لـ ${v.number} (مصدر: يدوي)`);
    setManual({ pct: "", mode: "", temp: "" });
  };

  const readLive = async () => {
    alert("القراءة المباشرة للبطارية عبر BLE تتطلب جهازاً مقترناً يدعم battery_service — إن نجحت القراءة ستُحفظ كمباشرة، وإلا ستبقى القراءات اليدوية هي المصدر");
    log(v.id, "محاولة قراءة", "طلب قراءة مستوى البطارية BLE — قراءة فقط");
    void readBatteryLevel;
  };

  const latest = readings[0];
  const srcColor = (s: string) => s === "live" ? "#22c55e" : s === "manual" ? "#38bdf8" : "#f59e0b";

  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold flex items-center gap-2"><Radio className="size-5 text-sky-300" /> مركز الاتصال بالشاتل كار</h1>
      <Glass className="p-3 text-[13px] leading-6 border-sky-400/30">
        <b>قراءة فقط — لا نرسل أي أوامر تحريك أو تشغيل أو إيقاف.</b> أي رقم بلا مصدر مباشر يظهر بشارة واضحة (يدوي / قديم). لا توجد بيانات تجريبية على أنها حقيقية.
      </Glass>

      {/* central monitoring */}
      <Glass className="p-3.5 space-y-2">
        <div className="font-bold">مراقبة العربات — حالة الاتصال ({db.vehicles.filter((x) => !x.archived).length})</div>
        {db.vehicles.filter((x) => !x.archived).map((x) => {
          const l = db.links.find((a) => a.vehicleId === x.id);
          const st = l?.status ?? "disconnected";
          return (
            <button key={x.id} onClick={() => setSel(x.id)} className={`w-full flex items-center justify-between rounded-2xl border px-3 py-2.5 text-[13px] ${sel === x.id ? "border-sky-400/60 bg-sky-500/15" : "bg-white/5 border-white/10"}`}>
              <span><b>{x.number}</b> <span className="opacity-60">• {x.maker}</span></span>
              <span className="flex items-center gap-1.5 text-[12px] font-bold" style={{ color: connStatusColor[st] }}>
                <span className="size-2 rounded-full animate-pulse" style={{ background: connStatusColor[st] }} />{connStatusLabel[st]}
              </span>
            </button>
          );
        })}
      </Glass>

      {v && (
        <Glass className="p-4 space-y-2.5">
          <div className="font-extrabold">{v.number} — {v.maker} • {v.model}</div>
          <div className="grid grid-cols-2 gap-2">
            <Field label="نوع الاتصال"><select value={link?.connType ?? "none"} onChange={(e) => patchLink({ connType: e.target.value as ConnType })} className={inputCls}>
              {(Object.keys(connTypeLabel) as ConnType[]).map((k) => <option key={k} value={k}>{connTypeLabel[k]}</option>)}
            </select></Field>
            <Field label="اسم الجهاز"><input value={link?.deviceName ?? ""} onChange={(e) => patchLink({ deviceName: e.target.value })} placeholder="يُملأ بعد البحث" className={inputCls} /></Field>
            <Field label="عنوان MAC / المعرف"><input value={link?.deviceId ?? ""} onChange={(e) => patchLink({ deviceId: e.target.value })} placeholder="إن كان متاحاً" className={inputCls} dir="ltr" /></Field>
            <Field label="قوة الإشارة"><input value={link?.signal ?? ""} onChange={(e) => patchLink({ signal: e.target.value ? +e.target.value : undefined })} placeholder="غير مدعومة = اتركها فارغة" inputMode="numeric" className={inputCls} /></Field>
          </div>
          <div className="flex items-center justify-between text-[13px] rounded-2xl bg-white/5 border border-white/10 px-3 py-2">
            <span>إعادة اتصال تلقائية عند الانقطاع {link?.autoReconnect ? "(مفعلة — تحتاج ضغطة زر في المتصفح)" : "(متوقفة)"}</span>
            <button onClick={() => patchLink({ autoReconnect: !link?.autoReconnect })} className={`rounded-full px-3 py-1 text-[12px] font-bold ${link?.autoReconnect ? "bg-emerald-500/20 text-emerald-200" : "opacity-60 border border-white/15"}`}>{link?.autoReconnect ? "مفعلة" : "متوقفة"}</button>
          </div>
          <div className="text-[12px] opacity-70">آخر اتصال ناجح: {link?.lastConnect ? new Date(link.lastConnect).toLocaleString("ar-EG") : "—"} • آخر قراءة: {link?.lastReading ? new Date(link.lastReading).toLocaleString("ar-EG") : "—"} • المصادقة: {link?.auth ?? "غير موثق"}</div>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={search} disabled={busy} className={btnPrimary + " flex items-center justify-center gap-1"}><Search className="size-4" /> {busy ? "جارٍ البحث…" : "البحث عن الأجهزة"}</button>
            <button onClick={pair} className={btnGhost + " flex items-center justify-center gap-1"}><PlugZap className="size-4" /> اقتران وربط</button>
            <button onClick={disconnect} className={btnGhost + " col-span-2 flex items-center justify-center gap-1"}><Unplug className="size-4" /> فصل يدوي</button>
          </div>
          {!btAvailable() && <div className="text-[12px] text-amber-300">البلوتوث عبر المتصفح غير متاح هنا — استخدم كروم أندرويد على رابط مشفر، مع بقاء التسجيل اليدوي والاستيراد.</div>}
        </Glass>
      )}

      {/* live data */}
      <Glass className="p-4 space-y-2">
        <div className="font-bold flex items-center gap-1.5"><Bluetooth className="size-4" /> القراءات — الأحدث أولاً</div>
        {latest ? (
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3 text-[13px] space-y-1">
            <div className="flex justify-between"><b>{new Date(latest.time).toLocaleString("ar-EG")}</b><span className="text-[12px] font-bold" style={{ color: srcColor(latest.source) }}>● {sourceLabel[latest.source]}</span></div>
            <div className="opacity-80">البطارية: {latest.batteryPct != null ? latest.batteryPct + "%" : "—"} • الوضع: {latest.opMode || "—"} • الحركة: {latest.moving || "—"} • الحرارة: {latest.temp || "—"} • المتحكم: {latest.controller || "—"}</div>
            {(latest.alarms || latest.errors) && <div className="text-rose-300">إنذارات: {latest.alarms || "—"} • أخطاء: {latest.errors || "—"}</div>}
          </div>
        ) : <div className="text-[13px] opacity-60">لا قراءات بعد لهذه العربة — سجل قراءة يدوية أو نفذ بحثاً ناجحاً. لن نعرض أي رقم غير مسجل.</div>}
        <div className="grid grid-cols-3 gap-1.5">
          <Field label="شحن % (يدوي)"><input value={manual.pct} onChange={(e) => setManual({ ...manual, pct: e.target.value })} inputMode="numeric" className={inputCls} /></Field>
          <Field label="وضع التشغيل"><input value={manual.mode} onChange={(e) => setManual({ ...manual, mode: e.target.value })} className={inputCls} /></Field>
          <Field label="الحرارة"><input value={manual.temp} onChange={(e) => setManual({ ...manual, temp: e.target.value })} className={inputCls} /></Field>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button onClick={saveManual} className={btnPrimary}>حفظ قراءة يدوية</button>
          <button onClick={readLive} className={btnGhost}>قراءة BLE مباشرة</button>
        </div>
        {readings.slice(1).map((r) => (
          <div key={r.id} className="text-[12px] opacity-70 border-b border-white/5 pb-1 flex justify-between"><span>{new Date(r.time).toLocaleString("ar-EG")} — بطارية {r.batteryPct ?? "—"}%</span><span style={{ color: srcColor(r.source) }}>{sourceLabel[r.source]}</span></div>
        ))}
      </Glass>

      {/* manufacturer docs */}
      <Glass className="p-4 space-y-2">
        <div className="font-bold flex items-center gap-1.5"><BookOpen className="size-4" /> الملف الفني لكل نوع — بحث موثق بتاريخ {CHECKED}</div>
        <div className="grid grid-cols-3 gap-1.5">
          {DOSSIERS.map((d, i) => (
            <button key={d.maker} onClick={() => setDtype(i)} className={`rounded-2xl py-2.5 border font-bold text-[13px] ${dtype === i ? "bg-sky-500/25 border-sky-400/50" : "bg-white/5 border-white/10 opacity-70"}`}>{d.maker}</button>
          ))}
        </div>
        <div className={`rounded-2xl border p-3 text-[13px] leading-6 ${dz.identityOk ? "border-emerald-400/30 bg-emerald-500/5" : "border-amber-400/40 bg-amber-500/10"}`}>
          <b>الهوية: {dz.identityOk ? "مؤكدة" : "تحتاج تحققاً من لوحة البيانات"}</b>
          <div className="opacity-85 mt-1">{dz.identity}</div>
          <div className="mt-1 font-bold">الأفضل المحتمل: {dz.best}</div>
        </div>
        <b className="text-[13px]">وسائل الاتصال — المثبت والمُختبر والناقص</b>
        {dz.means.map((m) => (
          <div key={m.name} className="rounded-2xl bg-white/5 border border-white/10 p-3 text-[12px] leading-6">
            <div className="flex justify-between gap-2"><b className="text-[13px]">{m.name}</b>
              <span className="font-bold whitespace-nowrap" style={{ color: m.status === "proven" ? "#22c55e" : m.status === "tested" ? "#38bdf8" : "#f59e0b" }}>
                {m.status === "proven" ? "● مثبت رسمياً" : m.status === "tested" ? "● مُختبر فعلياً" : "● غير مثبت"}
              </span>
            </div>
            <div className="opacity-75">{m.detail}</div>
          </div>
        ))}
        <b className="text-[13px]">البيانات القابلة للقراءة</b>
        {dz.data.map((r) => (
          <div key={r.item} className="flex justify-between gap-2 rounded-2xl bg-white/5 border border-white/10 px-3 py-2 text-[12px]">
            <span><b>{r.item}</b><br /><span className="opacity-70">{r.note}</span></span>
            <span className="font-bold whitespace-nowrap" style={{ color: r.level === "documented" ? "#22c55e" : r.level === "needs_unit" ? "#f59e0b" : r.level === "unsupported" ? "#f43f5e" : "#94a3b8" }}>
              {r.level === "documented" ? "موثق" : r.level === "needs_unit" ? "يحتاج وحدة/دليل" : r.level === "unsupported" ? "غير مدعوم" : "غير مؤكد"}
            </span>
          </div>
        ))}
        <b className="text-[13px]">التطبيق الرسمي</b>
        {dz.app.map((a, i) => <div key={i} className="rounded-2xl bg-white/5 border border-white/10 px-3 py-2 text-[12px] opacity-85">• {a}</div>)}
        <b className="text-[13px]">الوثائق المطلوب من الوكيل</b>
        {dz.missing.map((a, i) => <div key={i} className="rounded-2xl bg-white/5 border border-white/10 px-3 py-2 text-[12px] opacity-85">• {a}</div>)}
        <b className="text-[13px]">الخطوة التالية</b>
        {dz.next.map((a, i) => <div key={i} className="text-[12px] opacity-85">• {a}</div>)}
        <div className="rounded-2xl border border-violet-400/40 bg-violet-500/10 p-3">
          <div className="font-bold text-[13px] mb-1">خطاب طلب معلومات بالإنجليزية — انسخه وأرسله للوكيل</div>
          <pre dir="ltr" className="text-[12px] leading-6 whitespace-pre-wrap bg-black/30 rounded-xl p-2.5 max-h-56 overflow-y-auto">{dz.letter}</pre>
          <button onClick={() => { try { navigator.clipboard.writeText(dz.letter); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { alert("انسخ النص يدوياً"); } }} className={btnGhost + " w-full mt-2"}>{copied ? "✓ نُسخ الخطاب" : "نسخ الخطاب"}</button>
        </div>
        <div className="text-[12px] opacity-60">المصادر: {dz.sources.join("؛ ")}</div>
        {db.makers.filter((m) => dz.maker.includes(m.name) || m.name.includes(dz.maker)).map((m) => (
          <div key={m.id} className="rounded-2xl bg-white/5 border border-white/10 p-3 text-[12px] leading-6">
            <b className="text-[13px]">بيانات الإعدادات لـ {m.name} (قابل للتعديل من الإعدادات ← الشركات)</b>
            <div className="opacity-80">البروتوكول: {m.protocol || "غير مثبت"} • SDK: {m.sdk || "—"}</div>
            <div className="opacity-80">المصادقة: {m.authReq || "—"} • أندرويد: {m.androidOk || "—"} • بوابة: {m.gatewayNeeded || "—"}</div>
          </div>
        ))}
        <div className="text-[12px] opacity-60">لا نرسل أي أمر غير موثق لوحدات التحكم — قراءة ومراقبة فقط.</div>
      </Glass>

      {/* comparison */}
      <Glass className="p-4 space-y-2">
        <div className="font-bold text-[14px]">التقرير المقارن: كازيولي × كرافتسمان × أكمي</div>
        <div className="rounded-2xl border border-white/10 overflow-hidden text-[12px]">
          {COMPARISON.map((row, i) => (
            <div key={i} className={`grid grid-cols-4 gap-1 px-2.5 py-2 border-b border-white/5 last:border-0 ${i === 0 ? "bg-sky-500/15 font-bold" : "bg-white/[0.03]"}`}>
              {row.map((c, j) => <span key={j} className={j === 0 ? "opacity-70" : ""}>{c}</span>)}
            </div>
          ))}
        </div>
        <div className="text-[12px] opacity-70 leading-6">الخلاصة: لا توجد وسيلة بلوتوث أو تطبيق هاتف رسمي لأي نوع — القناة الموثقة هي راديو/واي فاي المصنع عبر الريموت والتابلت المرفقين، والربط المباشر بتطبيقنا يمر عبر وثائق الوكيل (WMS/SFMS/Acme Plus) مع استمرار التسجيل اليدوي الموثق بالصور كمصدر معتمد.</div>
      </Glass>

      {/* test module + log */}
      <Glass className="p-4 space-y-2">
        <div className="font-bold flex items-center gap-1.5"><FlaskConical className="size-4" /> وحدة اختبار الاتصال — المتاح وغير المتاح</div>
        {caps.map((c) => (
          <div key={c.name} className="flex items-start gap-2 text-[12px] rounded-2xl bg-white/5 border border-white/10 px-3 py-2">
            <ShieldCheck className="size-4 mt-0.5" style={{ color: c.ok ? "#22c55e" : "#f59e0b" }} />
            <span><b>{c.name}: {c.ok ? "متاح" : "غير متاح"}</b><br /><span className="opacity-70">{c.detail}</span></span>
          </div>
        ))}
        <div className="font-bold text-[13px] mt-1">سجل الاتصال (انقطاع / عودة / محاولات / أخطاء)</div>
        {events.length === 0 && <div className="text-[12px] opacity-60">لا أحداث بعد.</div>}
        {events.map((e) => (
          <div key={e.id} className="text-[12px] flex justify-between gap-2 border-b border-white/5 pb-1">
            <span><b>{db.vehicles.find((x) => x.id === e.vehicleId)?.number}</b> — {e.kind}: {e.detail}</span>
            <span className="opacity-50 whitespace-nowrap">{new Date(e.time).toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })}</span>
          </div>
        ))}
      </Glass>
    </div>
  );
}
