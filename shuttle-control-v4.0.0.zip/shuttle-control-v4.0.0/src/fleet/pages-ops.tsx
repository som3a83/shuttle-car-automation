// Fleet list + batteries + shifts
import React, { useState } from "react";
import { Zap, ArrowLeftRight, Plus } from "lucide-react";
import { type FleetDB, statusLabel, statusColor, uid, fmtTime } from "./store";
import { Glass, ChargeRing, StatusDot, ShuttleArt, LevelBar, Field, inputCls, btnPrimary, btnGhost } from "./ui";

export function FleetList({ db, go }: { db: FleetDB; go: (t: string, id?: string) => void }) {
  const [q, setQ] = useState("");
  const list = db.vehicles.filter((v) => (v.number + v.maker + v.model).includes(q));
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold">العربات — {db.vehicles.length}</h1>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث برقم العربة أو الشركة…" className={inputCls} />
      <div className="grid gap-3">
        {list.map((v) => {
          const b = db.batteries.find((x) => x.id === v.batteryId);
          return (
            <Glass key={v.id} onClick={() => go("vehicle", v.id)} glow={statusColor[v.status]} className="p-3">
              <ShuttleArt maker={v.maker} status={v.status} />
              <div className="flex justify-between items-center mt-2">
                <b>{v.number} • {v.maker}</b>
                <span className="text-[12px]" style={{ color: statusColor[v.status] }}><StatusDot status={v.status} /> {statusLabel[v.status]}</span>
              </div>
              <div className="text-[12px] opacity-70">{v.model} • {v.location}</div>
              <div className="flex items-center gap-2 mt-2">{b ? <><ChargeRing pct={b.charge} size={44} /><LevelBar pct={b.charge} color={b.charge > (db.settings?.swapThreshold ?? 50) ? "#22c55e" : "#f59e0b"} /><span className="text-[12px]">{b.code}</span></> : <span className="text-[12px] text-rose-300">بدون بطارية</span>}</div>
            </Glass>
          );
        })}
      </div>
    </div>
  );
}

export function Batteries({ db, update }: { db: FleetDB; update: any }) {
  const [f, setF] = useState("all");
  const [showSwap, setShowSwap] = useState(false);
  const [swap, setSwap] = useState({ batteryId: "", vehicleId: "", by: "" });
  const thr = db.settings?.swapThreshold ?? 50;
  const low = db.settings?.lowAlert ?? 30;
  const filtered = db.batteries.filter((b) => f === "all" ? true : f === "need" ? (b.charge <= thr) : b.state === f);
  const doSwap = () => {
    if (!swap.batteryId || !swap.vehicleId) return;
    update((d: FleetDB) => {
      const bat = d.batteries.find((x) => x.id === swap.batteryId)!;
      const veh = d.vehicles.find((x) => x.id === swap.vehicleId)!;
      const old = d.batteries.find((x) => x.id === veh.batteryId);
      if (old) { old.vehicleId = null; old.state = "charging"; old.location = "محطة الشحن — خارج غرف التبريد"; old.lastSwap = new Date().toISOString().slice(0, 10); old.lastBy = swap.by || "مشرف الوردية"; }
      bat.vehicleId = veh.id; bat.state = "mounted"; bat.location = `مركبة على ${veh.number}`; bat.lastSwap = new Date().toISOString().slice(0, 10); bat.lastBy = swap.by || "مشرف الوردية";
      veh.batteryId = bat.id; veh.lastUpdate = new Date().toISOString();
      return d;
    }, `تبديل بطارية ${swap.batteryId} على ${swap.vehicleId}`);
    setShowSwap(false);
  };
  const chargeOne = (id: string) => update((d: FleetDB) => {
    const b = d.batteries.find((x) => x.id === id)!;
    b.charge = 100; b.state = b.vehicleId ? "mounted" : "full"; b.lastCharge = new Date().toISOString().slice(0, 10);
    return d;
  }, `تسجيل شحن بطارية ${id}`);
  const [cyc, setCyc] = useState({ bid: "", kind: "charge", s: "", e: "", by: "" });
  const saveCycle = () => {
    if (!cyc.bid || cyc.s === "" || cyc.e === "") return alert("اختر البطارية ونسبتي البداية والنهاية");
    const b = db.batteries.find((x) => x.id === cyc.bid)!;
    update((d: FleetDB) => {
      d.cycles.unshift({ id: uid("c"), batteryCode: b.code, batteryId: b.id, kind: cyc.kind as any, startPct: +cyc.s, endPct: +cyc.e, startedAt: new Date().toISOString(), endedAt: new Date().toISOString(), by: cyc.by || "مشرف الوردية" });
      const x = d.batteries.find((a) => a.id === cyc.bid)!;
      x.charge = Math.max(0, Math.min(100, +cyc.e)); x.lastCharge = new Date().toISOString().slice(0, 10);
      if (cyc.kind === "charge" && +cyc.e >= 100) x.state = x.vehicleId ? "mounted" : "full";
      return d;
    }, `تسجيل دورة ${cyc.kind === "charge" ? "شحن" : "تفريغ"} ${b.code}`);
    setCyc({ bid: "", kind: "charge", s: "", e: "", by: "" });
  };
  const stateColor = (s: string) => s === "mounted" ? "#38bdf8" : s === "full" || s === "spare" ? "#22c55e" : s === "charging" ? "#a78bfa" : s === "needs_charge" ? "#f59e0b" : "#f43f5e";

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-extrabold">البطاريات — {db.batteries.length}</h1>
        <button onClick={() => setShowSwap(true)} className={btnPrimary + " flex items-center gap-1 !py-2"}><ArrowLeftRight className="size-4" /> تبديل</button>
      </div>
      <div className="rounded-2xl bg-amber-500/10 border border-amber-400/30 p-3 text-[12px] leading-6">
        تعليمات التشغيل: الاستبدال عند {thr}% وعدم انتظار النفاد • الشحن في المكان المخصص بجانب غرف التبريد من الخارج • تسجيل كل عملية • التنبيه عند انخفاض الشحن أو عدم جاهزية الاحتياطية.
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1 text-[12px]">
        {[["all", "الكل"], ["mounted", "مركبة"], ["spare", "احتياطية"], ["charging", "قيد الشحن"], ["full", "مكتملة"], ["need", `تحتاج شحن ≤${thr}%`], ["inspect", "فحص"], ["fault", "عطل"]].map(([k, l]) => (
          <button key={k} onClick={() => setF(k)} className={`px-3 py-2 rounded-full border whitespace-nowrap font-bold ${f === k ? "bg-sky-500/25 border-sky-400/50" : "bg-white/5 border-white/10 opacity-70"}`}>{l}</button>
        ))}
      </div>
      <Glass className="p-3 space-y-2">
        <div className="font-bold text-[13px]">تسجيل دورة شحن / تفريغ (تُحسب في التحليلات ولا تُقدَّر الصحة منها)</div>
        <div className="grid grid-cols-3 gap-1.5">
          <select value={cyc.bid} onChange={(e) => setCyc({ ...cyc, bid: e.target.value })} className={inputCls + " !text-[12px] !py-2"}><option value="">البطارية…</option>{db.batteries.filter((b) => !b.archived).map((b) => <option key={b.id} value={b.id}>{b.code}</option>)}</select>
          <select value={cyc.kind} onChange={(e) => setCyc({ ...cyc, kind: e.target.value })} className={inputCls + " !text-[12px] !py-2"}><option value="charge">شحن</option><option value="discharge">تفريغ</option></select>
          <input value={cyc.by} onChange={(e) => setCyc({ ...cyc, by: e.target.value })} placeholder="المسؤول" className={inputCls + " !text-[12px] !py-2"} />
          <input value={cyc.s} onChange={(e) => setCyc({ ...cyc, s: e.target.value })} placeholder="بداية %" inputMode="numeric" className={inputCls + " !text-[12px] !py-2"} />
          <input value={cyc.e} onChange={(e) => setCyc({ ...cyc, e: e.target.value })} placeholder="نهاية %" inputMode="numeric" className={inputCls + " !text-[12px] !py-2"} />
          <button onClick={saveCycle} className={btnPrimary + " !text-[12px] !py-2"}>حفظ الدورة</button>
        </div>
        {db.cycles.slice(0, 3).map((c) => <div key={c.id} className="text-[12px] opacity-70 border-b border-white/5 pb-1 flex justify-between"><span>{c.batteryCode} — {c.kind === "charge" ? "شحن" : "تفريغ"} {c.startPct}% → {c.endPct}%</span><span>{c.by}</span></div>)}
      </Glass>
      <div className="grid gap-3">
        {filtered.map((b) => (
          <Glass key={b.id} glow={b.charge <= thr ? "#f59e0b" : undefined} className="p-3">
            <div className="flex items-center gap-3">
              <ChargeRing pct={b.charge} />
              <div className="flex-1">
                <div className="font-extrabold flex items-center gap-2"><Zap className="size-4 text-amber-300" />{b.code}</div>
                <div className="text-[12px] opacity-70">{b.location} {b.vehicleId ? `• ${db.vehicles.find((v) => v.id === b.vehicleId)?.number}` : ""}</div>
                <div className="flex flex-wrap gap-1.5 mt-1.5 text-[12px]">
                  <span className="rounded-full px-2 py-0.5 border" style={{ color: stateColor(b.state), borderColor: stateColor(b.state) + "66" }}>{b.state === "mounted" ? "مركبة" : b.state === "spare" ? "احتياطية" : b.state === "charging" ? "قيد الشحن" : b.state === "full" ? "مكتملة الشحن" : b.state === "needs_charge" ? "تحتاج شحن" : b.state === "inspect" ? "تحت الفحص" : "بها عطل"}</span>
                  <span className="rounded-full px-2 py-0.5 bg-white/10">الصحة: {b.health === "excellent" ? "ممتازة" : b.health === "good" ? "جيدة" : b.health === "fair" ? "متوسطة" : b.health === "poor" ? "ضعيفة" : "عطل"}</span>
                </div>
                <div className="text-[12px] opacity-60 mt-1">آخر شحن: {b.lastCharge} • آخر استبدال: {b.lastSwap} • {b.lastBy}</div>
              </div>
            </div>
            <div className="mt-2"><LevelBar pct={b.charge} color={b.charge > thr ? "#22c55e" : b.charge > low ? "#f59e0b" : "#f43f5e"} /></div>
            <div className="flex gap-2 mt-2">
              <button onClick={() => chargeOne(b.id)} className={btnGhost + " flex-1"}>تسجيل شحن مكتمل</button>
              {b.charge <= thr && <span className="text-[12px] text-amber-300 self-center font-bold">⚠ استبدال مطلوب (≤{thr}%)</span>}
            </div>
          </Glass>
        ))}
      </div>
      {showSwap && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur grid place-items-center p-4" onClick={() => setShowSwap(false)}>
          <div className="w-full max-w-sm rounded-3xl bg-[#0e1a2e] border border-white/10 p-4 space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="font-extrabold">تبديل بطارية</div>
            <Field label="البطارية الجديدة"><select value={swap.batteryId} onChange={(e) => setSwap({ ...swap, batteryId: e.target.value })} className={inputCls}>
              <option value="">اختر…</option>{db.batteries.filter((b) => !b.vehicleId).map((b) => <option key={b.id} value={b.id}>{b.code} — {b.charge}%</option>)}
            </select></Field>
            <Field label="العربة"><select value={swap.vehicleId} onChange={(e) => setSwap({ ...swap, vehicleId: e.target.value })} className={inputCls}>
              <option value="">اختر…</option>{db.vehicles.map((v) => <option key={v.id} value={v.id}>{v.number} — {v.maker}</option>)}
            </select></Field>
            <Field label="المسؤول"><input value={swap.by} onChange={(e) => setSwap({ ...swap, by: e.target.value })} placeholder="اسم المسؤول" className={inputCls} /></Field>
            <div className="flex gap-2"><button onClick={doSwap} className={btnPrimary + " flex-1"}>تأكيد التبديل</button><button onClick={() => setShowSwap(false)} className={btnGhost}>إلغاء</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

export function Shifts({ db, update }: { db: FleetDB; update: any }) {
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({ date: new Date().toISOString().slice(0, 10), type: "صباحية", start: "08:00", end: "16:00", supervisor: "", notes: "" });
  const [compare, setCompare] = useState(false);
  const [stopF, setStopF] = useState({ sid: "", vid: "", min: "", reason: "" });
  const [swapF, setSwapF] = useState({ sid: "", batt: "", by: "" });
  const addStop = () => {
    if (!stopF.sid || !stopF.vid || !stopF.min) return alert("اختر الوردية والعربة ومدة التوقف");
    update((d: FleetDB) => { d.shifts.find((x) => x.id === stopF.sid)!.stops.push({ vehicleId: stopF.vid, minutes: +stopF.min, reason: stopF.reason || "غير موثق" }); return d; }, `تسجيل توقف ${stopF.min} د`);
    setStopF({ sid: "", vid: "", min: "", reason: "" });
  };
  const addSwap = () => {
    if (!swapF.sid || !swapF.batt) return alert("اختر الوردية والبطارية");
    update((d: FleetDB) => { const s = d.shifts.find((x) => x.id === swapF.sid)!; s.swaps.push({ batteryId: swapF.batt, from: "", to: "", by: swapF.by || "مشرف الوردية", time: new Date().toISOString().slice(11, 16) }); const b = d.batteries.find((x) => x.id === swapF.batt); if (b) { b.lastSwap = new Date().toISOString().slice(0, 10); b.lastBy = swapF.by || "مشرف الوردية"; } return d; }, `تسجيل تبديل بطاري ${swapF.batt}`);
    setSwapF({ sid: "", batt: "", by: "" });
  };
  const create = () => {
    if (!form.supervisor) return alert("اكتب اسم المشرف المسؤول");
    update((d: FleetDB) => {
      d.shifts.unshift({
        id: uid("s"), date: form.date, type: form.type as any, start: form.start, end: form.end, supervisor: form.supervisor,
        ops: d.vehicles.filter((v) => v.status !== "maintenance").map((v) => {
          const b = d.batteries.find((x) => x.id === v.batteryId);
          return { vehicleId: v.id, operator: "", room: v.location, startCharge: b?.charge ?? 0, endCharge: b?.charge ?? 0 };
        }),
        swaps: [], faults: [], stops: [], notes: form.notes, deliverState: "", receiveState: "",
        deliveredBy: "", receivedBy: "", handoverDone: false, signature: "", createdAt: new Date().toISOString(),
      });
      return d;
    }, `تسجيل وردية ${form.type} بتاريخ ${form.date}`);
    setShow(false);
  };
  const setOp = (sid: string, vid: string, k: string, val: any) => update((d: FleetDB) => {
    const s = d.shifts.find((x) => x.id === sid)!; const o = s.ops.find((x) => x.vehicleId === vid)!; (o as any)[k] = val; return d;
  }, "");
  const handover = (sid: string, patch: Partial<any>) => update((d: FleetDB) => { Object.assign(d.shifts.find((x) => x.id === sid)!, patch); return d; }, "تسليم واستلام وردية");

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-extrabold">الورديات — {db.shifts.length}</h1>
        <div className="flex gap-2">
          <button onClick={() => setCompare(!compare)} className={btnGhost}>مقارنة</button>
          <button onClick={() => setShow(true)} className={btnPrimary + " flex items-center gap-1"}><Plus className="size-4" /> وردية</button>
        </div>
      </div>
      {db.shifts.length === 0 && <Glass className="p-4 text-[13px] opacity-80">لا توجد ورديات مسجلة بعد. سجل أول وردية بالزر أعلاه — لن تظهر أي ساعات أو مقارنات قبل التسجيل الفعلي.</Glass>}
      {compare && db.shifts.length >= 2 && (
        <Glass className="p-4 text-[13px]">
          <div className="font-bold mb-2">مقارنة الورديات</div>
          {db.shifts.slice(0, 4).map((s) => (
            <div key={s.id} className="flex justify-between border-b border-white/5 py-1.5 tabular-nums">
              <span>{s.date} — {s.type}</span>
              <span>عربات: {s.ops.length} • تبديل: {s.swaps.length} • أعطال: {s.faults.length} • توقف: {s.stops.reduce((a, x) => a + x.minutes, 0)} د</span>
            </div>
          ))}
          <div className="opacity-60 text-[12px] mt-1">الالتزام بالتسجيل: {db.shifts.filter((s) => s.handoverDone).length}/{db.shifts.length} ورديات مكتملة التسليم</div>
        </Glass>
      )}
      <div className="grid gap-3">
        {db.shifts.map((s) => (
          <Glass key={s.id} glow={s.handoverDone ? "#22c55e" : "#f59e0b"} className="p-3.5 space-y-2">
            <div className="flex justify-between items-start">
              <div><div className="font-extrabold">{s.date} — وردية {s.type}</div>
              <div className="text-[12px] opacity-70 tabular-nums">{s.start} – {s.end} • المشرف: {s.supervisor}</div></div>
              <span className={`text-[12px] font-bold rounded-full px-2.5 py-1 border ${s.handoverDone ? "text-emerald-300 border-emerald-400/40" : "text-amber-300 border-amber-400/40"}`}>{s.handoverDone ? "✓ مسلمة" : "بانتظار التسليم"}</span>
            </div>
            {s.ops.map((o) => {
              const v = db.vehicles.find((x) => x.id === o.vehicleId);
              return (
                <div key={o.vehicleId} className="rounded-2xl bg-white/5 border border-white/10 p-2.5 text-[12px] space-y-1.5">
                  <div className="font-bold">{v?.number} — {v?.maker}</div>
                  <div className="grid grid-cols-2 gap-1.5">
                    <input value={o.operator} onChange={(e) => setOp(s.id, o.vehicleId, "operator", e.target.value)} placeholder="المشغل" className={inputCls + " !py-1.5"} />
                    <input value={o.room} onChange={(e) => setOp(s.id, o.vehicleId, "room", e.target.value)} placeholder="الغرفة" className={inputCls + " !py-1.5"} />
                    <label className="flex items-center gap-1">بداية <input type="number" value={o.startCharge} onChange={(e) => setOp(s.id, o.vehicleId, "startCharge", +e.target.value)} className={inputCls + " !py-1.5"} /></label>
                    <label className="flex items-center gap-1">نهاية <input type="number" value={o.endCharge} onChange={(e) => setOp(s.id, o.vehicleId, "endCharge", +e.target.value)} placeholder="نهاية %" className={inputCls + " !py-1.5"} /></label>
                  </div>
                </div>
              );
            })}
            <div className="grid grid-cols-2 gap-1.5">
              <input value={s.deliverState} onChange={(e) => handover(s.id, { deliverState: e.target.value })} placeholder="حالة العربة عند التسليم" className={inputCls + " !text-[12px]"} />
              <input value={s.receiveState} onChange={(e) => handover(s.id, { receiveState: e.target.value })} placeholder="حالة العربة عند الاستلام" className={inputCls + " !text-[12px]"} />
              <input value={s.deliveredBy} onChange={(e) => handover(s.id, { deliveredBy: e.target.value })} placeholder="سلمها: الاسم" className={inputCls + " !text-[12px]"} />
              <input value={s.receivedBy} onChange={(e) => handover(s.id, { receivedBy: e.target.value })} placeholder="استلمها: الاسم" className={inputCls + " !text-[12px]"} />
            </div>
            {(s.stops.length > 0 || s.swaps.length > 0) && (
              <div className="rounded-2xl bg-white/5 border border-white/10 p-2.5 text-[12px] space-y-1">
                {s.stops.map((t, i) => <div key={i}>⏸ توقف: {db.vehicles.find((x) => x.id === t.vehicleId)?.number} — {t.minutes} د — {t.reason} <button onClick={() => handover(s.id, { stops: s.stops.filter((_, j) => j !== i) })} className="text-rose-300">حذف</button></div>)}
                {s.swaps.map((w, i) => <div key={i}>🔄 تبديل: {db.batteries.find((x) => x.id === w.batteryId)?.code} — {w.by} {w.time} <button onClick={() => handover(s.id, { swaps: s.swaps.filter((_, j) => j !== i) })} className="text-rose-300">حذف</button></div>)}
              </div>
            )}
            <div className="grid grid-cols-4 gap-1.5">
              <select value={stopF.sid === s.id ? stopF.vid : ""} onChange={(e) => setStopF({ ...stopF, sid: s.id, vid: e.target.value })} className={inputCls + " !text-[12px] !py-1.5"}>
                <option value="">توقف: عربة…</option>{s.ops.map((o) => <option key={o.vehicleId} value={o.vehicleId}>{db.vehicles.find((x) => x.id === o.vehicleId)?.number}</option>)}
              </select>
              <input value={stopF.sid === s.id ? stopF.min : ""} onChange={(e) => setStopF({ ...stopF, sid: s.id, min: e.target.value })} placeholder="دقائق" inputMode="numeric" className={inputCls + " !text-[12px] !py-1.5"} />
              <input value={stopF.sid === s.id ? stopF.reason : ""} onChange={(e) => setStopF({ ...stopF, sid: s.id, reason: e.target.value })} placeholder="السبب" className={inputCls + " !text-[12px] !py-1.5"} />
              <button onClick={addStop} className={btnGhost + " !text-[12px] !py-1.5"}>توقف +</button>
              <select value={swapF.sid === s.id ? swapF.batt : ""} onChange={(e) => setSwapF({ ...swapF, sid: s.id, batt: e.target.value })} className={inputCls + " !text-[12px] !py-1.5"}>
                <option value="">تبديل: بطاري…</option>{db.batteries.map((b) => <option key={b.id} value={b.id}>{b.code} {b.charge}%</option>)}
              </select>
              <input value={swapF.sid === s.id ? swapF.by : ""} onChange={(e) => setSwapF({ ...swapF, sid: s.id, by: e.target.value })} placeholder="المسؤول" className={inputCls + " !text-[12px] !py-1.5"} />
              <span className="text-[12px] opacity-60 self-center">يسجل مع الوقت والتاريخ</span>
              <button onClick={addSwap} className={btnGhost + " !text-[12px] !py-1.5"}>تبديل +</button>
            </div>
            <SignaturePad value={s.signature} onChange={(v2) => handover(s.id, { signature: v2 })} />
            {s.notes ? <div className="text-[12px] opacity-70">ملاحظات: {s.notes}</div> : null}
            <div className="text-[12px] opacity-50">أُنشئت {fmtTime(s.createdAt)}</div>
            <button onClick={() => { if (!s.handoverDone) { if (!s.deliverState || !s.receiveState || !s.deliveredBy || !s.receivedBy) { const r = prompt("الحالة النهائية أو سبب عدم التسجيل (يُحفظ في الملاحظات)"); if (!r) return; handover(s.id, { notes: (s.notes ? s.notes + " | " : "") + "سبب: " + r }); } } handover(s.id, { handoverDone: !s.handoverDone }); }} className={(s.handoverDone ? btnGhost : btnPrimary) + " w-full"}>{s.handoverDone ? "إلغاء اعتماد التسليم" : "اعتماد التسليم والاستلام ✓"}</button>
          </Glass>
        ))}
      </div>
      {show && (
        <div className="fixed inset-0 z-50 bg-black/60 grid place-items-center p-4" onClick={() => setShow(false)}>
          <div className="w-full max-w-sm rounded-3xl bg-[#0e1a2e] border border-white/10 p-4 space-y-3" onClick={(e) => e.stopPropagation()}>
            <div className="font-extrabold">تسجيل وردية جديدة</div>
            <div className="grid grid-cols-2 gap-2">
              <Field label="التاريخ"><input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className={inputCls} /></Field>
              <Field label="النوع"><select value={form.type} onChange={(e) => { const t = db.shiftTemplates.find((x) => x.name === e.target.value); setForm({ ...form, type: e.target.value, start: t?.start ?? form.start, end: t?.end ?? form.end }); }} className={inputCls}>{db.shiftTemplates.map((t) => <option key={t.id} value={t.name}>{t.name} ({t.start}–{t.end})</option>)}</select></Field>
              <Field label="البداية"><input type="time" value={form.start} onChange={(e) => setForm({ ...form, start: e.target.value })} className={inputCls} /></Field>
              <Field label="النهاية"><input type="time" value={form.end} onChange={(e) => setForm({ ...form, end: e.target.value })} className={inputCls} /></Field>
            </div>
            <Field label="المشرف المسؤول"><input value={form.supervisor} onChange={(e) => setForm({ ...form, supervisor: e.target.value })} placeholder="اسم المشرف" className={inputCls} /></Field>
            <Field label="ملاحظات التشغيل"><input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="اختياري" className={inputCls} /></Field>
            <div className="flex gap-2"><button onClick={create} className={btnPrimary + " flex-1"}>حفظ الوردية</button><button onClick={() => setShow(false)} className={btnGhost}>إلغاء</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

export function SignaturePad({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [drawing, setDrawing] = useState(false);
  const ref = React.useRef<HTMLCanvasElement>(null);
  React.useEffect(() => {
    if (value && ref.current) { const img = new Image(); img.onload = () => ref.current?.getContext("2d")?.drawImage(img, 0, 0, 280, 90); img.src = value; }
  }, []);
  const pos = (e: any) => {
    const r = ref.current!.getBoundingClientRect();
    const t = e.touches?.[0] ?? e;
    return { x: t.clientX - r.left, y: t.clientY - r.top };
  };
  return (
    <div>
      <div className="text-[12px] opacity-70 mb-1">التوقيع الإلكتروني (ارسم بإصبعك)</div>
      <canvas ref={ref} width={280} height={90} className="w-full h-[90px] rounded-2xl bg-white border border-white/20 touch-none"
        onMouseDown={(e) => { setDrawing(true); const c = ref.current!.getContext("2d")!; const p = pos(e); c.beginPath(); c.moveTo(p.x, p.y); }}
        onMouseMove={(e) => { if (!drawing) return; const c = ref.current!.getContext("2d")!; const p = pos(e); c.lineWidth = 2; c.strokeStyle = "#0b1526"; c.lineTo(p.x, p.y); c.stroke(); }}
        onMouseUp={() => { setDrawing(false); onChange(ref.current!.toDataURL()); }}
        onTouchStart={(e) => { setDrawing(true); const c = ref.current!.getContext("2d")!; const p = pos(e); c.beginPath(); c.moveTo(p.x, p.y); }}
        onTouchMove={(e) => { if (!drawing) return; e.preventDefault(); const c = ref.current!.getContext("2d")!; const p = pos(e); c.lineWidth = 2.5; c.strokeStyle = "#0b1526"; c.lineTo(p.x, p.y); c.stroke(); }}
        onTouchEnd={() => { setDrawing(false); onChange(ref.current!.toDataURL()); }}
      />
      <div className="flex gap-2 mt-1">
        <button onClick={() => { ref.current?.getContext("2d")?.clearRect(0, 0, 280, 90); onChange(""); }} className="text-[12px] opacity-60">مسح التوقيع</button>
        {value && <span className="text-[12px] text-emerald-300">✓ تم التوقيع</span>}
      </div>
    </div>
  );
}
