// Shared glass / industrial UI
import React from "react";
import { statusColor, type VehicleStatus } from "./store";

export function Glass({ children, className = "", glow = "", onClick }: { children: React.ReactNode; className?: string; glow?: string; onClick?: () => void }) {
  return (
    <div onClick={onClick}
      className={`rounded-3xl border border-white/10 bg-white/[0.06] dark:bg-white/[0.06] bg-slate-900/[0.04] backdrop-blur-xl shadow-[0_8px_40px_-12px_rgba(0,0,0,0.5)] ${onClick ? "cursor-pointer active:scale-[0.99] transition" : ""} ${className}`}
      style={glow ? { boxShadow: `0 0 0 1px rgba(255,255,255,0.06), 0 0 32px -8px ${glow}` } : undefined}>
      {children}
    </div>
  );
}

export function Kpi({ label, value, sub, color, onClick }: { label: string; value: string | number; sub?: string; color?: string; onClick?: () => void }) {
  return (
    <Glass onClick={onClick} glow={color} className="p-4 min-w-0">
      <div className="text-[12px] opacity-70 leading-5">{label}</div>
      <div className="text-2xl font-extrabold mt-1 tabular-nums" style={color ? { color } : undefined}>{value}</div>
      {sub ? <div className="text-[12px] opacity-60 mt-1 leading-5">{sub}</div> : null}
    </Glass>
  );
}

export function ChargeRing({ pct, size = 64, color }: { pct: number; size?: number; color?: string }) {
  const r = 26, c = 2 * Math.PI * r;
  const col = color ?? (pct > 50 ? "#22c55e" : pct > 30 ? "#f59e0b" : "#f43f5e");
  return (
    <div className="relative grid place-items-center shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox="0 0 64 64">
        <circle cx="32" cy="32" r={r} stroke="rgba(255,255,255,0.12)" strokeWidth="7" fill="none" />
        <circle cx="32" cy="32" r={r} stroke={col} strokeWidth="7" fill="none" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c - (c * Math.min(100, Math.max(0, pct))) / 100}
          transform="rotate(-90 32 32)" style={{ transition: "stroke-dashoffset .8s ease", filter: `drop-shadow(0 0 6px ${col})` }} />
      </svg>
      <span className="absolute text-[13px] font-bold tabular-nums">{pct}%</span>
    </div>
  );
}

export function StatusDot({ status }: { status: VehicleStatus }) {
  const c = statusColor[status];
  return <span className="inline-block size-2.5 rounded-full" style={{ background: c, boxShadow: `0 0 10px ${c}` }} />;
}

export function ShuttleArt({ maker, status }: { maker: string; status: VehicleStatus }) {
  const c = statusColor[status];
  return (
    <div className="relative w-full h-28 rounded-2xl overflow-hidden" style={{ background: "linear-gradient(135deg,#0b1526,#12294d 60%,#0b1526)" }}>
      <div className="absolute inset-0 opacity-40" style={{ background: "radial-gradient(300px 120px at 70% 20%, rgba(56,189,248,0.35), transparent), radial-gradient(200px 100px at 20% 90%, rgba(34,197,94,0.18), transparent)" }} />
      {/* rails */}
      <div className="absolute left-4 right-4 top-1/2 h-[3px] bg-white/15 rounded" />
      <div className="absolute left-4 right-4 top-1/2 translate-y-2 h-[2px] bg-white/10 rounded" />
      {/* body */}
      <div className="absolute top-1/2 -translate-y-1/2 right-6 left-6">
        <div className="mx-auto w-40 max-w-[70%] rounded-xl border border-white/20 bg-gradient-to-b from-slate-200 to-slate-500 dark:from-slate-600 dark:to-slate-900 p-1.5 shadow-2xl">
          <div className="flex items-center justify-between px-1">
            <span className="text-[12px] font-bold text-sky-300">{maker}</span>
            <span className="size-2 rounded-full animate-pulse" style={{ background: c, boxShadow: `0 0 8px ${c}` }} />
          </div>
          <div className="mt-1 h-6 rounded-md bg-[#0b1526] border border-cyan-400/30 grid grid-cols-6 gap-1 p-1">
            {[0, 1, 2, 3, 4, 5].map((i) => <div key={i} className="rounded-sm bg-cyan-400/70" style={{ opacity: 0.5 + (i % 3) * 0.25 }} />)}
          </div>
          <div className="mt-1 flex justify-between px-2">
            <span className="size-3 rounded-full bg-slate-900 border border-white/30" />
            <span className="size-3 rounded-full bg-slate-900 border border-white/30" />
            <span className="size-3 rounded-full bg-slate-900 border border-white/30" />
          </div>
        </div>
      </div>
      <div className="absolute bottom-1.5 right-3 text-[12px] text-white/60">مخازن مبردة ❄</div>
    </div>
  );
}

export function LevelBar({ pct, color }: { pct: number; color: string }) {
  return (
    <div className="h-2 rounded-full bg-white/10 overflow-hidden">
      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${Math.min(100, Math.max(0, pct))}%`, background: color, boxShadow: `0 0 12px ${color}` }} />
    </div>
  );
}

export function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[12px] opacity-70">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
export const inputCls = "w-full rounded-2xl border border-white/10 bg-white/[0.07] px-3 py-2.5 text-[14px] outline-none focus:border-sky-400/60 placeholder:opacity-40";
export const btnPrimary = "rounded-full bg-gradient-to-l from-sky-500 to-cyan-400 px-5 py-2.5 text-[14px] font-bold text-[#06222e] shadow-[0_8px_24px_-8px_rgba(56,189,248,0.7)] active:scale-95 transition min-h-[44px]";
export const btnGhost = "rounded-full border border-white/15 bg-white/[0.06] px-4 py-2.5 text-[13px] active:scale-95 transition min-h-[44px]";
