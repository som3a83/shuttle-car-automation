// Real wireless discovery helpers — read-only, no fake connections.
// Web Bluetooth works on Android Chrome over HTTPS with a user gesture.
// Everything else is honest capability detection, never a simulated link.
export interface CapRow { name: string; ok: boolean; detail: string; }

export function btAvailable(): boolean {
  try { return typeof navigator !== "undefined" && !!(navigator as any).bluetooth; } catch { return false; }
}
export function secureOK(): boolean {
  try { return typeof window !== "undefined" && (window.isSecureContext || location.hostname === "localhost" || location.hostname === "127.0.0.1"); } catch { return false; }
}
export function capabilities(): CapRow[] {
  const bt = btAvailable();
  const sec = secureOK();
  return [
    { name: "بلوتوث / BLE عبر المتصفح", ok: bt && sec, detail: bt ? (sec ? "متاح — يتطلب ضغطة زر واقتراناً من النظام" : "موجود لكن الصفحة ليست آمنة — انشرها على رابط مشفر") : "غير متاح في هذا المتصفح — استخدم كروم أندرويد" },
    { name: "واي فاي مباشر", ok: false, detail: "يتطلب عنوان جهاز الشاتل وبروتوكول الشركة المصنعة — لم يثبت بعد" },
    { name: "راديو RF", ok: false, detail: "يحتاج وحدة استقبال خاصة — لم تثبت وثائقها بعد" },
    { name: "وحدة الشركة المصنعة", ok: false, detail: "تنتظر دليل الربط الرسمي من الوكيل" },
    { name: "بوابة صناعية / API", ok: false, detail: "تنتظر SDK أو وثائق رسمية — النظام جاهز للربط لاحقاً" },
  ];
}
export async function discoverBT(onName: (n: string) => void): Promise<{ name: string; id: string; ref?: any } | null> {
  const nav = navigator as any;
  if (!nav?.bluetooth) throw new Error("البلوتوث غير متاح في هذا المتصفح");
  // Must be called from a user gesture; accept all services read-only.
  const device = await nav.bluetooth.requestDevice({ acceptAllDevices: true, optionalServices: ["battery_service", "device_information"] });
  const name = String(device?.name || "جهاز بدون اسم");
  onName(name);
  return { name, id: String(device?.id || ""), ref: device };
}
export async function readBatteryLevel(device: any): Promise<number | null> {
  try {
    const server = await device.gatt?.connect();
    const svc = await server?.getPrimaryService("battery_service");
    const ch = await svc?.getCharacteristic("battery_level");
    const v = await ch?.readValue();
    const pct = v?.getUint8(0);
    try { device.gatt?.disconnect(); } catch { /* ignore */ }
    return typeof pct === "number" ? pct : null;
  } catch { return null; }
}
