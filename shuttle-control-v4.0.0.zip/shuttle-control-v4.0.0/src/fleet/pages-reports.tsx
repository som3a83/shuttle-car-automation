// Reports + analytics + assistant + admin
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";
import { FileText, Download, Share2, Printer, Sparkles, Database, ShieldCheck } from "lucide-react";
import { type FleetDB, readiness, openFaults, batteriesNeeding, shiftCoverage, statusLabel, uid } from "./store";
import { Glass, Field, inputCls, btnPrimary, btnGhost } from "./ui";

export function Reports({ db }: { db: FleetDB }) {
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [range, setRange] = useState<"day" | "week" | "month">("day");
  const [scope, setScope] = useState((db as any).settings?.reportScope ?? "fleet");
  const scopeVehicles = db.vehicles.filter((v) => scope === "fleet" ? true : scope === "trial" ? v.trial : v.id === scope || v.maker === scope);
  const shifts = db.shifts.filter((s) => range === "day" ? s.date === date : range === "week" ? s.date >= date : s.date.slice(0, 7) === date.slice(0, 7));
  const faultsNew = db.faults.filter((f) => (f.createdAt || "").slice(0, 10) === date);
  const faultsClosed = db.faults.filter((f) => f.status === "closed");
  const r = readiness(db);
  const open = openFaults(db);
  const need = batteriesNeeding(db);
  const cov = shiftCoverage(db, date);
  const missing: string[] = [];
  if (shifts.length === 0) missing.push("لا توجد ورديات مسجلة في الفترة — ساعات التشغيل والتوقفات غير متوفرة");
  if (db.faults.length <= 1) missing.push("سجل الأعطال في بدايته — المؤشرات التاريخية محدودة");
  if (need.length > 0) missing.push(`${need.length} بطاريات عند حد الاستبدال أو تحته`);
  if (!db.readings.length) missing.push("لا قراءات مباشرة من الشاتل بعد — حالة الاتصال: يدوي فقط");

  const buildText = () => {
    return `التقرير ${range === "day" ? "اليومي" : range === "week" ? "الأسبوعي" : "الشهري"} — أسطول الشاتل كار
التاريخ: ${date}
Nطاق التقرير: ${scope === "fleet" ? "الأسطول بالكامل" : scope}

أولاً: الملخص التنفيذي
- إجمالي العربات: ${db.vehicles.length} | الجاهزة: ${db.vehicles.filter((v) => v.status === "ready").length} | العاملة: ${db.vehicles.filter((v) => v.status === "working").length} | المتوقفة: ${db.vehicles.filter((v) => v.status === "stopped").length} | تحت الصيانة: ${db.vehicles.filter((v) => v.status === "maintenance").length}
- الجاهزية: ${r}% | الأعطال المفتوحة: ${open.length}

ثانياً: حالة كل عربة
${db.vehicles.map((v) => { const b = db.batteries.find((x) => x.id === v.batteryId); const fl = db.faults.filter((f) => f.vehicleId === v.id && f.status !== "closed").length; return `- ${v.number} (${v.maker}): ${statusLabel[v.status]} | البطارية ${b ? b.code + " " + b.charge + "%" : "غير مركبة"} | أعطال مفتوحة: ${fl} | ${v.location}`; }).join("\n")}

ثالثاً: البطاريات
- الإجمالي: ${db.batteries.length} | الجاهزة (≥80% غير مركبة): ${db.batteries.filter((b) => !b.vehicleId && b.charge >= 80).length} | قيد الشحن: ${db.batteries.filter((b) => b.state === "charging").length} | تحتاج شحن (≤50%): ${need.length}
- الإجمالي: ${db.batteries.length} | الجاهزة (≥80% غير مركبة): ${db.batteries.filter((b) => !b.vehicleId && b.charge >= 80).length} | قيد الشحن: ${db.batteries.filter((b) => b.state === "charging").length} | تحتاج شحن (≤${(db as any).settings?.swapThreshold ?? 50}%): ${need.length}

رابعاً: الأعطال والصيانة
- جديدة بتاريخ التقرير: ${faultsNew.length} | مغلقة إجمالاً: ${faultsClosed.length} | مستمرة: ${open.length}
- الصيانة المجدولة: ${db.maints.filter((m) => m.status !== "done").length} | المنفذة: ${db.maints.filter((m) => m.status === "done").length}

خامساً: الورديات (${shifts.length})
${shifts.map((s) => `- ${s.date} ${s.type}: المشرف ${s.supervisor} | عربات ${s.ops.length} | تسليم ${s.handoverDone ? "مكتمل" : "غير مكتمل"}`).join("\n") || "- لا ورديات مسجلة (توضيح لنقص البيانات، ليست أرقاماً تقديرية)"}

سادساً: التوصيات
${need.length ? `- متابعة البطاريات: ${need.map((b) => b.code).join("، ")}` : "- البطاريات مستقرة"}
${open.length ? `- تدخل في ${open.length} أعطال مفتوحة` : "- لا أعطال حرجة مفتوحة"}
${cov.count < cov.expected && range === "day" ? `- استكمال تسجيل الورديات (${cov.expected} يومياً)` : ""}
${missing.length ? "\nملاحظة شفافية: " + missing.join("؛ ") : ""}`;
  };
  const download = (kind: "txt" | "csv") => {
    const blob = kind === "txt"
      ? new Blob([buildText()], { type: "text/plain;charset=utf-8" })
      : new Blob(["العربة,الشركة,الحالة,البطارية,الشحن\n" + db.vehicles.map((v) => { const b = db.batteries.find((x) => x.id === v.batteryId); return `${v.number},${v.maker},${statusLabel[v.status]},${b?.code ?? "-"},${b?.charge ?? "-"}`; }).join("\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = kind === "txt" ? `تقرير-الأسطول-${date}.txt` : `أسطول-الشاتل-${date}.csv`;
    a.click();
  };
  const share = async () => {
    try {
      if (navigator.share) await navigator.share({ title: "تقرير الأسطول", text: buildText() });
      else { await navigator.clipboard.writeText(buildText()); alert("نُسخ التقرير — الصقه في واتساب أو البريد"); }
    } catch { /* cancelled */ }
  };
  const downloadXlsx = async () => {
    const XLSX = await import("xlsx");
    const wb = XLSX.utils.book_new();
    const fleet = scopeVehicles.map((v) => { const b = db.batteries.find((x) => x.id === v.batteryId);
      return { العربة: v.number, الشركة: v.maker, الطراز: v.model, الموقع: v.location, الحالة: statusLabel[v.status], البطارية: b?.code ?? "-", الشحن: b?.charge ?? "-" }; });
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(fleet), "الأسطول");
    const faults = db.faults.map((f) => ({ البلاغ: f.id, العربة: db.vehicles.find((v) => v.id === f.vehicleId)?.number, النوع: f.type, الخطورة: f.severity, الحالة: f.status, الفني: f.technician, الإجراء: f.action, الاختبار: f.testResult }));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(faults), "الأعطال");
    const shifts = db.shifts.filter((s) => range === "day" ? s.date === date : range === "week" ? s.date >= date : s.date.slice(0, 7) === date.slice(0, 7))
      .map((s) => ({ التاريخ: s.date, النوع: s.type, المشرف: s.supervisor, العربات: s.ops.length, التبديلات: s.swaps.length, التوقفات_د: s.stops.reduce((a, x) => a + x.minutes, 0), التسليم: s.handoverDone ? "مكتمل" : "غير مكتمل" }));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(shifts), "الورديات");
    XLSX.writeFile(wb, `تقرير-الأسطول-${date}.xlsx`);
  };

  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold flex items-center gap-2"><FileText className="size-5" /> التقارير الإدارية</h1>
      <Glass className="p-4 space-y-3">
        <div className="grid grid-cols-2 gap-2">
          <Field label="تاريخ التقرير"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} /></Field>
          <Field label="النوع"><select value={range} onChange={(e) => setRange(e.target.value as any)} className={inputCls}><option value="day">يومي</option><option value="week">أسبوعي</option><option value="month">شهري</option></select></Field>
        </div>
        <Field label="النطاق"><select value={scope} onChange={(e) => setScope(e.target.value)} className={inputCls}>
          <option value="fleet">الأسطول بالكامل</option>
          <option value="trial">عربات تحت التجربة فقط</option>
          {db.makers.map((m) => <option key={m.id} value={m.name}>{m.name}</option>)}
          {db.vehicles.map((v) => <option key={v.id} value={v.id}>{v.number} — {v.maker}</option>)}
        </select></Field>
        <div className="grid grid-cols-2 gap-2">
          <button onClick={() => download("txt")} className={btnGhost + " flex items-center justify-center gap-1"}><Printer className="size-4" /> حفظ للطباعة</button>
          <button onClick={() => download("csv")} className={btnGhost + " flex items-center justify-center gap-1"}><Download className="size-4" /> جدول إلكتروني</button>
          <button onClick={downloadXlsx} className={btnGhost + " flex items-center justify-center gap-1"}><Download className="size-4" /> ملف Excel حقيقي</button>
          <button onClick={share} className={btnPrimary + " col-span-2 flex items-center justify-center gap-1"}><Share2 className="size-4" /> مشاركة عبر الهاتف</button>
          <button onClick={() => window.print()} className={btnGhost + " col-span-2"}>عرض داخل التطبيق والطباعة</button>
        </div>
      </Glass>
      <Glass className="p-5 leading-8 text-[14px] print:text-black">
        <div className="text-center border-b border-white/10 pb-3 mb-3">
          <div className="font-extrabold text-lg">تقرير {range === "day" ? "يومي" : range === "week" ? "أسبوعي" : "شهري"} — أسطول الشاتل كار بالمخازن المبردة</div>
          <div className="opacity-60 text-[12px]">التاريخ: {date} • يُعرض على مدير المخازن ومدير التشغيل والإدارة العليا</div>
        </div>
        <section><b>أولاً: الملخص التنفيذي.</b> الإجمالي {db.vehicles.length} عربات — الجاهزية {r}% — المفتوحة {open.length} أعطال. {missing.length ? `تنبيه شفافية: ${missing[0]}.` : "البيانات مكتملة للفترة."}</section>
        <section className="mt-2"><b>ثانياً: حالة كل عربة.</b>
          {db.vehicles.map((v) => { const b = db.batteries.find((x) => x.id === v.batteryId); return <div key={v.id} className="rounded-2xl bg-white/5 border border-white/10 px-3 py-1.5 mt-1.5">• {v.number} ({v.maker}) — {statusLabel[v.status]} — البطارية {b ? `${b.code} ${b.charge}%` : "غير مركبة"} — {v.location}</div>; })}
        </section>
        <section className="mt-2"><b>ثالثاً: البطاريات.</b> الإجمالي {db.batteries.length} — تحتاج شحن {need.length} — قيد الشحن {db.batteries.filter((b) => b.state === "charging").length} — المكتملة {db.batteries.filter((b) => b.state === "full").length}.</section>
        <section className="mt-2"><b>رابعاً: الأعطال والصيانة.</b> الجديدة بتاريخ التقرير {faultsNew.length} — المستمرة {open.length} — المغلقة {faultsClosed.length} — الصيانة المجدولة {db.maints.filter((m) => m.status !== "done").length}.</section>
        <section className="mt-2"><b>خامساً: الورديات ({shifts.length}).</b> {shifts.length ? shifts.map((s) => `${s.date} ${s.type} بإشراف ${s.supervisor} (${s.handoverDone ? "مسلمة" : "غير مسلمة"})`).join("؛ ") : "لا ورديات مسجلة في الفترة — لا نعرض أرقاماً تقديرية."}</section>
        <section className="mt-2"><b>سابعاً: حالة الاتصال المباشر.</b>
          {scopeVehicles.map((v) => { const l = db.links.find((x) => x.vehicleId === v.id); const rd = db.readings.find((x) => x.vehicleId === v.id); const st = l ? ({ connected: "متصل", disconnected: "غير متصل", searching: "جارٍ البحث", failed: "فشل الاتصال", nodata: "متصل دون بيانات", repair: "يحتاج إعادة اقتران" } as any)[l.status] : "غير متصل"; return <div key={v.id} className="rounded-2xl bg-white/5 border border-white/10 px-3 py-1.5 mt-1.5">• {v.number}: {st} — آخر قراءة: {rd ? new Date(rd.time).toLocaleString("ar-EG") + " (" + (rd.source === "live" ? "مباشرة" : rd.source === "manual" ? "يدوية" : "قديمة") + ")" : "لا قراءة مسجلة"}</div>; })}
        </section>
        <section className="mt-2"><b>سادساً: التوصيات.</b> {need.length ? `متابعة ${need.map((b) => b.code).join("، ")} للشحن والاستبدال عند ${(db as any).settings?.swapThreshold ?? 50}%. ` : "البطاريات مستقرة. "}{open.length ? `التدخل في ${open.length} أعطال مفتوحة. ` : "لا أعطال حرج. "}{cov.count < cov.expected && range === "day" ? "استكمال تسجيل الورديات اليومية. " : ""}</section>
      </Glass>
    </div>
  );
}

export function Analytics({ db, go }: { db: FleetDB; go: (t: string, id?: string) => void }) {
  const r = readiness(db);
  const total = db.vehicles.length;
  const working = db.vehicles.filter((v) => v.status === "working").length;
  const closed = db.faults.filter((f) => f.startTime && f.endTime);
  const mttr = closed.length ? closed.map((f) => (new Date(f.endTime).getTime() - new Date(f.startTime).getTime()) / 36e5).filter((n) => n >= 0) : [];
  const avgMttr = mttr.length ? mttr.reduce((a, b) => a + b, 0) / mttr.length : null;
  const maintDone = db.maints.filter((m) => m.status === "done").length;
  const perDay = [0, 1, 2, 3, 4, 5, 6].map((i) => {
    const d = new Date(); d.setDate(d.getDate() - (6 - i));
    const k = d.toISOString().slice(0, 10);
    return { name: d.toLocaleDateString("ar-EG", { weekday: "short" }), shifts: db.shifts.filter((s) => s.date === k).length, faults: db.faults.filter((f) => (f.createdAt || "").slice(0, 10) === k).length };
  });
  const kpi = (label: string, val: string | null, hint: string) => (
    <Glass className="p-3"><div className="text-[12px] opacity-70">{label}</div><div className="text-xl font-extrabold tabular-nums">{val ?? "—"}</div>{val == null && <div className="text-[12px] opacity-50">{hint}</div>}</Glass>
  );
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold">التحليلات ومؤشرات الأداء</h1>
      <div className="grid grid-cols-2 gap-2.5">
        {kpi("جاهزية الأسطول", `${r}%`, "")}
        {kpi("الاستخدام التشغيلي", `${Math.round((working / Math.max(1, total)) * 100)}%`, "")}
        {kpi("الساعات المسجلة", db.shifts.length ? `${db.shifts.reduce((a, s) => a + s.ops.length * 8, 0)} س` : null, "سجل وردية أولاً")}
        {kpi("التوقف المسجل", db.shifts.flatMap((s) => s.stops).length ? `${db.shifts.flatMap((s) => s.stops).reduce((a, x) => a + x.minutes, 0)} د` : null, "لا توقفات مسجلة")}
        {kpi("تكرار الأعطال", db.faults.length ? `${db.faults.length} بلاغات` : null, "لا بلاغات")}
        {kpi("متوسط الإصلاح", avgMttr != null ? `${avgMttr.toFixed(1)} س` : null, "لا إصلاحات مكتملة بتواريخ")}
        {kpi("الالتزام بالصيانة", db.maints.length ? `${Math.round((maintDone / db.maints.length) * 100)}%` : null, "لا مهام مجدولة")}
        {kpi("اكتمال الورديات اليوم", db.shifts.length ? `${shiftCoverage(db, new Date().toISOString().slice(0, 10)).pct}%` : null, "لا ورديات اليوم")}
      </div>
      <Glass className="p-4">
        <div className="font-bold text-[14px] mb-2">الورديات والأعطال — آخر 7 أيام</div>
        <div className="h-48" dir="ltr"><ResponsiveContainer><BarChart data={perDay}><XAxis dataKey="name" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 12 }} /><Tooltip /><Bar dataKey="shifts" fill="#38bdf8" radius={[6, 6, 0, 0]} name="ورديات" /><Bar dataKey="faults" fill="#f43f5e" radius={[6, 6, 0, 0]} name="أعطال" /></BarChart></ResponsiveContainer></div>
      </Glass>
      <Glass className="p-4">
        <div className="font-bold text-[14px] mb-2">شحن البطاريات الحالي</div>
        <div className="h-44" dir="ltr"><ResponsiveContainer><LineChart data={db.batteries.map((b) => ({ name: b.code, c: b.charge }))}><XAxis dataKey="name" tick={{ fontSize: 12 }} /><YAxis domain={[0, 100]} tick={{ fontSize: 12 }} /><Tooltip /><Line type="monotone" dataKey="c" stroke="#22c55e" strokeWidth={2.5} dot name="الشحن %" /></LineChart></ResponsiveContainer></div>
        <div className="text-[12px] opacity-50">المعادلات المستخدمة: الجاهزية = (جاهزة+عاملة)/الإجمالي • الالتزام = منفذة/مجدولة • لا يُعرض مؤشر بلا بيانات كافية.</div>
      </Glass>
      <button onClick={() => go("reports")} className={btnPrimary + " w-full"}>إنشاء التقرير الإداري من هذه البيانات</button>
    </div>
  );
}

const QA: { q: string; a: (db: FleetDB) => string }[] = [
  { q: "ما حالة الأسطول اليوم؟", a: (db) => `الجاهزية ${readiness(db)}% — ${db.vehicles.filter((v) => v.status === "working").length} عاملة، ${db.vehicles.filter((v) => v.status === "ready").length} جاهزة، ${openFaults(db).length} أعطال مفتوحة. المصدر: حالة العربات الحالية.` },
  { q: "ما العربة الأكثر أعطالاً؟", a: (db) => { const c: Record<string, number> = {}; db.faults.forEach((f) => c[f.vehicleId] = (c[f.vehicleId] || 0) + 1); const e = Object.entries(c).sort((a, b) => b[1] - a[1])[0]; return e ? `${db.vehicles.find((v) => v.id === e[0])?.number} بعدد ${e[1]} بلاغات (الفترة: كل السجل)` : "لا بلاغات مسجلة بعد."; } },
  { q: "ما البطاريات التي تحتاج شحن؟", a: (db) => { const n = batteriesNeeding(db); const t = (db as any).settings?.swapThreshold ?? 50; return n.length ? n.map((b) => `${b.code} (${b.charge}%) في ${b.location}`).join("، ") : `كل البطاريات فوق حد الاستبدال (${t}%).`; } },
  { q: "هل هناك وردية لم تُسجل؟", a: (db) => { const t = new Date().toISOString().slice(0, 10); const c = shiftCoverage(db, t); return c.count >= 3 ? "ورديات اليوم الثلاث مسجلة." : `اليوم ${t}: مسجل ${c.count}/3 — الناقص يحتاج تسجيلاً.`; } },
  { q: "ما الصيانة المستحقة؟", a: (db) => { const p = db.maints.filter((m) => m.status !== "done"); return p.length ? p.map((m) => `${m.kind} لـ ${db.vehicles.find((v) => v.id === m.vehicleId)?.number} بتاريخ ${m.dueDate}`).join("، ") : "لا صيانة مستحقة."; } },
  { q: "أنشئ ملخصاً إدارياً", a: (db) => `ملخص اليوم: الجاهزية ${readiness(db)}%، الأعطال المفتوحة ${openFaults(db).length}، البطاريات المحتاجة ${batteriesNeeding(db).length}، الورديات المسجلة اليوم ${db.shifts.filter((s) => s.date === new Date().toISOString().slice(0, 10)).length}/3. اعتمد التقرير الإداري للتقديم الرسمي.` },
];
export function Assistant({ db }: { db: FleetDB }) {
  const [q, setQ] = useState("");
  const [log, setLog] = useState<{ me: boolean; t: string }[]>([{ me: false, t: "أهلاً بك — أنا المساعد الذكي للأسطول. أسألني عن الحالة أو البطاريات أو الأعطال، وأجيب فقط من البيانات المسجلة فعلياً مع ذكر المصدر والفترة." }]);
  const ask = (text: string) => {
    if (!text.trim()) return;
    const hit = QA.find((x) => text.includes(x.q.slice(0, 8)) || x.q.includes(text.slice(0, 8)));
    let ans: string;
    if (hit) ans = hit.a(db) + " — المصدر: قاعدة البيانات المحلية، الفترة: السجل الحالي.";
    else if (text.includes("كرافتسمان") || text.includes("تجربة")) {
      const v = db.vehicles.find((x) => x.maker.includes("كرافتسمان"));
      const fl = v ? db.faults.filter((f) => f.vehicleId === v.id) : [];
      ans = v ? `كرافتسمان (${v.number}): الحالة ${statusLabel[v.status]}، الأعطال المسجلة ${fl.length}، آخر تحديث ${v.lastUpdate.slice(0, 10)}. المصدر: سجل العربة.` : "لا بيانات.";
    }
    else ans = "أجيب فقط من البيانات المسجلة: اسأل عن (حالة الأسطول، الأكثر أعطالاً، البطاريات، وردية ناقصة، الصيانة، ملخص إداري). لا أخترع أرقاماً غير مسجلة.";
    setLog((l) => [...l, { me: true, t: text }, { me: false, t: ans }]);
    setQ("");
  };
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold flex items-center gap-2"><Sparkles className="size-5 text-violet-300" /> المساعد الذكي (عربي)</h1>
      <Glass className="p-3 space-y-2 min-h-[300px]">
        {log.map((m, i) => (
          <div key={i} className={`max-w-[88%] rounded-2xl px-3 py-2 text-[13px] leading-6 ${m.me ? "mr-auto bg-sky-500/25 border border-sky-400/30" : "bg-white/[0.07] border border-white/10"}`}>{m.t}</div>
        ))}
      </Glass>
      <div className="flex flex-wrap gap-1.5">
        {QA.slice(0, 4).map((x) => <button key={x.q} onClick={() => ask(x.q)} className="text-[12px] rounded-full border border-white/15 bg-white/[0.06] px-3 py-1.5">{x.q}</button>)}
      </div>
      <div className="flex gap-2 sticky bottom-20">
        <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && ask(q)} placeholder="اكتب سؤالك…" className={inputCls} />
        <button onClick={() => ask(q)} className={btnPrimary}>إرسال</button>
      </div>
    </div>
  );
}

export function Admin({ db, update }: { db: FleetDB; update: any }) {
  const me = db.users.find((u) => u.id === db.currentUser)!;
  const can = (roles: string[]) => roles.includes(me.role) || me.role === "مدير النظام";
  const [tab, setTab] = useState("users");
  const exportAll = () => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(db, null, 2)], { type: "application/json" }));
    a.download = `نسخة-احتياطية-الأسطول-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  };
  const restore = (f: File) => {
    const r = new FileReader();
    r.onload = () => { try { const d = JSON.parse(String(r.result)); update(() => d, "استعادة نسخة احتياطية"); alert("تمت الاستعادة"); } catch { alert("ملف غير صالح"); } };
    r.readAsText(f);
  };
  const wipeDemo = () => { if (!confirm("حذف كل الورديات والأعطال المسجلة والبدء بسجل نظيف؟")) return; update((d: FleetDB) => { d.shifts = []; d.faults = []; d.activity = []; return d; }, "تصفير السجل التشغيلي"); };
  return (
    <div className="space-y-3">
      <h1 className="text-xl font-extrabold flex items-center gap-2"><ShieldCheck className="size-5" /> الإدارة والصلاحيات</h1>
      <Glass className="p-4">
        <div className="text-[13px]">المستخدم الحالي: <b>{me.name}</b> — {me.role}</div>
        <Field label="تبديل المستخدم (للتجربة)"><select value={db.currentUser} onChange={(e) => update((d: FleetDB) => { d.currentUser = e.target.value; return d; }, "تبديل المستخدم")} className={inputCls}>
          {db.users.map((u) => <option key={u.id} value={u.id}>{u.name} — {u.role}</option>)}
        </select></Field>
        <div className="text-[12px] opacity-70 mt-2 leading-6">الصلاحيات: مدير النظام (كل شيء) • مدير التشغيل (التقارير والورديات) • مدير المخازن (عرض وتقارير) • مشرف الوردية (تسجيل الورديات والبطاريات) • المشغل (عرض عربته) • الفني (الأعطال والصيانة). الواجهة الحالية تعرض كل الوظائف للتجربة، والتقييد الكامل يُفعّل مع حسابات الدخول.</div>
      </Glass>
      <div className="grid grid-cols-3 gap-2 text-[12px]">
        {[["users", "المستخدمون"], ["log", "سجل التعديلات"], ["data", "البيانات"]].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`rounded-2xl py-2.5 border font-bold ${tab === k ? "bg-sky-500/25 border-sky-400/50" : "bg-white/5 border-white/10 opacity-70"}`}>{l}</button>
        ))}
      </div>
      {tab === "users" && (
        <Glass className="p-3 space-y-2">
          {db.users.map((u) => (
            <div key={u.id} className="flex items-center justify-between rounded-2xl bg-white/5 border border-white/10 px-3 py-2 text-[13px]">
              <span><b>{u.name}</b> — {u.role}</span>
              {can(["مدير النظام"]) && <button onClick={() => update((d: FleetDB) => { d.users = d.users.filter((x) => x.id !== u.id); return d; }, `حذف مستخدم ${u.name}`)} className="text-rose-300 text-[12px]">حذف</button>}
            </div>
          ))}
          <button onClick={() => { const n = prompt("اسم المستخدم الجديد؟"); if (!n) return; const ro = prompt("الدور؟ (مدير التشغيل/مشرف الوردية/فني الصيانة/مشغل الشاتل كار)") || "مشغل الشاتل كار"; update((d: FleetDB) => { d.users.push({ id: uid("u"), name: n, role: ro }); return d; }, `إضافة مستخدم ${n}`); }} className={btnGhost + " w-full"}>إضافة مستخدم</button>
        </Glass>
      )}
      {tab === "log" && (
        <Glass className="p-3 space-y-1.5 text-[12px]">
          {db.activity.map((a) => <div key={a.id} className="flex justify-between gap-2 border-b border-white/5 pb-1.5"><span>{a.user} — {a.action}</span><span className="opacity-50">{a.time.slice(0, 16).replace("T", " ")}</span></div>)}
          {db.activity.length === 0 && <div className="opacity-60">لا نشاط بعد.</div>}
        </Glass>
      )}
      {tab === "data" && (
        <Glass className="p-4 space-y-2">
          <div className="font-bold text-[14px] flex items-center gap-2"><Database className="size-4" /> النسخ الاحتياطي والاستعادة</div>
          <div className="text-[12px] opacity-70 leading-6">تُحفظ البيانات تلقائياً على الهاتف بعد كل عملية، وتعمل دون إنترنت. صدّر نسخة قبل نهاية كل يوم.</div>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={exportAll} className={btnPrimary}>نسخ احتياطي</button>
            <label className={btnGhost + " text-center cursor-pointer"}>استعادة<input type="file" accept=".json" className="hidden" onChange={(e) => e.target.files?.[0] && restore(e.target.files[0])} /></label>
          </div>
          <button onClick={wipeDemo} className="text-rose-300 text-[12px]">تصفير السجل التشغيلي والبدء النظيف</button>
          <div className="text-[12px] opacity-50">الربط المباشر مع أجهزة الشاتل (بلوتوث): غير مُدّعى — يحتاج بروتوكول الشركة المصنعة. التطبيق جاهز للربط عند توفره.</div>
        </Glass>
      )}
    </div>
  );
}
