import { useState, useEffect } from "react";
import { LayoutDashboard, Truck, BatteryCharging, CalendarClock, Wrench, FileText, ChartColumn, Bell, Sparkles, ShieldCheck, Sun, Moon, Settings2, PlugZap, BookOpen } from "lucide-react";
import { useFleet } from "./fleet/store";
import { useTheme } from "./lib/theme";
import { Dashboard, VehicleCenter } from "./fleet/pages-dash";
import { FleetList, Batteries, Shifts } from "./fleet/pages-ops";
import { Faults, Maintenance, Alerts } from "./fleet/pages-maint";
import { Reports, Analytics, Assistant, Admin } from "./fleet/pages-reports";
import { SettingsCenter } from "./fleet/pages-settings";
import { ExecAssistant } from "./fleet/pages-assistant";
import { Connectivity } from "./fleet/pages-connect";
import { Guide } from "./fleet/pages-guide";

const TABS = [
  { k: "home", l: "الرئيسية", i: LayoutDashboard },
  { k: "fleet", l: "العربات", i: Truck },
  { k: "batteries", l: "البطاريات", i: BatteryCharging },
  { k: "shifts", l: "الورديات", i: CalendarClock },
  { k: "faults", l: "الأعطال", i: Wrench },
  { k: "reports", l: "التقارير", i: FileText },
  { k: "more", l: "المزيد", i: ChartColumn },
];

export default function App() {
  const { db, update } = useFleet();
  const [theme, setTheme] = useTheme();
  const [tab, setTab] = useState("home");
  const [vehId, setVehId] = useState<string | undefined>();
  const [more, setMore] = useState("analytics");

  useEffect(() => {
    document.documentElement.lang = "ar";
    document.title = "شاتل كونترول — إدارة أسطول الشاتل كار";
  }, []);

  const go = (t: string, id?: string) => {
    if (t === "vehicle") { setVehId(id); setTab("vehicle"); }
    else if (["analytics", "maint", "alerts", "assistant", "assistant_exec", "admin", "settings", "connect", "guide"].includes(t)) { setMore(t === "assistant" ? "assistant_exec" : t); setTab("more"); }
    else setTab(t);
    window.scrollTo({ top: 0 });
  };

  return (
    <div dir="rtl" className="min-h-dvh text-slate-900 dark:text-slate-100" style={{ background: theme === "dark" ? "radial-gradient(1200px 600px at 80% -10%, #12325e 0%, #0a1628 45%, #060b14 100%)" : "linear-gradient(180deg,#eaf3ff,#f7fafc)" }}>
      {/* top bar */}
      <header className="sticky top-0 z-40 backdrop-blur-xl border-b border-white/10" style={{ background: theme === "dark" ? "rgba(6,12,22,0.75)" : "rgba(255,255,255,0.8)" }}>
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <img src="/logo.png" alt="شعار الأسطول" className="size-10 rounded-2xl object-cover border border-white/20 shadow-[0_0_20px_rgba(56,189,248,0.4)]" />
            <div>
              <div className="font-extrabold text-[15px] leading-5">شاتل كونترول</div>
              <div className="text-[12px] opacity-60">المخازن المبردة • Fleet Control</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => { setMore("settings"); setTab("more"); window.scrollTo({ top: 0 }); }} aria-label="إعدادات النظام" className="rounded-full border border-white/15 bg-white/10 p-2.5 min-w-[44px] min-h-[44px] grid place-items-center">
              <Settings2 className="size-5" />
            </button>
            <span className="hidden sm:inline text-[12px] opacity-70">{db.users.find((u) => u.id === db.currentUser)?.name}</span>
            <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label="الوضع الليلي والنهاري" className="rounded-full border border-white/15 bg-white/10 p-2.5 min-w-[44px] min-h-[44px] grid place-items-center">
              {theme === "dark" ? <Sun className="size-5" /> : <Moon className="size-5" />}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-3 sm:px-4 pt-4 pb-32">
        {tab === "home" && <Dashboard db={db} go={go} />}
        {tab === "fleet" && <FleetList db={db} go={go} />}
        {tab === "vehicle" && <VehicleCenter db={db} id={vehId ?? db.vehicles[0]?.id} go={go} update={update} />}
        {tab === "batteries" && <Batteries db={db} update={update} />}
        {tab === "shifts" && <Shifts db={db} update={update} />}
        {tab === "faults" && <Faults db={db} update={update} />}
        {tab === "reports" && <Reports db={db} />}
        {tab === "more" && (
          <div className="space-y-3">
            <div className="grid grid-cols-4 gap-1.5 text-[12px]">
              {[["connect", "الاتصال المباشر", PlugZap], ["analytics", "التحليلات", ChartColumn], ["maint", "الصيانة", Wrench], ["alerts", "التنبيهات", Bell], ["assistant_exec", "المساعد الذكي", Sparkles], ["settings", "الإعدادات", Settings2], ["guide", "الدليل والاختبار", BookOpen], ["admin", "الإدارة", ShieldCheck], ["assistant", "المساعد السريع", Bell], ["reports", "التقارير", FileText]].map(([k, l, I]: any) => (
                <button key={k} onClick={() => setMore(k)} className={`rounded-2xl py-2.5 border font-bold flex flex-col items-center gap-1 ${more === k ? "bg-sky-500/25 border-sky-400/50" : "bg-white/5 border-white/10 opacity-70"}`}>
                  <I className="size-4" />{l}
                </button>
              ))}
            </div>
            {more === "analytics" && <Analytics db={db} go={go} />}
            {more === "maint" && <Maintenance db={db} update={update} />}
            {more === "alerts" && <Alerts db={db} go={go} />}
            {more === "assistant_exec" && <ExecAssistant db={db} update={update} />}
            {more === "assistant" && <Assistant db={db} />}
            {more === "settings" && <SettingsCenter db={db} update={update} />}
            {more === "connect" && <Connectivity db={db} update={update} />}
            {more === "guide" && <Guide db={db} />}
            {more === "admin" && <Admin db={db} update={update} />}
          </div>
        )}
      </main>

      {/* bottom nav */}
      <nav className="fixed bottom-0 inset-x-0 z-40 border-t border-white/10 backdrop-blur-xl" style={{ background: theme === "dark" ? "rgba(6,12,22,0.88)" : "rgba(255,255,255,0.92)", paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div className="max-w-7xl mx-auto grid grid-cols-7 px-1">
          {TABS.map(({ k, l, i: I }) => (
            <button key={k} onClick={() => setTab(k)} className={`flex flex-col items-center gap-0.5 py-2.5 min-h-[60px] text-[12px] font-bold ${tab === k || (k === "more" && tab === "more") ? "text-sky-400" : "opacity-60"}`}>
              <I className="size-5" />
              {l}
              {(tab === k) && <span className="size-1 rounded-full bg-sky-400 shadow-[0_0_8px_#38bdf8]" />}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
