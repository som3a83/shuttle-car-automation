/**
 * Keeps the page laid out properly by measuring it, whatever classes the page wrote. base.css gives the kit's room by
 * the classes a page usually writes; classes cannot tell the rest (a margin in `style`, a move by `translate`, a card
 * placed with `absolute`, any of them inside boxes of the page's own), so this looks at where things are drawn.
 *
 * ROOM. Nothing sits on or against:
 * - a full-width photo band (`data-band`: Hero, PhotoBand, FormBand, ScrollFilm, Steps with a photo). What is inside
 *   a band (glass cards on its photo) is the band's design and stays. What comes before or after it starts clear of
 *   it: a search card pulled up over the hero and raised above it (`relative z-10 -mt-12`) covered its lower edge
 *   (owner, 2026-11-12, a production vacation-rentals site: "the check in card should have been in the following
 *   section, not on top of the hero pic", "make it in a way that doesn't happen again never"). A full-width colored
 *   section may meet a band, never cover it; another band or full-width picture keeps the band's room;
 * - a section's title (`data-section-head`): the cards, pictures or fields under it (a production bowl shop's care
 *   cards sat 8 px under "Keep it beautiful for years", `mt-2`), and what ends the section over it (a florist's
 *   "Kind words" stood 35 px under the crew's cards, on a page whose other sections are 80 px apart);
 * - a card (`data-card`): what is right above or below it (a theme park's sections, each one card and no padding,
 *   stacked their cards edge to edge).
 * Within `close` of the edge, or over it, the block that follows the seam moves down until `room` is between them.
 * A block with room of its own is left as it is.
 *
 * ROWS. A grid of cards never ends in a row with a hole beside it: three cards written two to a row on a tablet
 * (`md:grid-cols-2 lg:grid-cols-3`: 10 of 75 production sites, 2026-11-12) sit three to a row where each keeps
 * `TILE` of width, four written three to a row sit four. Where no number of columns makes every row full (five
 * cards, a phone's two to a row with an odd number), the last row's cards sit in its middle, as `ItemGrid`'s do.
 *
 * WIDTH. A card with its photo beside its words (`side`) in a box too narrow for both (a third of a computer's row),
 * or whose words run so long that the photo is a tall strip (220 px wide, 970 px tall beside a long story), is marked
 * `data-stack`; base.css then lays it out as on a phone, the photo over the words.
 *
 * WORDS IN A ROW. A row's words are never crushed into a sliver by the things beside them: a basket's line of photo,
 * name and a quantity stepper left the name 50 px on a phone, broken mid-word over six lines ("Signat / ure / Half",
 * production, 2026-11-13). Where a short text stands four lines or more in a column under `SLIVER`, its row may
 * wrap: the words keep a readable width beside what comes before them, and what no longer fits (the stepper, a
 * button) drops under them, at the row's end.
 *
 * BUTTONS. Two buttons written one after the other with nothing between them (no gap, no space) touch on one line
 * (a store-traffic page's "Check in today's sale" and "Copy summary", production, 2026-11-13): the second keeps
 * `BETWEEN` from the first. Only in running text: buttons a page set in a row or grid of its own are its design,
 * and so are two halves of one control (square where they meet), tabs and a group's choices.
 *
 * Every site, with nothing for the page to do: checked when the page draws, changes or is resized, before the screen
 * shows it.
 */
type Rule = {
  mark: string;
  /** Nearer than this to the marked box's edge counts as against it. */
  close: number;
  room: () => number;
  sides: (1 | -1)[];
};
const tablet = () => window.innerWidth >= 768;
const BAND: Rule = { mark: '[data-band]', close: 24, room: () => (tablet() ? 64 : 48), sides: [1, -1] };
const HEAD: Rule = { mark: '[data-section-head]', close: 16, room: () => (tablet() ? 48 : 40), sides: [1] };
/** Over a section's title: what ends the section before it. */
const ABOVE: Rule = { mark: '[data-section-head]', close: 36, room: () => (tablet() ? 64 : 48), sides: [-1] };
const CARD: Rule = { mark: '[data-card]', close: 4, room: () => 16, sides: [1, -1] };
/** The narrowest a card in a row of several may be. */
const TILE = 180;
/** A set of at most this many cards may change how many sit to a row; a longer one keeps its columns. */
const FEW = 12;
/** A grid of more than this many is a long list: left as it is. */
const MOST_TILES = 60;
/** A card with its photo beside its words needs this much width for both. */
const BESIDE = 544;
/** A photo beside its words is a strip when it is this many times as tall as it is wide. */
const STRIP = 2.2;
/** A page of more cards than this is a list or an app's board: its cards are left where they are. */
const MOST = 200;
/** A column of words narrower than this, beside other things in a row, is a sliver. */
const SLIVER = 96;
/** Between two buttons on one line. */
const BETWEEN = 12;
/** A page of more text blocks or buttons than this is left as it is: the two passes below read each one. */
const MOST_BLOCKS = 1500;

type Ink = { edge: number; left: number; right: number; wide: boolean; band: boolean; words: boolean };
type Kept = [name: string, value: string, priority: string][];

let installed = false;
/** What each changed box had in its own `style`, put back before the page is measured again. */
const changed = new Map<HTMLElement, Kept>();
/** The page's own color, read once a check: a box of that color draws nothing on it. */
let page = '';

export function keepLayoutInOrder() {
  if (installed || typeof document === 'undefined') return;
  installed = true;
  let queued = false;
  const check = () => {
    queued = false;
    for (const [el, kept] of changed) {
      for (const [name, value, priority] of kept) {
        if (value) el.style.setProperty(name, value, priority);
        else el.style.removeProperty(name);
      }
    }
    changed.clear();
    page = getComputedStyle(document.body).backgroundColor;
    const width = document.documentElement.clientWidth;
    for (const media of document.querySelectorAll<HTMLElement>('[data-card] > [data-side]')) {
      const card = media.parentElement;
      if (!card) continue;
      // Measured side by side each time, then stacked if the box is too narrow for both, or the words are so long
      // that the photo beside them is a strip more than twice as tall as it is wide.
      card.removeAttribute('data-stack');
      if (window.innerWidth < 768) continue;
      if (card.clientWidth < BESIDE || media.offsetHeight > media.offsetWidth * STRIP) card.setAttribute('data-stack', '');
    }
    rows();
    squeezed();
    touching();
    for (const band of document.querySelectorAll<HTMLElement>(BAND.mark)) {
      const box = band.getBoundingClientRect();
      // Only a band across the whole screen: one a page set in a column is a card there.
      if (!box.height || box.width < width - 1 || floats(band)) continue;
      settle(band);
      for (const dir of BAND.sides) seam(band, dir, BAND, width);
    }
    for (const head of document.querySelectorAll<HTMLElement>(HEAD.mark)) {
      if (floats(head)) continue;
      seam(head, 1, HEAD, width);
      // A title in a card or on a band starts that box: the box's own edge is what stands over it.
      if (!head.closest(`${CARD.mark}, ${BAND.mark}`)) seam(head, -1, ABOVE, width);
    }
    const cards = document.querySelectorAll<HTMLElement>(CARD.mark);
    if (cards.length > MOST) return;
    for (const card of cards) {
      if (card.parentElement?.closest(CARD.mark) || floats(card)) continue;
      for (const dir of CARD.sides) seam(card, dir, CARD, width);
    }
  };
  const queue = () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(check);
  };
  // Children only: this file's own `style` changes never call it back.
  new MutationObserver(queue).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener('resize', queue);
  queue();
}

/** In a dialog, a menu or anything else laid over the page: not part of its flow. */
const floats = (el: Element) =>
  Boolean(el.closest('[role="dialog"], dialog, [popover], [data-radix-popper-content-wrapper]')) ||
  ['absolute', 'fixed'].includes(getComputedStyle(el).position);

function keep(el: HTMLElement, names: string[]) {
  const kept = changed.get(el) ?? [];
  for (const name of names) {
    if (!kept.some(([had]) => had === name)) kept.push([name, el.style.getPropertyValue(name), el.style.getPropertyPriority(name)]);
  }
  changed.set(el, kept);
}

/** A short text crushed into a sliver by its row: the row wraps, and the words get a readable width. */
function squeezed() {
  const blocks = document.querySelectorAll<HTMLElement>('p, h3, h4, h5');
  if (blocks.length > MOST_BLOCKS) return;
  for (const words of blocks) {
    // Cheap first: most text is wider than a sliver.
    if (!words.offsetWidth || words.offsetWidth >= SLIVER || words.offsetHeight < 64) continue;
    const length = words.textContent?.trim().length ?? 0;
    if (length < 8 || length > 90) continue;
    const style = getComputedStyle(words);
    const line = parseFloat(style.lineHeight) || parseFloat(style.fontSize) * 1.4;
    if (words.offsetHeight < line * 3.5 || style.writingMode !== 'horizontal-tb') continue;
    // The nearest row above it that holds something else too.
    let item: HTMLElement = words;
    let row: HTMLElement | null = null;
    for (let up = 0; up < 4 && item.parentElement && !row; up += 1) {
      const parent: HTMLElement = item.parentElement;
      const box = getComputedStyle(parent);
      if (box.display.includes('flex') && box.flexDirection.startsWith('row') && parent.children.length > 1) row = parent;
      else item = parent;
    }
    // A header's row is folded by the header itself (fit-row.ts); a row that scrolls sideways is meant to be one line.
    if (!row || row.closest('header, nav, [data-kit-row]') || /auto|scroll/.test(getComputedStyle(row).overflowX)) continue;
    keep(row, ['flex-wrap']);
    row.style.setProperty('flex-wrap', 'wrap');
    keep(item, ['min-width']);
    item.style.setProperty('min-width', 'min(100%, 10rem)');
    // What dropped under the words keeps to the row's end, where it was.
    const bottom = item.getBoundingClientRect().bottom;
    for (let next = item.nextElementSibling; next; next = next.nextElementSibling) {
      if (!(next instanceof HTMLElement) || next.getBoundingClientRect().top < bottom - 2) continue;
      keep(next, ['margin-inline-start']);
      next.style.setProperty('margin-inline-start', 'auto');
      break;
    }
  }
}

/** Two buttons in running text with nothing between them: the second keeps a gap from the first. */
function touching() {
  const buttons = document.querySelectorAll<HTMLElement>('button, [role="button"], a');
  if (buttons.length > MOST_BLOCKS) return;
  const flows = new Map<Element, boolean>();
  /** Laid out as text is, not as a row or grid of the page's own. */
  const running = (parent: Element) => {
    let flow = flows.get(parent);
    if (flow === undefined) {
      flow = !/flex|grid/.test(getComputedStyle(parent).display);
      flows.set(parent, flow);
    }
    return flow;
  };
  /** A link drawn as a button (a box of its own), not a word in a sentence. */
  const button = (el: Element) => !el.matches('a') || /^inline-(flex|block|grid)$/.test(getComputedStyle(el).display);
  /** Two halves of one control, joined on purpose: the corners where they meet are square, the outer ones round. */
  const joined = (first: Element, second: Element) => {
    const left = getComputedStyle(first);
    const right = getComputedStyle(second);
    return (
      (parseFloat(left.borderTopRightRadius) === 0 && parseFloat(left.borderTopLeftRadius) > 0) ||
      (parseFloat(right.borderTopLeftRadius) === 0 && parseFloat(right.borderTopRightRadius) > 0)
    );
  };
  for (const first of buttons) {
    const second = first.nextElementSibling;
    if (!(second instanceof HTMLElement) || !second.matches('button, [role="button"], a')) continue;
    const parent = first.parentElement;
    if (!parent || !running(parent) || !button(first) || !button(second)) continue;
    // A header's row, a set of tabs or choices, a toolbar: one control made of several, its own to space.
    if (first.closest('header, nav, [role="group"], [role="tablist"], [role="radiogroup"], [role="toolbar"]')) continue;
    const a = first.getBoundingClientRect();
    const b = second.getBoundingClientRect();
    const gap = b.left - a.right;
    if (!a.width || !b.width || b.top >= a.bottom - 4 || b.bottom <= a.top + 4 || gap < -1 || gap >= 4) continue;
    if (joined(first, second)) continue;
    keep(second, ['margin-inline-start', 'margin-top']);
    second.style.setProperty('margin-inline-start', `${BETWEEN}px`);
    // Pushed onto the next line by that gap: it starts the line, with room above it instead.
    if (second.getBoundingClientRect().top >= a.bottom - 4) {
      second.style.setProperty('margin-inline-start', '0px');
      second.style.setProperty('margin-top', '8px');
    }
  }
}

/**
 * A card placed with `absolute` over a band's lower edge (a sibling after it, in a box around both) goes back into
 * the page under the band, at its own width and centered. Only one with words or fields in it: a wave or a glow laid
 * over the edge is decoration and stays.
 */
function settle(band: HTMLElement) {
  const edge = band.getBoundingClientRect();
  for (let el = band.nextElementSibling; el; el = el.nextElementSibling) {
    if (!(el instanceof HTMLElement) || getComputedStyle(el).position !== 'absolute') continue;
    const box = el.getBoundingClientRect();
    const over = box.top > edge.top + edge.height * 0.4 && box.top < edge.bottom - 4 && box.bottom > edge.bottom + 4;
    if (!over || !(el.innerText?.trim() || el.querySelector('input, select, textarea, button'))) continue;
    const reset = { position: 'relative', inset: 'auto', translate: 'none', transform: 'none', 'margin-left': 'auto', 'margin-right': 'auto' };
    keep(el, Object.keys(reset));
    for (const [name, value] of Object.entries(reset)) el.style.setProperty(name, value, 'important');
  }
}

/** One side of a marked box: `dir` 1 is what follows it, -1 what comes before it. */
function seam(el: HTMLElement, dir: 1 | -1, rule: Rule, width: number) {
  // Most cards have a neighbor right there, well clear of them or beside them (a grid's cards): nothing to measure.
  const next = dir > 0 ? el.nextElementSibling : el.previousElementSibling;
  if (rule === CARD && next) {
    const box = el.getBoundingClientRect();
    const other = next.getBoundingClientRect();
    if (other.height && (dir > 0 ? other.top - box.bottom : box.top - other.bottom) >= rule.close) return;
    if (other.height && Math.min(other.right, box.right) - Math.max(other.left, box.left) < 8) return;
  }
  const side = neighbor(el, dir, width);
  if (!side) return;
  for (let tries = 0; tries < 2; tries += 1) {
    const box = el.getBoundingClientRect();
    const found = ink(side.block, dir, width);
    if (!found) return;
    // Beside the box, or far over it, not after it: not a seam.
    const middle = box.top + box.height / 2;
    if (dir > 0 ? found.edge < middle : found.edge > middle) return;
    if (Math.min(found.right, box.right) - Math.max(found.left, box.left) < 8) return;
    // Under a title, only boxes: a line of words the page wrote there is the title's own.
    if (rule === HEAD && found.words) return;
    const gap = dir > 0 ? found.edge - box.bottom : box.top - found.edge;
    // A full-width colored section may meet a band; another band or a full-width picture keeps the band's room.
    const need = rule === BAND && found.wide && !found.band ? 0 : rule.room();
    if (gap >= (need ? rule.close : 0) - 0.5) return;
    keep(side.after, ['margin-top']);
    const now = parseFloat(getComputedStyle(side.after).marginTop) || 0;
    side.after.style.setProperty('margin-top', `${now + need - gap}px`, 'important');
  }
}

/** The block next to `el` in the page's flow, and the box that follows that seam (the one that moves down). */
function neighbor(el: HTMLElement, dir: 1 | -1, width: number): { block: HTMLElement; after: HTMLElement } | null {
  for (let at: HTMLElement | null = el; at && at !== document.body && at.id !== 'root'; at = at.parentElement) {
    for (
      let sib = dir > 0 ? at.nextElementSibling : at.previousElementSibling;
      sib;
      sib = dir > 0 ? sib.nextElementSibling : sib.previousElementSibling
    ) {
      if (!(sib instanceof HTMLElement)) continue;
      const style = getComputedStyle(sib);
      // Out of the flow (the header, a glow, a badge) or not there.
      if (style.display === 'none' || ['absolute', 'fixed', 'sticky'].includes(style.position)) continue;
      // Nothing drawn in it (a spacer, an anchor): the seam is with what comes after it.
      if (!ink(sib, dir, width)) continue;
      return { block: sib, after: dir > 0 ? sib : at };
    }
  }
  return null;
}

const alpha = (color: string) =>
  color === 'transparent' ? 0 : color.startsWith('rgba(') || color.includes('/') ? parseFloat(/([\d.]+)%?\s*\)$/.exec(color)?.[1] ?? '1') : 1;

/** Whether `el` itself shows: a picture, a field, a color, an edge on the side asked, a shadow. */
function drawn(el: Element, style: CSSStyleDeclaration, dir: 1 | -1) {
  if (el.matches('img, video, canvas, iframe, svg, input, select, textarea, button, [data-band]')) return true;
  return (
    (alpha(style.backgroundColor) > 0.02 && style.backgroundColor !== page) ||
    style.backgroundImage !== 'none' ||
    style.boxShadow !== 'none' ||
    (style.backdropFilter ?? 'none') !== 'none' ||
    (dir > 0
      ? parseFloat(style.borderTopWidth) > 0 && alpha(style.borderTopColor) > 0.02
      : parseFloat(style.borderBottomWidth) > 0 && alpha(style.borderBottomColor) > 0.02)
  );
}

/** The first thing drawn in `el` from the side asked: a box, a picture, a field, or words. */
function ink(el: Element, dir: 1 | -1, width: number): Ink | null {
  const style = getComputedStyle(el);
  if (style.display === 'none' || style.visibility === 'hidden') return null;
  const box = el.getBoundingClientRect();
  // A box of no height draws nothing itself; what it holds may still show past it.
  if (box.width > 0 && box.height > 0 && drawn(el, style, dir)) {
    return {
      edge: dir > 0 ? box.top : box.bottom,
      left: box.left,
      right: box.right,
      wide: box.width >= width - 1,
      band: el.matches('img, video, canvas, iframe, [data-band]'),
      words: false,
    };
  }
  let best: Ink | null = null;
  const nearer = (edge: number) => !best || (edge - best.edge) * dir < 0;
  const range = document.createRange();
  for (const node of el.childNodes) {
    if (node.nodeType !== Node.TEXT_NODE || !node.textContent?.trim()) continue;
    range.selectNodeContents(node);
    const words = range.getBoundingClientRect();
    const edge = dir > 0 ? words.top : words.bottom;
    if (words.height && nearer(edge)) best = { edge, left: words.left, right: words.right, wide: false, band: false, words: true };
  }
  const kids = [...el.children]
    .filter((child) => !['absolute', 'fixed'].includes(getComputedStyle(child).position))
    .map((child) => ({ child, box: child.getBoundingClientRect() }))
    .sort((a, b) => (dir > 0 ? a.box.top - b.box.top : b.box.bottom - a.box.bottom));
  for (const kid of kids) {
    // A box starts where it is, or lower: one that starts past what was found cannot hold anything nearer.
    if (!nearer(dir > 0 ? kid.box.top : kid.box.bottom)) break;
    const found = ink(kid.child, dir, width);
    if (found && nearer(found.edge)) best = found;
  }
  return best;
}

/**
 * A grid of cards never ends in a row with a hole beside it. A few cards take a number of columns that makes every
 * row full, where they fit (three written two to a row sit three to a row, four written three to a row sit four,
 * six written four to a row sit three and three). Otherwise the cards of the last row sit in its middle.
 */
function rows() {
  for (const grid of document.querySelectorAll<HTMLElement>('[class~="grid"], [class*=":grid"]')) {
    const style = getComputedStyle(grid);
    if (style.display !== 'grid' || !style.gridAutoFlow.startsWith('row') || grid.closest('form, table') || floats(grid)) continue;
    const tracks = style.gridTemplateColumns.split(' ').map(parseFloat);
    const cols = tracks.length;
    if (cols < 2 || tracks.some(Number.isNaN) || Math.max(...tracks) - Math.min(...tracks) > 2) continue;
    const kids = [...grid.children].filter((kid): kid is HTMLElement => kid instanceof HTMLElement && kid.offsetWidth > 0);
    const n = kids.length;
    const over = n % cols;
    if (n > MOST_TILES || n <= cols || over === 0 || kids.length !== grid.children.length) continue;
    // Cards of a kind, each in a place the grid gave it: a mosaic's spans, a list's long rows, a table or a map are
    // laid out as they are on purpose.
    const tiles = kids.every((kid) => {
      const own = getComputedStyle(kid);
      if (own.gridColumnStart !== 'auto' || own.gridColumnEnd !== 'auto' || own.gridRowEnd !== 'auto') return false;
      if (own.position !== 'static' && own.position !== 'relative') return false;
      // Things to press or fill in (a day's time slots, a form's fields) keep their places in the grid.
      if (kid.matches('button, label, input, select, textarea')) return false;
      if (kid.offsetWidth > kid.offsetHeight * 6 || kid.querySelector('table, iframe, canvas')) return false;
      // A card with its photo beside its words needs its width.
      if (own.display === 'flex' && own.flexDirection.startsWith('row')) return false;
      return kid.matches('[data-card]') || drawn(kid, own, 1) || Boolean(kid.querySelector(':scope > [data-card], :scope > img'));
    });
    if (!tiles) continue;
    const gap = parseFloat(style.columnGap) || 0;
    const across = tracks.reduce((sum, track) => sum + track, 0) + gap * (cols - 1);
    // One more to a row where each card keeps its width; one fewer where that adds no row.
    const even =
      n <= FEW &&
      [cols + 1, cols - 1].find(
        (count) =>
          count >= 2 &&
          n % count === 0 &&
          (count > cols ? (across - gap * (count - 1)) / count >= TILE : n / count <= Math.ceil(n / cols)),
      );
    if (even) {
      keep(grid, ['grid-template-columns']);
      grid.style.setProperty('grid-template-columns', `repeat(${even}, minmax(0, 1fr))`, 'important');
      continue;
    }
    // The last row's cards in its middle: each moves half the room left beside them (towards the end of the line,
    // in either direction of writing).
    const shift = ((cols - over) * (tracks[0] + gap)) / 2;
    for (const kid of kids.slice(n - over)) {
      keep(kid, ['position', 'inset-inline-start']);
      kid.style.setProperty('position', 'relative', 'important');
      kid.style.setProperty('inset-inline-start', `${shift}px`, 'important');
    }
  }
}
