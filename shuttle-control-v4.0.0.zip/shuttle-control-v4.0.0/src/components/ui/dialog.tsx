import { X } from 'lucide-react';
import { AlertDialog, Dialog as Modal } from 'radix-ui';
import { useCallback, useRef, useState, useSyncExternalStore, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import { Button } from '@/components/ui/button';
import { Sheet } from '@/components/ui/sheet';
import { cn } from '@/lib/utils';

const WORDS = {
  en: { cancel: 'Cancel', confirm: 'Confirm', close: 'Close', failed: "That didn't work. Try again." },
  es: { cancel: 'Cancelar', confirm: 'Confirmar', close: 'Cerrar', failed: 'No funcionó. Inténtalo de nuevo.' },
};
const words = () => (document.documentElement.lang.toLowerCase().startsWith('es') ? WORDS.es : WORDS.en);

/**
 * The last thing pressed. Safari does not focus a button on a click, so there the button that opened a pop-up is not
 * the focused element, and focus could not go back to it when the pop-up closed.
 */
let pressed: HTMLElement | null = null;
if (typeof document !== 'undefined') {
  document.addEventListener(
    'pointerdown',
    (event) => {
      pressed = event.target instanceof Element ? event.target.closest<HTMLElement>('button, a, [role="button"], [tabindex]') : null;
    },
    true,
  );
}

/** A phone-wide screen, followed as the window changes. */
const PHONE = '(max-width: 639px)';
function usePhone(): boolean {
  return useSyncExternalStore(
    (changed) => {
      const query = window.matchMedia(PHONE);
      query.addEventListener('change', changed);
      return () => query.removeEventListener('change', changed);
    },
    () => window.matchMedia(PHONE).matches,
    () => false,
  );
}

/**
 * A pop-up for a form or for one thing's details (add a task, edit a habit, an order): on a computer a card in the
 * middle of the screen over a dimmed page; on a phone the kit's `Sheet`, which slides up from the bottom and keeps
 * its fields above the keyboard, as an iPhone presents a form. Its title, an optional line under it and a Close
 * button come with it, so what goes inside needs none: put the form and its buttons there. Escape, a press outside
 * and Close all close it, and focus returns to what opened it; a long form scrolls under the title. Use it instead
 * of a hand-made overlay (`fixed inset-0`), which misses those and opens off a phone's screen. Wider content:
 * `className="max-w-2xl"`. A yes or no question is `ConfirmDialog`, below. Content that shows its own heading
 * passes `label` instead of `title`, as the kit's `Sheet` does: the name for screen readers, with no title row
 * (a production bakery's basket wrote `label` and its own heading, and opened under an empty title line and with
 * no name, 2026-11-13).
 *
 *   <Dialog open={adding} onOpenChange={setAdding} title="New task" text="It lands in To do.">
 *     <form onSubmit={add} className="grid gap-4">…<Button>Add task</Button></form>
 *   </Dialog>
 */
export function Dialog({
  open,
  onOpenChange,
  title,
  label,
  text,
  children,
  className,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** The heading shown at the top. */
  title?: string;
  /** Instead of `title`, when what goes inside shows its own heading: the pop-up's name, not shown. */
  label?: string;
  /** One line under the title: what this is for, or what happens next. */
  text?: ReactNode;
  children: ReactNode;
  /** The card's width on a computer (`max-w-2xl` for a wide form); a phone's sheet is always the screen's width. */
  className?: string;
}) {
  const phone = usePhone();
  // The sheet stays in the page once shown (it slides away); one that never opened adds nothing, so a list with an
  // edit pop-up per row does not carry a hidden sheet per row.
  const [shown, setShown] = useState(open);
  if (open && !shown) setShown(true);
  const opener = useRef<HTMLElement | null>(null);
  if (phone) {
    if (!shown) return null;
    return (
      <Sheet open={open} onOpenChange={onOpenChange} label={title ?? label ?? ''}>
        {title && <h2 className="text-xl leading-snug font-semibold tracking-tight text-balance">{title}</h2>}
        {text != null && <p className="mt-1.5 leading-relaxed opacity-75">{text}</p>}
        {title || text != null ? <div className="mt-5">{children}</div> : children}
      </Sheet>
    );
  }
  return (
    <Modal.Root open={open} onOpenChange={onOpenChange}>
      <Modal.Portal>
        <Modal.Overlay className="fixed inset-0 z-50 bg-black/45 backdrop-blur-[2px]" />
        <Modal.Content
          {...(text == null ? { 'aria-describedby': undefined } : {})}
          // Typing starts in the form's first field; with no field the card itself is focused, never its Close
          // button, which would open with a focus ring on the one thing nobody came for.
          onOpenAutoFocus={(event) => {
            const card = event.currentTarget as HTMLElement;
            const field = card.querySelector<HTMLElement>('[autofocus], input:not([type=hidden], [type=range]), textarea');
            // Still the button that opened it: remembered here, because the page opens it from its own button, not
            // radix's trigger, and radix returns focus only to that (focus fell to the page: dev, 2026-11-12).
            const focused = document.activeElement;
            opener.current = focused instanceof HTMLElement && focused !== document.body ? focused : pressed;
            event.preventDefault();
            (field ?? card).focus();
          }}
          onCloseAutoFocus={(event) => {
            event.preventDefault();
            opener.current?.focus({ preventScroll: true });
          }}
          className={cn(
            'fixed inset-0 z-50 m-auto flex h-fit max-h-[calc(100dvh-2rem)] w-[calc(100vw-2rem)] max-w-lg flex-col rounded-3xl bg-white text-zinc-900 shadow-[0_24px_64px_-12px_rgb(0_0_0/0.5)] outline-none dark:bg-zinc-900 dark:text-zinc-50',
            className,
          )}
        >
          {/* With no title, only the Close button's slim row, as the kit's Sheet has above its content. */}
          <div className={cn('flex items-start gap-3 px-6 sm:px-7', title ? 'pt-6 sm:pt-7' : 'pt-4 sm:pt-5')}>
            <div className="min-w-0 flex-1">
              <Modal.Title className={title ? 'text-xl leading-snug font-semibold tracking-tight text-balance' : 'sr-only'}>
                {title ?? label}
              </Modal.Title>
              {text != null && <Modal.Description className="mt-1.5 leading-relaxed opacity-75">{text}</Modal.Description>}
            </div>
            {/* 44px to press, a 30px gray circle to see, as an iPhone sheet's Close. */}
            <Modal.Close
              aria-label={words().close}
              className="group -mt-2 -mr-2 grid size-11 shrink-0 place-items-center rounded-full outline-none"
            >
              <span className="grid size-[30px] place-items-center rounded-full bg-[rgb(120_120_128/0.16)] text-zinc-600 transition-colors group-hover:bg-[rgb(120_120_128/0.28)] group-focus-visible:ring-2 group-focus-visible:ring-[var(--brand)] dark:text-zinc-300">
                <X aria-hidden className="size-4" strokeWidth={2.5} />
              </span>
            </Modal.Close>
          </div>
          {/* The form scrolls here, under the title, when it is taller than the screen. */}
          <div
            className={cn(
              'min-h-0 overflow-y-auto overscroll-contain px-6 pb-6 sm:px-7 sm:pb-7',
              title || text != null ? 'pt-5' : '-mt-2',
            )}
          >
            {children}
          </div>
        </Modal.Content>
      </Modal.Portal>
    </Modal.Root>
  );
}

export type ConfirmOptions = {
  title: ReactNode;
  /** What happens, in a sentence: "Your seats go back on sale and the $90 is refunded." */
  text?: ReactNode;
  /** The action, said as the button says it: "Cancel order", "Delete event". */
  confirmLabel?: string;
  cancelLabel?: string;
  /** A red action button, for deleting, cancelling or refunding. */
  danger?: boolean;
  /**
   * The work, run with the dialog still open and its button busy: it closes when the work finishes, and stays open
   * with the error's words when it throws, so the person can try again or cancel.
   */
  onConfirm?: () => unknown;
};

/**
 * A question before something that cannot be taken back (cancel an order, delete an event, refund a ticket): in the
 * middle of the screen at every size, over a dimmed page, on the page's top layer (a dialog drawn in the page opened
 * 5,800 px down a phone's page: production 2026-10-22, a ticket site's confirmations). Escape and Cancel close it; the
 * action's button shows it is working and the dialog waits for it. Words follow `<html lang>` (English, or Spanish
 * for `es`) unless given. Use it instead of the browser's `confirm()`, which looks like an error from the browser.
 *
 *   const confirm = useConfirm();
 *   if (await confirm({ title: 'Cancel this order?', confirmLabel: 'Cancel order', danger: true, onConfirm: cancel }))
 *
 * or controlled: `<ConfirmDialog open={open} onOpenChange={setOpen} title=… onConfirm=… />`.
 */
export function ConfirmDialog({
  open,
  onOpenChange,
  title,
  text,
  confirmLabel,
  cancelLabel,
  danger,
  onConfirm,
}: ConfirmOptions & { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState('');
  const w = words();
  const close = (next: boolean) => {
    if (busy) return;
    setProblem('');
    onOpenChange(next);
  };
  const run = async () => {
    setBusy(true);
    setProblem('');
    try {
      await onConfirm?.();
      setBusy(false);
      onOpenChange(false);
    } catch (cause) {
      setBusy(false);
      const message = (cause as { userMessage?: unknown; message?: unknown } | null) ?? {};
      setProblem(
        typeof message.userMessage === 'string'
          ? message.userMessage
          : typeof message.message === 'string' && message.message
            ? message.message
            : w.failed,
      );
    }
  };
  return (
    <AlertDialog.Root open={open} onOpenChange={close}>
      <AlertDialog.Portal>
        <AlertDialog.Overlay className="fixed inset-0 z-50 bg-black/45 backdrop-blur-[2px]" />
        <AlertDialog.Content
          {...(text == null ? { 'aria-describedby': undefined } : {})}
          className="fixed inset-0 z-50 m-auto h-fit max-h-[calc(100dvh-2rem)] w-[min(28rem,calc(100vw-2rem))] overflow-y-auto rounded-3xl bg-white p-6 text-zinc-900 shadow-[0_24px_64px_-12px_rgb(0_0_0/0.5)] outline-none sm:p-7 dark:bg-zinc-900 dark:text-zinc-50"
        >
          <AlertDialog.Title className="text-xl leading-snug font-semibold tracking-tight text-balance">{title}</AlertDialog.Title>
          {text != null && (
            <AlertDialog.Description className="mt-2 leading-relaxed opacity-75">{text}</AlertDialog.Description>
          )}
          {problem && (
            <p role="alert" className="mt-4 text-sm text-red-600 dark:text-red-400">
              {problem}
            </p>
          )}
          {/* On a phone the two buttons stack full width with the action on top, as an iPhone's alert. */}
          <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
            <AlertDialog.Cancel asChild>
              <Button variant="gray" disabled={busy} className="max-sm:w-full">
                {cancelLabel ?? w.cancel}
              </Button>
            </AlertDialog.Cancel>
            <Button
              busy={busy}
              onClick={() => void run()}
              className={cn('max-sm:w-full', danger && 'bg-red-600 text-white hover:bg-red-600 dark:bg-red-500')}
            >
              {confirmLabel ?? w.confirm}
            </Button>
          </div>
        </AlertDialog.Content>
      </AlertDialog.Portal>
    </AlertDialog.Root>
  );
}

/** Opens a `ConfirmDialog` of its own and answers whether the person went ahead (and its `onConfirm` finished). */
function ask(options: ConfirmOptions): Promise<boolean> {
  return new Promise((resolve) => {
    const host = document.createElement('div');
    document.body.append(host);
    const root = createRoot(host);
    let done = false;
    let wentAhead = false;
    const finish = (went: boolean) => {
      if (done) return;
      done = true;
      resolve(went);
      // After its closing animation.
      setTimeout(() => {
        root.unmount();
        host.remove();
      }, 400);
    };
    function Asked() {
      const [open, setOpen] = useState(true);
      return (
        <ConfirmDialog
          {...options}
          open={open}
          onConfirm={async () => {
            await options.onConfirm?.();
            wentAhead = true;
          }}
          onOpenChange={(next) => {
            setOpen(next);
            if (!next) finish(wentAhead);
          }}
        />
      );
    }
    root.render(<Asked />);
  });
}

/** `confirm(options)`: true once the person went ahead and `onConfirm` (if any) finished, false when they backed out. */
export function useConfirm(): (options: ConfirmOptions) => Promise<boolean> {
  return useCallback(ask, []);
}
