import { useEffect, useRef, useState, type ReactNode } from 'react';
import { cn } from '@/lib/utils';

/**
 * The page's first screen: a full-bleed photo of the subject under a dark fade, the words on the left in line with
 * the header's name (never centered), the headline in long lines up to 70% of the screen, its line narrower, the
 * buttons under them; on phones the words sit below the middle over a bottom fade. The floating header sits over
 * it. `position` is the photo's `object-position`: make or crop the photo with its subject on the right.
 *
 * Only the home page is a landing page. On any other page (a gallery, the services, booking) it is that page's short
 * header, the photo a band under the floating header with the page's title, so what the visitor clicked for shows
 * on the first screen: every tab of a barber's site opened on a screen-high photo of its own (owner, 2026-11-04:
 * "the tabs should open the things directly"). A page that is a tool people work in (a chat, a practice screen, a
 * board) has no hero at all: it opens on the tool.
 *
 * The words read on any photo: where the picture behind them is bright (a bowl of cream popcorn, a laptop's white
 * screen), the fade under them deepens by itself, as little as makes them read. With the standing fade alone a
 * popcorn site's label lay on cream at about 4:1 on a phone, and a line under a headline at 3.5:1 (production,
 * 2026-11-13).
 */
/** White words on what is behind them, as a contrast ratio: what the fade must reach for small words, and for the headline. */
const READS = { small: 5, headline: 3.5 };
/** A fade of three stops, at `t` of its way: the black it lays over the photo there. */
const fade = (t: number, from: number, via: number, to: number) =>
  t < 0.5 ? from + (via - from) * t * 2 : via + (to - via) * (t - 0.5) * 2;

/**
 * How much deeper the fade under the words must be, 0 to 0.5: the part of the photo each line lies on, as
 * `object-fit: cover` draws it, under the standing fade (the same stops as the classes below), judged by its bright
 * parts, not its average. The least that makes every line read; a photo that already does gets none. A picture from
 * another site cannot be read and keeps the standing fade.
 */
function deeperFade(img: HTMLImageElement, box: HTMLElement): number {
  try {
    const frame = box.getBoundingClientRect();
    if (!img.naturalWidth || !frame.width || !frame.height) return 0;
    const scale = Math.max(frame.width / img.naturalWidth, frame.height / img.naturalHeight);
    const [x = 0.5, y = 0.5] = getComputedStyle(img)
      .objectPosition.split(' ')
      .map((part) => (part.endsWith('%') ? parseFloat(part) / 100 : 0.5));
    const startX = (frame.width - img.naturalWidth * scale) * x;
    const startY = (frame.height - img.naturalHeight * scale) * y;
    const across = 16;
    const down = 6;
    const canvas = document.createElement('canvas');
    canvas.width = across;
    canvas.height = down;
    const paint = canvas.getContext('2d', { willReadFrequently: true });
    if (!paint) return 0;
    // From md up the fades run left to right, below it bottom to top (the classes on the two layers below).
    const sideways = window.matchMedia('(min-width: 768px)').matches;
    const linear = (part: number) => (part <= 0.03928 ? part / 12.92 : ((part + 0.055) / 1.055) ** 2.4);
    /** Each line's photo, and how bright its bright parts are (relative luminance) with this much more fade. */
    const lines = [...box.querySelectorAll('.hero-words > :is(h1, p)')].flatMap((el) => {
      const range = document.createRange();
      range.selectNodeContents(el);
      const words = range.getBoundingClientRect();
      if (words.width <= 0 || words.height <= 0) return [];
      const left = words.left - frame.left;
      const top = words.top - frame.top;
      paint.drawImage(img, (left - startX) / scale, (top - startY) / scale, words.width / scale, words.height / scale, 0, 0, across, down);
      const pixels = paint.getImageData(0, 0, across, down).data;
      const bright = (deeper: number) => {
        const seen: number[] = [];
        for (let row = 0; row < down; row += 1) {
          for (let col = 0; col < across; col += 1) {
            const t = sideways
              ? (left + ((col + 0.5) / across) * words.width) / frame.width
              : 1 - (top + ((row + 0.5) / down) * words.height) / frame.height;
            const kept = ((1 - (sideways ? fade(t, 0.75, 0.4, 0.05) : fade(t, 0.85, 0.45, 0.1))) * (1 - deeper * fade(t, 1, 0.6, 0))) / 255;
            const at = (row * across + col) * 4;
            seen.push(
              0.2126 * linear((pixels[at] ?? 0) * kept) + 0.7152 * linear((pixels[at + 1] ?? 0) * kept) + 0.0722 * linear((pixels[at + 2] ?? 0) * kept),
            );
          }
        }
        seen.sort((one, other) => one - other);
        return seen[Math.floor(seen.length * 0.9)] ?? 0;
      };
      return [{ bright, reads: el.matches('h1') ? READS.headline : READS.small }];
    });
    for (const deeper of [0, 0.2, 0.35]) {
      if (lines.every((line) => 1.05 / (line.bright(deeper) + 0.05) >= line.reads)) return deeper;
    }
    return lines.length ? 0.5 : 0;
  } catch {
    return 0;
  }
}

/** The first screen's photo, for a section given none of its own to show (the FAQ's card, faq.tsx). */
let heroPhoto: string | undefined;
export const heroImage = () => heroPhoto;

export function Hero({
  src,
  alt = '',
  position,
  eyebrow,
  title,
  intro,
  actions,
  className,
}: {
  src: string;
  alt?: string;
  position?: string;
  /** A few words over the headline, such as "Licensed counseling · In person and online". */
  eyebrow?: ReactNode;
  title: ReactNode;
  /**
   * The line under the headline: ONE short sentence a visitor reads at a glance, never two and never a paragraph
   * (owner, 2026-10-26: a 30-word line under anela.ai's headline was "too long"). The rest goes in the sections below.
   */
  intro?: ReactNode;
  /** One or two links styled with `buttonVariants` (the main one first). */
  actions?: ReactNode;
  className?: string;
}) {
  // The home page: `/`, or a language's own root (`/es`).
  const inner =
    typeof window !== 'undefined' && !/^\/?(?:[a-z]{2}(?:-[a-zA-Z]{2})?\/?)?(?:index\.html)?$/.test(window.location.pathname);
  if (!inner) heroPhoto = src;
  const band = useRef<HTMLElement>(null);
  const picture = useRef<HTMLImageElement>(null);
  const [deeper, setDeeper] = useState(0);
  useEffect(() => {
    const img = picture.current;
    const box = band.current;
    if (!img || !box) return;
    const read = () => setDeeper(deeperFade(img, box));
    if (img.complete) read();
    img.addEventListener('load', read);
    const watch = new ResizeObserver(read);
    watch.observe(box);
    return () => {
      img.removeEventListener('load', read);
      watch.disconnect();
    };
  }, [src]);
  return (
    <section
      ref={band}
      // A full-width band: base.css keeps room between it and the next band or unspaced content.
      data-band=""
      // On an inner page, base.css trims the next section's top padding so its content shows under the header.
      data-page-header={inner ? '' : undefined}
      className={cn(
        'relative isolate flex items-end overflow-hidden bg-neutral-950 text-white',
        inner ? 'min-h-[22rem] md:min-h-[26rem]' : 'min-h-svh md:items-center',
        className,
      )}
    >
      <img
        ref={picture}
        src={src}
        alt={alt}
        fetchPriority="high"
        className="absolute inset-0 -z-10 size-full object-cover"
        style={position ? { objectPosition: position } : undefined}
      />
      <div
        aria-hidden
        className="absolute inset-0 -z-10 bg-gradient-to-t from-black/85 via-black/45 to-black/10 md:bg-gradient-to-r md:from-black/75 md:via-black/40 md:to-black/5"
      />
      {/* The same fade again, as deep as a bright photo needs (`deeperFade`); none on a dark one. */}
      <div
        aria-hidden
        className="absolute inset-0 -z-10 bg-gradient-to-t from-black via-black/60 to-transparent transition-opacity duration-300 md:bg-gradient-to-r"
        style={{ opacity: deeper }}
      />
      {/* On a phone the words end a sixth of the screen above its foot, not at it (owner, 2026-10-22: "should we put
          the mobile headline more up?"; at 56 px the buttons sat on the screen's edge). */}
      <div
        className={cn(
          'hero-words mx-auto w-full max-w-7xl px-5 sm:px-8',
          inner ? 'pt-28 pb-10 md:pb-12' : 'pt-28 pb-[max(3.5rem,16svh)] md:py-32',
        )}
      >
        {eyebrow && <p className="text-sm font-medium uppercase tracking-[0.14em] text-white/85">{eyebrow}</p>}
        <h1
          className={cn(
            'leading-[1.05] font-semibold tracking-tight text-pretty md:max-w-[70vw]',
            inner ? 'text-4xl md:text-5xl' : 'text-4xl sm:text-5xl lg:text-6xl',
            eyebrow && 'mt-4',
          )}
        >
          {title}
        </h1>
        {intro && <p className={cn('max-w-xl text-lg text-white/90 md:text-xl', inner ? 'mt-3' : 'mt-6')}>{intro}</p>}
        {actions && <div className={cn('flex flex-wrap gap-3', inner ? 'mt-6' : 'mt-8')}>{actions}</div>}
      </div>
    </section>
  );
}
