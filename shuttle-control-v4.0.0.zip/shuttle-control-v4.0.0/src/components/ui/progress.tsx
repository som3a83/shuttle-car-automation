import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';

/**
 * How far along something is (a day's goal, step 2 of 5, an upload): a rounded track that fills with the brand color,
 * or with `color` when each bar has its own (a habit's, a category's). `label` names it above on the left and the
 * amount shows on the right: the percent, or `valueLabel` in words ("2 of 6"). Without a `label` it is the bar alone,
 * for a card that already says what it measures. The fill glides when the value changes. `className` styles the
 * whole block.
 *
 *   <Progress label="Drink water" value={2} max={6} valueLabel="2 of 6" />
 */
export function Progress({
  value,
  max = 100,
  label,
  valueLabel,
  color,
  className,
}: {
  value: number;
  max?: number;
  label?: string;
  /** The amount in words; the percent when left out. */
  valueLabel?: ReactNode;
  /** Any CSS color for this bar's fill; the brand color when left out. */
  color?: string;
  className?: string;
}) {
  const percent = max > 0 ? Math.min(100, Math.max(0, (value / max) * 100)) : 0;
  return (
    <div className={cn('grid gap-2', className)}>
      {(label != null || valueLabel != null) && (
        <div className="flex items-baseline justify-between gap-4 text-sm">
          <span className="min-w-0 font-medium">{label}</span>
          <span className="shrink-0 tabular-nums opacity-70">{valueLabel ?? `${Math.round(percent)}%`}</span>
        </div>
      )}
      <div
        role="progressbar"
        aria-label={label}
        aria-valuemin={0}
        aria-valuemax={max}
        aria-valuenow={Math.min(max, Math.max(0, value))}
        className="h-2 overflow-hidden rounded-full bg-[rgb(120_120_128/0.2)]"
      >
        {/* Slid in from the left, so its end stays round at every amount. */}
        <div
          className="h-full rounded-full bg-[var(--brand)] transition-[translate] duration-300 ease-out"
          style={{ translate: `${percent - 100}% 0`, backgroundColor: color }}
        />
      </div>
    </div>
  );
}
