import { Minus, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

const WORDS = { en: { less: 'Decrease', more: 'Increase' }, es: { less: 'Menos', more: 'Más' } };
const words = () =>
  typeof document !== 'undefined' && document.documentElement.lang.toLowerCase().startsWith('es') ? WORDS.es : WORDS.en;

/**
 * A small whole number stepped down and up (guests, a quantity, times a day): the iOS stepper, minus and plus in one
 * capsule with the number between them. Its label is on the left and the stepper on the right, as the kit's `Switch`
 * row. Each button is 40px for a finger and dims at its limit. Inside a `<form>`, `name` sends the number.
 * `className` styles the row.
 *
 *   <Stepper label="Guests" value={guests} onValueChange={setGuests} min={1} max={8} />
 */
export function Stepper({
  value,
  onValueChange,
  min = 0,
  max = Number.POSITIVE_INFINITY,
  step = 1,
  label,
  name,
  className,
}: {
  value: number;
  onValueChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  label: string;
  name?: string;
  className?: string;
}) {
  const w = words();
  const move = (by: number) => onValueChange(Math.min(max, Math.max(min, value + by)));
  const button =
    'grid size-10 shrink-0 place-items-center rounded-full outline-none transition-colors hover:bg-[rgb(120_120_128/0.16)] focus-visible:ring-2 focus-visible:ring-[var(--brand)] disabled:opacity-30 disabled:hover:bg-transparent';
  return (
    <div role="group" aria-label={label} className={cn('flex min-h-11 items-center justify-between gap-4', className)}>
      <span>{label}</span>
      <div className="inline-flex h-11 shrink-0 items-center rounded-full bg-[rgb(120_120_128/0.16)] p-0.5">
        <button type="button" aria-label={w.less} disabled={value <= min} onClick={() => move(-step)} className={button}>
          <Minus aria-hidden className="size-4" strokeWidth={2.5} />
        </button>
        {/* Room for three digits, so the buttons do not move as the number grows. */}
        <output aria-live="polite" className="min-w-10 px-1 text-center text-base font-medium tabular-nums">
          {value.toLocaleString()}
        </output>
        <button type="button" aria-label={w.more} disabled={value >= max} onClick={() => move(step)} className={button}>
          <Plus aria-hidden className="size-4" strokeWidth={2.5} />
        </button>
      </div>
      {name !== undefined && <input type="hidden" name={name} value={value} />}
    </div>
  );
}
