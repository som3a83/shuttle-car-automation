import { useId, type CSSProperties, type ReactNode } from 'react';
import { cn } from '@/lib/utils';

/**
 * A value on a range, dragged or moved with the arrow keys (the iOS slider): a white thumb on a thin track, filled
 * with the brand color up to the thumb. Its `label` is shown above on the left and the value on the right;
 * `valueLabel` words the value ("6 times", "8%"). It is the browser's own range field underneath, so a finger, a
 * mouse and the keyboard all move it, and inside a `<form>` `name` sends it. `className` styles the whole block.
 *
 *   <Slider label="Tax" value={tax} onValueChange={setTax} max={25} valueLabel={`${tax}%`} />
 */
export function Slider({
  value,
  onValueChange,
  min = 0,
  max = 100,
  step = 1,
  label,
  valueLabel,
  name,
  disabled,
  className,
}: {
  value: number;
  onValueChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  label: string;
  /** The value in words; the number itself when left out. */
  valueLabel?: ReactNode;
  name?: string;
  disabled?: boolean;
  className?: string;
}) {
  const id = useId();
  const part = max > min ? Math.min(1, Math.max(0, (value - min) / (max - min))) : 0;
  return (
    <div className={cn('grid gap-1', className)}>
      <div className="flex items-baseline justify-between gap-4">
        <label htmlFor={id} className="text-sm font-medium">
          {label}
        </label>
        <output htmlFor={id} className="text-sm tabular-nums opacity-70">
          {valueLabel ?? value}
        </output>
      </div>
      <input
        id={id}
        type="range"
        name={name}
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        onChange={(event) => onValueChange(Number(event.target.value))}
        // Where the fill ends: the thumb's middle, which travels from half a thumb in to half a thumb short.
        style={{ '--at': `calc(14px + (100% - 28px) * ${part})` } as CSSProperties}
        className={cn(
          // 44px tall to press; the track and thumb are drawn inside it.
          'block h-11 w-full cursor-pointer appearance-none bg-transparent outline-none disabled:cursor-default disabled:opacity-40',
          '[&::-webkit-slider-runnable-track]:h-1.5 [&::-webkit-slider-runnable-track]:rounded-full [&::-webkit-slider-runnable-track]:[background:linear-gradient(to_right,var(--brand)_var(--at),rgb(120_120_128/0.24)_var(--at))]',
          '[&::-webkit-slider-thumb]:-mt-[11px] [&::-webkit-slider-thumb]:size-7 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:shadow-[0_0_0_0.5px_rgb(0_0_0/0.06),0_0.5px_4px_rgb(0_0_0/0.14),0_6px_13px_rgb(0_0_0/0.14)]',
          'focus-visible:[&::-webkit-slider-thumb]:shadow-[0_0_0_4px_color-mix(in_oklab,var(--brand)_35%,transparent),0_0.5px_4px_rgb(0_0_0/0.14),0_6px_13px_rgb(0_0_0/0.14)]',
          // Firefox draws the filled part itself.
          '[&::-moz-range-track]:h-1.5 [&::-moz-range-track]:rounded-full [&::-moz-range-track]:bg-[rgb(120_120_128/0.24)] [&::-moz-range-progress]:h-1.5 [&::-moz-range-progress]:rounded-full [&::-moz-range-progress]:bg-[var(--brand)]',
          '[&::-moz-range-thumb]:size-7 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-white [&::-moz-range-thumb]:shadow-[0_0_0_0.5px_rgb(0_0_0/0.06),0_0.5px_4px_rgb(0_0_0/0.14),0_6px_13px_rgb(0_0_0/0.14)]',
          'focus-visible:[&::-moz-range-thumb]:shadow-[0_0_0_4px_color-mix(in_oklab,var(--brand)_35%,transparent),0_0.5px_4px_rgb(0_0_0/0.14),0_6px_13px_rgb(0_0_0/0.14)]',
        )}
      />
    </div>
  );
}
