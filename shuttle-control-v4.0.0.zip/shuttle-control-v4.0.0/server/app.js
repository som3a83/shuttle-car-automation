import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { openDb } from './db.js';
import { diagnose } from './diagnostics.js';
import { publicProtocols } from './protocols.js';
import { seedSim, tick } from './sim.js';
import { registerV31, BACKUP_TABLES } from './v31.js';
import { registerV40 } from './v40.js';

const PUBLIC = path.join(path.dirname(fileURLToPath(import.meta.url)), 'public');
const RANK = { viewer: 1, operator: 2, technician: 3, admin: 4, super_admin: 5 };
const SESSION_MS = 8 * 3600e3;
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const now = () => new Date().toISOString();

export function hashPw(pw) {
  const s = crypto.randomBytes(16);
  return s.toString('hex') + ':' + crypto.scryptSync(pw, s, 64).toString('hex');
}
function checkPw(pw, stored) {
  const [s, h] = stored.split(':');
  return crypto.timingSafeEqual(crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64), Buffer.from(h, 'hex'));
}
class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }
const str = (v, max = 200, req = true) => {
  if (v == null || v === '') { if (req) throw new HttpError(400, 'missing field'); return null; }
  if (typeof v !== 'string' || v.length > max) throw new HttpError(400, 'invalid field');
  return v.trim();
};
const oneOf = (v, list) => { if (!list.includes(v)) throw new HttpError(400, 'invalid value, allowed: ' + list.join('|')); return v; };
const int = (v, min, max) => { if (!Number.isInteger(v) || v < min || v > max) throw new HttpError(400, 'invalid number'); return v; };
const audit = (db, actor, action, detail) => db.prepare('INSERT INTO audit(actor,action,detail,ts) VALUES(?,?,?,?)').run(actor, action, detail ?? null, now());
const SEV = ['info', 'low', 'medium', 'high', 'critical'];

function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = '', n = 0;
    req.on('data', (c) => { n += c.length; if (n > 8e6) { reject(new HttpError(413, 'body too large')); req.destroy(); } else d += c; });
    req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch { reject(new HttpError(400, 'invalid JSON')); } });
  });
}

const vehicleSql = `SELECT v.*, m.name AS manufacturer, b.code AS battery_code, b.charge AS battery_charge, b.state AS battery_state
  FROM vehicles v LEFT JOIN manufacturers m ON m.id=v.manufacturer_id LEFT JOIN batteries b ON b.vehicle_id=v.id`;
const withOnline = (v) => ({ ...v, online: v.data_source !== 'OFFLINE' && !!v.last_seen && Date.now() - Date.parse(v.last_seen) < 120000 });

export function createApp({ dbPath = process.env.DB_PATH || 'data/shuttle.db', simulation = true } = {}) {
  const db = openDb(dbPath);
  const fails = new Map();
  if (!db.prepare('SELECT 1 FROM users LIMIT 1').get()) {
    const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
    db.prepare('INSERT INTO users(username,pass_hash,role,created_at) VALUES(?,?,?,?)').run('admin', hashPw(pw), 'super_admin', now());
    if (!process.env.ADMIN_PASSWORD) console.log(`FIRST RUN - super admin created. username: admin  password: ${pw}  (shown once; change it)`);
    for (const [n, c] of [['Cassioli', 'Italy'], ['Craftsman', ''], ['ACME', '']])
      db.prepare('INSERT INTO manufacturers(name,country) VALUES(?,?)').run(n, c);
  }

  const routes = [];
  const add = (m, p, role, fn) => routes.push({ m, re: new RegExp('^' + p.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), role, fn });
  const getVehicle = (id) => { const v = db.prepare(vehicleSql + ' WHERE v.id=?').get(id); if (!v) throw new HttpError(404, 'not found'); return v; };

  add('GET', '/api/health', null, () => ({ ok: true, version: fs.readFileSync(path.join(PUBLIC, '..', 'VERSION'), 'utf8').trim() }));
  add('POST', '/api/login', null, ({ body }) => {
    const u = str(body.username, 64), p = str(body.password, 200);
    const f = fails.get(u);
    if (f && f.n >= 5 && Date.now() < f.until) throw new HttpError(429, 'too many attempts, retry later');
    const row = db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(u);
    if (!row || !checkPw(p, row.pass_hash)) {
      fails.set(u, { n: (f?.n || 0) + 1, until: Date.now() + 60000 });
      audit(db, u, 'login_failed');
      throw new HttpError(401, 'invalid credentials');
    }
    fails.delete(u);
    const token = crypto.randomBytes(32).toString('hex');
    db.prepare('INSERT INTO sessions(token_hash,user_id,exp) VALUES(?,?,?)').run(sha(token), row.id, Date.now() + SESSION_MS);
    audit(db, u, 'login');
    return { token, user: { username: row.username, role: row.role } };
  });
  add('POST', '/api/logout', 'viewer', ({ user, token }) => { db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha(token)); audit(db, user.username, 'logout'); return { ok: true }; });
  add('GET', '/api/me', 'viewer', ({ user }) => ({ username: user.username, role: user.role }));

  add('GET', '/api/dashboard', 'viewer', () => {
    const vs = db.prepare(vehicleSql).all().map(withOnline);
    const count = (k) => vs.reduce((a, v) => ((a[v[k]] = (a[v[k]] || 0) + 1), a), {});
    return {
      total: vs.length, online: vs.filter((v) => v.online).length, byStatus: count('status'), bySource: count('data_source'),
      openFaults: db.prepare("SELECT COUNT(*) c FROM faults WHERE status!='closed'").get().c,
      lowBatteries: db.prepare("SELECT COUNT(*) c FROM batteries WHERE charge<=30 AND state!='charging'").get().c,
    };
  });

  add('GET', '/api/vehicles', 'viewer', () => db.prepare(vehicleSql + ' ORDER BY v.code').all().map(withOnline));
  add('POST', '/api/vehicles', 'admin', ({ body, user }) => {
    const code = str(body.code, 40);
    if (db.prepare('SELECT 1 FROM vehicles WHERE code=?').get(code)) throw new HttpError(409, 'code already exists');
    const mid = body.manufacturer_id == null ? null : int(body.manufacturer_id, 1, 1e9);
    const r = db.prepare('INSERT INTO vehicles(code,manufacturer_id,model,created_at) VALUES(?,?,?,?)').run(code, mid, str(body.model, 80, false), now());
    audit(db, user.username, 'vehicle_create', code);
    return withOnline(getVehicle(r.lastInsertRowid));
  });
  add('PATCH', '/api/vehicles/:id', 'admin', ({ params, body, user }) => {
    const v = getVehicle(params.id);
    if (body.status !== undefined) {
      oneOf(body.status, ['running', 'stopped', 'idle', 'charging', 'fault', 'offline']);
      if (v.data_source !== 'OFFLINE') throw new HttpError(409, 'status of a live/simulated source cannot be set manually');
      db.prepare('UPDATE vehicles SET status=? WHERE id=?').run(body.status, v.id);
    }
    if (body.model !== undefined) db.prepare('UPDATE vehicles SET model=? WHERE id=?').run(str(body.model, 80, false), v.id);
    audit(db, user.username, 'vehicle_update', v.code);
    return withOnline(getVehicle(v.id));
  });
  add('GET', '/api/vehicles/:id/signals', 'viewer', ({ params }) => {
    const v = getVehicle(params.id);
    return { vehicle: v.code, data_source: v.data_source,
      signals: db.prepare('SELECT r.signal,r.kind,r.value,r.source,r.ts FROM readings r JOIN (SELECT signal, MAX(id) mid FROM readings WHERE vehicle_id=? GROUP BY signal) x ON r.id=x.mid ORDER BY r.signal').all(v.id) };
  });
  add('GET', '/api/vehicles/:id/diagnose', 'viewer', ({ params }) => {
    const v = getVehicle(params.id);
    const battery = db.prepare('SELECT * FROM batteries WHERE vehicle_id=?').get(v.id);
    const faults = db.prepare('SELECT * FROM faults WHERE vehicle_id=?').all(v.id);
    const signals = db.prepare('SELECT signal FROM readings WHERE vehicle_id=? GROUP BY signal').all(v.id);
    return { vehicle: v.code, data_source: v.data_source, findings: diagnose({ vehicle: v, battery, faults, signals }) };
  });

  add('GET', '/api/batteries', 'viewer', () => db.prepare('SELECT b.*, v.code AS vehicle_code FROM batteries b LEFT JOIN vehicles v ON v.id=b.vehicle_id ORDER BY b.code').all());
  add('POST', '/api/batteries', 'admin', ({ body, user }) => {
    const code = str(body.code, 40);
    if (db.prepare('SELECT 1 FROM batteries WHERE code=?').get(code)) throw new HttpError(409, 'code already exists');
    const r = db.prepare('INSERT INTO batteries(code,charge,health) VALUES(?,?,?)').run(code, body.charge == null ? 0 : int(body.charge, 0, 100), body.health == null ? null : int(body.health, 0, 100));
    audit(db, user.username, 'battery_create', code);
    return db.prepare('SELECT * FROM batteries WHERE id=?').get(r.lastInsertRowid);
  });
  add('PATCH', '/api/batteries/:id', 'technician', ({ params, body, user }) => {
    const b = db.prepare('SELECT * FROM batteries WHERE id=?').get(params.id);
    if (!b) throw new HttpError(404, 'not found');
    if (body.charge !== undefined) db.prepare('UPDATE batteries SET charge=? WHERE id=?').run(int(body.charge, 0, 100), b.id);
    if (body.state !== undefined) db.prepare('UPDATE batteries SET state=? WHERE id=?').run(oneOf(body.state, ['idle', 'charging', 'fault']), b.id);
    if (body.vehicle_id !== undefined) {
      const vid = body.vehicle_id === null ? null : int(body.vehicle_id, 1, 1e9);
      if (vid !== null) { getVehicle(vid); for (const o of db.prepare('SELECT id FROM batteries WHERE vehicle_id=? AND id!=?').all(vid, b.id)) db.prepare('INSERT INTO battery_history(battery_id,vehicle_id,event,actor,ts) VALUES(?,?,?,?,?)').run(o.id, vid, 'removed', user.username, now()); db.prepare('UPDATE batteries SET vehicle_id=NULL WHERE vehicle_id=? AND id!=?').run(vid, b.id); }
      db.prepare('UPDATE batteries SET vehicle_id=? WHERE id=?').run(vid, b.id);
      db.prepare('INSERT INTO battery_history(battery_id,vehicle_id,event,actor,ts) VALUES(?,?,?,?,?)').run(b.id, vid, vid ? 'installed' : 'removed', user.username, now());
    }
    audit(db, user.username, 'battery_update', b.code);
    return db.prepare('SELECT * FROM batteries WHERE id=?').get(b.id);
  });
  add('GET', '/api/batteries/:id/history', 'viewer', ({ params }) => db.prepare('SELECT * FROM battery_history WHERE battery_id=? ORDER BY id DESC').all(params.id));

  add('GET', '/api/faults', 'viewer', () => db.prepare('SELECT f.*, v.code AS vehicle_code FROM faults f JOIN vehicles v ON v.id=f.vehicle_id ORDER BY f.id DESC LIMIT 500').all());
  add('POST', '/api/faults', 'operator', ({ body, user }) => {
    getVehicle(int(body.vehicle_id, 1, 1e9));
    const r = db.prepare('INSERT INTO faults(vehicle_id,type,severity,description,reported_by,created_at) VALUES(?,?,?,?,?,?)')
      .run(body.vehicle_id, str(body.type, 60), oneOf(body.severity, SEV), str(body.description, 2000), user.username, now());
    audit(db, user.username, 'fault_create', String(r.lastInsertRowid));
    return db.prepare('SELECT * FROM faults WHERE id=?').get(r.lastInsertRowid);
  });
  add('PATCH', '/api/faults/:id', 'technician', ({ params, body, user }) => {
    const f = db.prepare('SELECT * FROM faults WHERE id=?').get(params.id);
    if (!f) throw new HttpError(404, 'not found');
    if (body.assignee !== undefined) db.prepare('UPDATE faults SET assignee=? WHERE id=?').run(str(body.assignee, 80, false), f.id);
    if (body.severity !== undefined) db.prepare('UPDATE faults SET severity=? WHERE id=?').run(oneOf(body.severity, SEV), f.id);
    if (body.status !== undefined) {
      oneOf(body.status, ['open', 'in_progress', 'closed']);
      if (body.status === 'closed') {
        const res = str(body.resolution, 2000); // a fault cannot be closed without a documented action/test result
        const mins = body.downtime_min == null ? null : int(body.downtime_min, 0, 1e6);
        db.prepare('UPDATE faults SET status=?, resolution=?, closed_at=?, downtime_min=? WHERE id=?').run('closed', res, now(), mins, f.id);
      } else db.prepare('UPDATE faults SET status=? WHERE id=?').run(body.status, f.id);
    }
    audit(db, user.username, 'fault_update', String(f.id));
    return db.prepare('SELECT * FROM faults WHERE id=?').get(f.id);
  });

  add('GET', '/api/maintenance', 'viewer', () => db.prepare('SELECT m.*, v.code AS vehicle_code FROM maintenance m JOIN vehicles v ON v.id=m.vehicle_id ORDER BY m.due').all());
  add('POST', '/api/maintenance', 'technician', ({ body, user }) => {
    getVehicle(int(body.vehicle_id, 1, 1e9));
    const r = db.prepare('INSERT INTO maintenance(vehicle_id,kind,due,technician,notes) VALUES(?,?,?,?,?)')
      .run(body.vehicle_id, str(body.kind, 80), str(body.due, 10), str(body.technician, 80, false), str(body.notes, 1000, false));
    audit(db, user.username, 'maintenance_create', String(r.lastInsertRowid));
    return db.prepare('SELECT * FROM maintenance WHERE id=?').get(r.lastInsertRowid);
  });
  add('PATCH', '/api/maintenance/:id', 'technician', ({ params, user }) => {
    const r = db.prepare('UPDATE maintenance SET done_at=? WHERE id=?').run(now(), params.id);
    if (!r.changes) throw new HttpError(404, 'not found');
    audit(db, user.username, 'maintenance_done', params.id);
    return db.prepare('SELECT * FROM maintenance WHERE id=?').get(params.id);
  });

  add('GET', '/api/manufacturers', 'viewer', () => db.prepare('SELECT * FROM manufacturers ORDER BY name').all());
  add('POST', '/api/manufacturers', 'super_admin', ({ body, user }) => {
    const name = str(body.name, 80);
    if (body.register_map != null && typeof body.register_map !== 'object') throw new HttpError(400, 'register_map must be an object');
    const r = db.prepare('INSERT INTO manufacturers(name,country,protocol,register_map,docs) VALUES(?,?,?,?,?)')
      .run(name, str(body.country, 80, false), body.protocol ? str(body.protocol, 40) : 'unverified', JSON.stringify(body.register_map ?? {}), str(body.docs, 2000, false) ?? '');
    audit(db, user.username, 'manufacturer_create', name);
    return db.prepare('SELECT * FROM manufacturers WHERE id=?').get(r.lastInsertRowid);
  });
  add('GET', '/api/protocols', 'viewer', () => publicProtocols());

  add('GET', '/api/users', 'super_admin', () => db.prepare('SELECT id,username,role,active,created_at FROM users ORDER BY id').all());
  add('POST', '/api/users', 'super_admin', ({ body, user }) => {
    const name = str(body.username, 64), pw = str(body.password, 200);
    if (pw.length < 10) throw new HttpError(400, 'password must be at least 10 characters');
    if (db.prepare('SELECT 1 FROM users WHERE username=?').get(name)) throw new HttpError(409, 'username exists');
    const r = db.prepare('INSERT INTO users(username,pass_hash,role,created_at) VALUES(?,?,?,?)').run(name, hashPw(pw), oneOf(body.role, Object.keys(RANK)), now());
    audit(db, user.username, 'user_create', `${name}:${body.role}`);
    return db.prepare('SELECT id,username,role,active FROM users WHERE id=?').get(r.lastInsertRowid);
  });
  add('PATCH', '/api/users/:id', 'super_admin', ({ params, body, user }) => {
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(params.id);
    if (!u) throw new HttpError(404, 'not found');
    if (u.id === user.id && (body.active === false || (body.role && body.role !== 'super_admin'))) throw new HttpError(409, 'cannot demote or disable yourself');
    if (body.role !== undefined) db.prepare('UPDATE users SET role=? WHERE id=?').run(oneOf(body.role, Object.keys(RANK)), u.id);
    if (body.active !== undefined) { db.prepare('UPDATE users SET active=? WHERE id=?').run(body.active ? 1 : 0, u.id); if (!body.active) db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id); }
    if (body.password !== undefined) {
      if (str(body.password, 200).length < 10) throw new HttpError(400, 'password must be at least 10 characters');
      db.prepare('UPDATE users SET pass_hash=? WHERE id=?').run(hashPw(body.password), u.id);
      db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
    }
    audit(db, user.username, 'user_update', u.username);
    return db.prepare('SELECT id,username,role,active FROM users WHERE id=?').get(u.id);
  });
  add('GET', '/api/audit', 'super_admin', () => db.prepare('SELECT * FROM audit ORDER BY id DESC LIMIT 500').all());
  add('GET', '/api/backup', 'super_admin', ({ user }) => {
    audit(db, user.username, 'backup_export');
    const out = {};
    for (const t of BACKUP_TABLES) out[t] = db.prepare(`SELECT * FROM ${t}`).all();
    return { exported_at: now(), tables: out }; // users/password hashes are deliberately excluded
  });
  add('POST', '/api/simulation/seed', 'admin', ({ user }) => { const n = seedSim(db); audit(db, user.username, 'simulation_seed', String(n)); return { created: n, note: 'All simulated rows are tagged SIMULATION' }; });
  add('POST', '/api/simulation/tick', 'admin', () => ({ updated: tick(db) }));

  registerV31({ add, db, HttpError, str, oneOf, int, audit, getVehicle, now });
  registerV40({ add, db, HttpError, str, oneOf, int, audit, getVehicle, now });

  const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml' };
  const server = http.createServer(async (req, res) => {
    const send = (code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(JSON.stringify(obj)); };
    try {
      const url = new URL(req.url, 'http://x');
      if (!url.pathname.startsWith('/api/')) {
        const rel = url.pathname === '/' ? 'index.html' : decodeURIComponent(url.pathname).replace(/^\/+/, '');
        const file = path.resolve(PUBLIC, rel);
        if (!file.startsWith(PUBLIC + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return send(404, { error: 'not found' });
        res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff',
          'Content-Security-Policy': "default-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'" });
        return res.end(fs.readFileSync(file));
      }
      const route = routes.find((r) => r.m === req.method && r.re.test(url.pathname));
      if (!route) return send(404, { error: 'not found' });
      const ctx = { db, params: route.re.exec(url.pathname).groups ?? {} };
      if (route.role) {
        const token = (req.headers.authorization || '').replace(/^Bearer /, '');
        const row = token && db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.exp>? AND u.active=1').get(sha(token), Date.now());
        if (!row) return send(401, { error: 'authentication required' });
        if (RANK[row.role] < RANK[route.role]) { audit(db, row.username, 'forbidden', `${req.method} ${url.pathname}`); return send(403, { error: 'insufficient role' }); }
        ctx.user = row; ctx.token = token;
      }
      ctx.body = ['POST', 'PATCH', 'PUT'].includes(req.method) ? await readBody(req) : {};
      const out = route.fn(ctx);
      if (out && out.__csv !== undefined) { res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="${out.name}"`, 'X-Content-Type-Options': 'nosniff' }); return res.end(out.__csv); }
      send(200, out);
    } catch (e) {
      if (e instanceof HttpError) return send(e.code, { error: e.message });
      console.error(e); send(500, { error: 'internal error' });
    }
  });
  server.db = db;
  if (simulation && process.env.SIMULATION !== '0') setInterval(() => { try { tick(db); } catch {} }, 5000).unref();
  return server;
}
