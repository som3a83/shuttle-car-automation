// SIMULATION ONLY. Every row it creates is tagged data_source='SIMULATION'. Signal names are generic, not real PLC addresses.
const now = () => new Date().toISOString();
export function seedSim(db) {
  const mid = db.prepare('SELECT id FROM manufacturers ORDER BY id LIMIT 1').get()?.id ?? null;
  let n = 0;
  for (let i = 1; i <= 3; i++) {
    const code = 'SIM-0' + i;
    if (db.prepare('SELECT 1 FROM vehicles WHERE code=?').get(code)) continue;
    const v = db.prepare('INSERT INTO vehicles(code,manufacturer_id,model,status,data_source,last_seen,created_at) VALUES(?,?,?,?,?,?,?)')
      .run(code, mid, 'SIMULATED', 'idle', 'SIMULATION', now(), now());
    db.prepare('INSERT INTO batteries(code,charge,state,vehicle_id,health,cycles) VALUES(?,?,?,?,?,?)')
      .run('SIMB-0' + i, 40 + i * 15, 'idle', v.lastInsertRowid, 90, 10 * i);
    n++;
  }
  return n;
}
export function tick(db) {
  const vs = db.prepare("SELECT id FROM vehicles WHERE data_source='SIMULATION'").all();
  const ts = now();
  const rd = db.prepare('INSERT INTO readings(vehicle_id,signal,kind,value,source,ts) VALUES(?,?,?,?,?,?)');
  for (const { id } of vs) {
    const status = ['running', 'running', 'idle', 'charging'][Math.floor(Math.random() * 4)];
    const b = db.prepare('SELECT id,charge FROM batteries WHERE vehicle_id=?').get(id);
    let charge = b ? b.charge : 0;
    if (b) {
      charge = Math.max(5, Math.min(100, charge + (status === 'running' ? -3 : status === 'charging' ? 6 : 0)));
      db.prepare('UPDATE batteries SET charge=?, state=? WHERE id=?').run(charge, status === 'charging' ? 'charging' : 'idle', b.id);
    }
    db.prepare('UPDATE vehicles SET status=?, last_seen=?, hours=hours+? WHERE id=?').run(status, ts, status === 'running' ? 0.0014 : 0, id);
    const sig = [['DI1', 'digital_in', status === 'running' ? 1 : 0], ['DO1', 'digital_out', status === 'charging' ? 1 : 0],
      ['AI1', 'analog_in', +(40 + charge * 0.12).toFixed(2)], ['AO1', 'analog_out', status === 'running' ? 60 : 0]];
    for (const [s, k, v] of sig) rd.run(id, s, k, v, 'SIMULATION', ts);
  }
  db.prepare('DELETE FROM readings WHERE id < (SELECT COALESCE(MAX(id),0) FROM readings) - 2000').run();
  return vs.length;
}
