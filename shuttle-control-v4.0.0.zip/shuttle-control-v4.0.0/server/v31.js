// V3.1: battery cycles, work orders, reports, JSON restore.
export const BACKUP_TABLES = ['manufacturers', 'vehicles', 'batteries', 'battery_history', 'battery_cycles', 'faults', 'work_orders', 'maintenance', 'audit'];
const RESTORE_ORDER = ['manufacturers', 'vehicles', 'batteries', 'battery_history', 'battery_cycles', 'faults', 'work_orders', 'maintenance']; // parents first; audit is never overwritten
const PRIO = ['low', 'medium', 'high', 'critical'];
const csvCell = (v) => { let s = v == null ? '' : String(v); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
const avg = (a) => (a.length ? +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(1) : null);

export function registerV31({ add, db, HttpError, str, oneOf, int, audit, getVehicle, now }) {
  const iso = (v) => { if (v == null) return now(); const t = Date.parse(str(v, 40)); if (Number.isNaN(t)) throw new HttpError(400, 'invalid date'); return new Date(t).toISOString(); };

  const batteryAnalytics = () => db.prepare('SELECT * FROM batteries ORDER BY code').all().map((b) => {
    const cs = db.prepare("SELECT * FROM battery_cycles WHERE battery_id=? AND kind='charge'").all(b.id);
    const alerts = [];
    if (b.charge <= 30 && b.state !== 'charging') alerts.push('LOW_CHARGE');
    if (b.health != null && b.health < 70) alerts.push('MANUALLY_ENTERED_HEALTH_LOW');
    return { id: b.id, code: b.code, charge: b.charge, recorded_charge_sessions: cs.length,
      avg_charge_delta_pct: avg(cs.map((c) => c.end_pct - c.start_pct)), avg_charge_minutes: avg(cs.map((c) => (Date.parse(c.ended_at) - Date.parse(c.started_at)) / 6e4)),
      installs: db.prepare("SELECT COUNT(*) c FROM battery_history WHERE battery_id=? AND event='installed'").get(b.id).c,
      last_charge_at: cs.map((c) => c.ended_at).sort().pop() ?? null, alerts };
  });
  add('GET', '/api/batteries/analytics', 'viewer', () => ({ note: 'Derived only from recorded sessions; no health/SoH is estimated by the system', batteries: batteryAnalytics() }));
  add('GET', '/api/batteries/:id/cycles', 'viewer', ({ params }) => db.prepare('SELECT * FROM battery_cycles WHERE battery_id=? ORDER BY id DESC').all(params.id));
  add('POST', '/api/batteries/:id/cycles', 'technician', ({ params, body, user }) => {
    const b = db.prepare('SELECT * FROM batteries WHERE id=?').get(params.id);
    if (!b) throw new HttpError(404, 'not found');
    const kind = oneOf(body.kind, ['charge', 'discharge']), s = int(body.start_pct, 0, 100), e = int(body.end_pct, 0, 100);
    if ((kind === 'charge' && e < s) || (kind === 'discharge' && e > s)) throw new HttpError(400, 'end_pct inconsistent with kind');
    const st = iso(body.started_at), en = iso(body.ended_at);
    if (Date.parse(en) < Date.parse(st)) throw new HttpError(400, 'ended_at before started_at');
    const vid = body.vehicle_id == null ? b.vehicle_id : getVehicle(int(body.vehicle_id, 1, 1e9)).id;
    const r = db.prepare("INSERT INTO battery_cycles(battery_id,vehicle_id,kind,start_pct,end_pct,started_at,ended_at,source,actor) VALUES(?,?,?,?,?,?,?,'MANUAL',?)").run(b.id, vid, kind, s, e, st, en, user.username);
    db.prepare('UPDATE batteries SET charge=? WHERE id=?').run(e, b.id);
    audit(db, user.username, 'battery_cycle', `${b.code}:${kind}`);
    return db.prepare('SELECT * FROM battery_cycles WHERE id=?').get(r.lastInsertRowid);
  });

  const woRow = (w) => ({ ...w, parts: JSON.parse(w.parts) });
  add('GET', '/api/work-orders', 'viewer', () => db.prepare('SELECT w.*, v.code AS vehicle_code FROM work_orders w JOIN vehicles v ON v.id=w.vehicle_id ORDER BY w.id DESC LIMIT 500').all().map(woRow));
  add('POST', '/api/work-orders', 'technician', ({ body, user }) => {
    const vid = getVehicle(int(body.vehicle_id, 1, 1e9)).id;
    let fid = null;
    if (body.fault_id != null) {
      fid = int(body.fault_id, 1, 1e9);
      const f = db.prepare('SELECT vehicle_id FROM faults WHERE id=?').get(fid);
      if (!f || f.vehicle_id !== vid) throw new HttpError(400, 'fault not found for this shuttle');
    }
    const r = db.prepare('INSERT INTO work_orders(vehicle_id,fault_id,title,fault_type,priority,technician,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)')
      .run(vid, fid, str(body.title, 200), str(body.fault_type, 60, false), oneOf(body.priority, PRIO), str(body.technician, 80, false), user.username, now());
    audit(db, user.username, 'work_order_create', String(r.lastInsertRowid));
    return woRow(db.prepare('SELECT * FROM work_orders WHERE id=?').get(r.lastInsertRowid));
  });
  add('PATCH', '/api/work-orders/:id', 'technician', ({ params, body, user }) => {
    const w = db.prepare('SELECT * FROM work_orders WHERE id=?').get(params.id);
    if (!w) throw new HttpError(404, 'not found');
    if (w.status === 'completed' || w.status === 'cancelled') throw new HttpError(409, 'work order is final');
    // validate everything first, then write
    const tech = body.technician !== undefined ? str(body.technician, 80, false) : w.technician;
    const prio = body.priority !== undefined ? oneOf(body.priority, PRIO) : w.priority;
    let parts = w.parts;
    if (body.parts !== undefined) {
      if (!Array.isArray(body.parts) || body.parts.length > 50) throw new HttpError(400, 'invalid parts');
      parts = JSON.stringify(body.parts.map((p) => ({ name: str(p?.name, 80), ref: str(p?.ref, 80, false), qty: int(p?.qty, 1, 10000) })));
    }
    const s = body.status === undefined ? w.status : oneOf(body.status, ['open', 'in_progress', 'completed', 'cancelled']);
    if (s === 'open' && w.status !== 'open') throw new HttpError(409, 'invalid transition');
    let actions = w.actions, rep = w.repair_min, down = w.downtime_min, started = w.started_at, done = null;
    if (s === 'in_progress' && !started) started = now();
    if (s === 'completed') { actions = str(body.actions, 2000); rep = int(body.repair_min, 0, 1e6); down = int(body.downtime_min, 0, 1e6); done = now(); }
    if (s === 'cancelled') done = now();
    db.prepare('UPDATE work_orders SET technician=?,priority=?,parts=?,status=?,actions=?,repair_min=?,downtime_min=?,started_at=?,completed_at=? WHERE id=?').run(tech, prio, parts, s, actions, rep, down, started, done, w.id);
    if (s === 'completed' && w.fault_id)
      db.prepare("UPDATE faults SET status='closed',resolution=?,closed_at=?,downtime_min=? WHERE id=? AND status!='closed'").run(`WO#${w.id}: ${actions}`, done, down, w.fault_id);
    audit(db, user.username, 'work_order_update', `${w.id}:${s}`);
    return woRow(db.prepare('SELECT * FROM work_orders WHERE id=?').get(w.id));
  });

  const report = () => {
    const vehicles = db.prepare(`SELECT v.id, v.code, v.data_source, v.hours,
      (SELECT COUNT(*) FROM faults f WHERE f.vehicle_id=v.id) AS faults,
      (SELECT COALESCE(SUM(downtime_min),0) FROM faults f WHERE f.vehicle_id=v.id) AS fault_downtime_min,
      (SELECT COUNT(*) FROM work_orders w WHERE w.vehicle_id=v.id AND w.status IN ('open','in_progress')) AS open_work_orders FROM vehicles v ORDER BY v.code`).all();
    return { generated_at: now(), vehicles, downtime_total_min: vehicles.reduce((a, v) => a + v.fault_downtime_min, 0),
      repeated_faults: db.prepare('SELECT v.code AS vehicle, f.type, COUNT(*) AS n FROM faults f JOIN vehicles v ON v.id=f.vehicle_id GROUP BY f.vehicle_id, f.type HAVING n>=3 ORDER BY n DESC').all(),
      technicians: db.prepare("SELECT technician, COUNT(*) AS completed, ROUND(AVG(repair_min),1) AS avg_repair_min, COALESCE(SUM(downtime_min),0) AS downtime_min FROM work_orders WHERE status='completed' AND technician IS NOT NULL GROUP BY technician").all(),
      batteries: batteryAnalytics() };
  };
  add('GET', '/api/reports/summary', 'admin', report);
  add('GET', '/api/reports/work-orders.csv', 'admin', () => {
    const cols = ['id', 'vehicle_code', 'title', 'fault_type', 'priority', 'status', 'technician', 'parts', 'actions', 'repair_min', 'downtime_min', 'created_at', 'completed_at'];
    const rows = db.prepare('SELECT w.*, v.code AS vehicle_code FROM work_orders w JOIN vehicles v ON v.id=w.vehicle_id ORDER BY w.id').all();
    return { name: 'work-orders.csv', __csv: '\ufeff' + [cols.join(','), ...rows.map((r) => cols.map((c) => csvCell(r[c])).join(','))].join('\r\n') };
  });

  add('POST', '/api/restore', 'super_admin', ({ body, user }) => {
    const tabs = body?.tables;
    if (!tabs || typeof tabs !== 'object') throw new HttpError(400, 'invalid backup file');
    const plan = [];
    for (const t of RESTORE_ORDER) {
      const rows = tabs[t];
      if (!Array.isArray(rows)) throw new HttpError(400, 'missing table ' + t);
      const cols = db.prepare(`PRAGMA table_info(${t})`).all().map((c) => c.name);
      for (const r of rows) {
        if (!r || typeof r !== 'object' || Array.isArray(r)) throw new HttpError(400, 'invalid row in ' + t);
        for (const [k, v] of Object.entries(r)) {
          if (!cols.includes(k)) throw new HttpError(400, `unknown column ${t}.${k}`);
          if (v !== null && typeof v !== 'string' && typeof v !== 'number') throw new HttpError(400, 'invalid value type');
        }
      }
      plan.push([t, rows]);
    }
    db.exec('BEGIN');
    try {
      for (const t of [...RESTORE_ORDER].reverse()) db.exec(`DELETE FROM ${t}`);
      db.exec('DELETE FROM readings');
      for (const [t, rows] of plan) for (const r of rows) {
        const ks = Object.keys(r);
        db.prepare(`INSERT INTO ${t}(${ks.join(',')}) VALUES(${ks.map(() => '?').join(',')})`).run(...ks.map((k) => r[k]));
      }
      const bad = db.prepare('PRAGMA foreign_key_check').all();
      if (bad.length) throw new HttpError(400, 'integrity check failed in ' + bad[0].table);
      db.exec('COMMIT');
    } catch (e) {
      db.exec('ROLLBACK');
      throw e instanceof HttpError ? e : new HttpError(400, 'restore failed: ' + e.message);
    }
    audit(db, user.username, 'restore', plan.map(([t, r]) => `${t}=${r.length}`).join(' '));
    return { ok: true, restored: Object.fromEntries(plan.map(([t, r]) => [t, r.length])) };
  });
}
