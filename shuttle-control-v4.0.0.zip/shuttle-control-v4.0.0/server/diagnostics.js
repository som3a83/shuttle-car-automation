// Rule-based diagnostic engine. Output is ALWAYS a hypothesis requiring technician verification.
export function diagnose({ vehicle, battery, faults, signals = [], lowBattery = 30, now = Date.now() }) {
  const out = [];
  const src = vehicle.data_source;
  const add = (o) => out.push({ verificationRequired: true, status: 'hypothesis - not a confirmed fault', dataSource: src, ...o });
  const age = vehicle.last_seen ? now - Date.parse(vehicle.last_seen) : Infinity;

  if (src === 'OFFLINE') {
    add({ code: 'NO_LIVE_DATA', fault: 'No live data source connected', severity: 'info', confidence: 1,
      causes: ['Equipment not integrated yet (manual records only)'], evidence: ['data_source=OFFLINE'],
      steps: ['Commission a documented interface (see docs/INTEGRATION.md)'], action: 'No diagnostic conclusion possible from live signals' });
  } else if (age > 120000) {
    add({ code: 'COMM_LOSS', fault: 'Communication lost', severity: 'high', confidence: age === Infinity ? 0.3 : 0.6,
      causes: ['Network/gateway outage', 'Device powered off', 'Wireless coverage loss'],
      evidence: [vehicle.last_seen ? `Last communication ${Math.round(age / 1000)}s ago` : 'Never communicated'],
      steps: ['Check gateway and network status', 'Check device power at a safe location', 'Isolate the shuttle per site safety procedure before entering the rack aisle'],
      action: 'Restore link, then re-evaluate' });
  }
  if (battery && battery.charge <= lowBattery && battery.state !== 'charging') {
    add({ code: 'BATTERY_LOW', fault: `Low battery (${battery.charge}%)`, severity: battery.charge <= 15 ? 'high' : 'medium', confidence: 0.8,
      causes: ['Charge not scheduled in time', 'Possible degraded capacity (check cycles/health)'],
      evidence: [`charge=${battery.charge}%`, `state=${battery.state}`, `cycles=${battery.cycles}`, `health=${battery.health ?? 'unknown'}`],
      steps: ['Swap or charge per site procedure', 'Compare charge drop rate against the sister battery'], action: 'Charge or replace battery' });
  }
  if (battery && battery.health != null && battery.health < 70) {
    add({ code: 'BATTERY_HEALTH', fault: `Battery health ${battery.health}%`, severity: 'medium', confidence: 0.6,
      causes: ['Ageing / cell imbalance'], evidence: [`health=${battery.health}`], steps: ['Capacity test by technician'], action: 'Plan replacement' });
  }
  const recent = faults.filter((f) => now - Date.parse(f.created_at) < 30 * 864e5);
  const byType = {};
  for (const f of recent) byType[f.type] = (byType[f.type] || 0) + 1;
  for (const [type, n] of Object.entries(byType)) {
    if (n >= 3) add({ code: 'REPEATED_FAULT', fault: `Repeated fault type "${type}" (${n} in 30 days)`, severity: 'medium', confidence: 0.7,
      causes: ['Unresolved root cause', 'Wear or loose connection'], evidence: [`${n} reports in 30 days`],
      steps: ['Review previous resolutions', 'Targeted preventive inspection'], action: 'Open preventive work on the recurring component' });
  }
  for (const f of faults.filter((x) => x.status !== 'closed' && x.severity === 'critical')) {
    add({ code: 'OPEN_CRITICAL', fault: `Open critical fault #${f.id}: ${f.description.slice(0, 80)}`, severity: 'critical', confidence: 1,
      causes: ['As reported'], evidence: [`reported ${f.created_at}`], steps: ['Keep the shuttle out of service until closed with a documented test'], action: 'Resolve and document' });
  }
  if (!out.length) add({ code: 'NO_ANOMALY', fault: 'No abnormality in the available data', severity: 'info', confidence: 0.5,
    causes: [], evidence: [`${signals.length} signal(s) evaluated`], steps: ['Continue routine inspection'], action: 'None' });
  return out;
}
