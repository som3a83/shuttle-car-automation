// Communication adapter registry. NOTHING here talks to hardware yet.
// Each adapter must be implemented per manufacturer documentation and a real register map.
// No addresses, registers or commands are invented; no control writes are permitted (read-only by design).
const notCommissioned = (name) => async () => {
  throw new Error(`${name}: not commissioned - requires manufacturer documentation, register map and hardware`);
};
const mk = (id, label) => ({ id, label, status: 'not_implemented', readOnly: true, connect: notCommissioned(label) });
export const PROTOCOLS = [
  mk('modbus_tcp', 'Modbus TCP'), mk('opcua', 'OPC UA'), mk('ethernet_tcp', 'Ethernet TCP/IP'),
  mk('mqtt', 'MQTT'), mk('rest', 'REST API'), mk('ble', 'Bluetooth (documented interfaces only)'),
  mk('vendor', 'Manufacturer-specific'),
];
export const publicProtocols = () => PROTOCOLS.map(({ id, label, status, readOnly }) => ({ id, label, status, readOnly }));
