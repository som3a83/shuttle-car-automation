const T = {
  ar: { app: 'شاتل كونترول', login: 'دخول', user: 'اسم المستخدم', pass: 'كلمة المرور', logout: 'خروج', dashboard: 'القيادة', fleet: 'الأسطول', batteries: 'البطاريات', faults: 'الأعطال', maint: 'الصيانة', diag: 'التشخيص', plc: 'PLC والاتصال', mfr: 'الشركات', users: 'المستخدمون', audit: 'سجل المراجعة',
    total: 'إجمالي العربات', online: 'متصلة', open: 'أعطال مفتوحة', low: 'بطاريات منخفضة', REAL: 'بيانات حقيقية', SIMULATION: 'محاكاة', OFFLINE: 'غير متصلة', MANUAL: 'يدوي', add: 'إضافة', save: 'حفظ', code: 'الرمز', model: 'الطراز',
    status: 'الحالة', battery: 'البطارية', source: 'المصدر', type: 'النوع', severity: 'الخطورة', desc: 'الوصف', report: 'بلاغ عطل', close: 'إغلاق', resolution: 'الإجراء ونتيجة الاختبار', run: 'تشخيص', seed: 'تشغيل بيئة المحاكاة', simnote: 'تنبيه: كل بيانات المحاكاة وهمية وليست من معدات حقيقية.',
    hyp: 'فرضية تحتاج تحقق فني — ليست عطلاً مؤكداً', causes: 'الأسباب المحتملة', evidence: 'الأدلة', steps: 'خطوات الفحص', action: 'الإجراء المقترح', conf: 'الثقة', protocols: 'بروتوكولات الاتصال (غير مفعّلة حتى توفر وثائق وعتاد)', signals: 'الإشارات', nosig: 'لا إشارات', role: 'الدور', backup: 'نسخة احتياطية', vehicle: 'العربة', kind: 'النوع', due: 'الاستحقاق', done: 'تم', last: 'آخر اتصال', hours: 'ساعات التشغيل', name: 'الاسم', country: 'البلد', proto: 'البروتوكول' },
  en: { app: 'Shuttle Control', login: 'Sign in', user: 'Username', pass: 'Password', logout: 'Sign out', dashboard: 'Dashboard', fleet: 'Fleet', batteries: 'Batteries', faults: 'Faults', maint: 'Maintenance', diag: 'Diagnostics', plc: 'PLC & Comms', mfr: 'Manufacturers', users: 'Users', audit: 'Audit log',
    total: 'Total shuttles', online: 'Online', open: 'Open faults', low: 'Low batteries', REAL: 'REAL DATA', SIMULATION: 'SIMULATION', OFFLINE: 'OFFLINE', MANUAL: 'MANUAL', add: 'Add', save: 'Save', code: 'Code', model: 'Model',
    status: 'Status', battery: 'Battery', source: 'Source', type: 'Type', severity: 'Severity', desc: 'Description', report: 'Report fault', close: 'Close', resolution: 'Action taken and test result', run: 'Diagnose', seed: 'Start simulation environment', simnote: 'Notice: simulation data is fictitious and not from real equipment.',
    hyp: 'Hypothesis requiring technician verification - not a confirmed fault', causes: 'Possible causes', evidence: 'Evidence', steps: 'Inspection steps', action: 'Suggested action', conf: 'Confidence', protocols: 'Communication protocols (inactive until documentation and hardware are available)', signals: 'Signals', nosig: 'No signals', role: 'Role', backup: 'Backup', vehicle: 'Shuttle', kind: 'Kind', due: 'Due', done: 'Done', last: 'Last seen', hours: 'Operating hours', name: 'Name', country: 'Country', proto: 'Protocol' },
};
Object.assign(T.ar, { orders: 'أوامر العمل', reports: 'التقارير', priority: 'الأولوية', print: 'طباعة', csv: 'تصدير CSV', repair: 'دقائق الإصلاح', downtime: 'دقائق التوقف', actions: 'الإجراءات المنفذة', tech: 'الفني', repeated: 'أعطال متكررة', techperf: 'أداء الفنيين' });
Object.assign(T.en, { orders: 'Work orders', reports: 'Reports', priority: 'Priority', print: 'Print', csv: 'Export CSV', repair: 'Repair minutes', downtime: 'Downtime minutes', actions: 'Actions taken', tech: 'Technician', repeated: 'Repeated faults', techperf: 'Technician performance' });
const RANK = { viewer: 1, operator: 2, technician: 3, admin: 4, super_admin: 5 };
let lang = localStorage.getItem('lang') || 'ar', theme = localStorage.getItem('theme') || 'dark';
let token = sessionStorage.getItem('tk'), me = null, view = 'dashboard', timer = null;
const t = (k) => T[lang][k] || k;
const can = (r) => me && RANK[me.role] >= RANK[r];
const h = (tag, a = {}, ...kids) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(a)) k.startsWith('on') ? e.addEventListener(k.slice(2), v) : k === 'class' ? (e.className = v) : e.setAttribute(k, v);
  for (const c of kids.flat()) if (c != null) e.append(c instanceof Node ? c : String(c));
  return e;
};
async function api(p, o = {}) {
  const r = await fetch('/api' + p, { method: o.method || 'GET', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: o.body ? JSON.stringify(o.body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401 && token) { token = null; sessionStorage.removeItem('tk'); render(); }
  if (!r.ok) throw new Error(j.error || r.status);
  return j;
}
const badge = (s) => h('span', { class: 'badge ' + s }, t(s));
const fmt = (s) => (s ? new Date(s).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-GB') : '-');
const table = (cols, rows) => h('div', { class: 'scroll' }, h('table', {}, h('tr', {}, cols.map((c) => h('th', {}, c))), rows.map((r) => h('tr', {}, r.map((c) => h('td', {}, c))))));
const field = (name, ph, type = 'text') => h('input', { name, placeholder: ph, type, required: 'required' });
const form = (children, fn, msg) => h('form', { class: 'row', onsubmit: async (e) => { e.preventDefault(); try { await fn(Object.fromEntries(new FormData(e.target))); render(); } catch (x) { msg.textContent = x.message; } } }, children);
const barChart = (vs) => {
  const ns = 'http://www.w3.org/2000/svg', s = document.createElementNS(ns, 'svg');
  s.setAttribute('viewBox', `0 0 ${Math.max(vs.length, 1) * 60} 120`); s.setAttribute('width', '100%');
  vs.forEach((v, i) => {
    const c = v.battery_charge ?? 0, r = document.createElementNS(ns, 'rect');
    r.setAttribute('x', i * 60 + 10); r.setAttribute('y', 100 - c); r.setAttribute('width', 40); r.setAttribute('height', c);
    r.setAttribute('fill', c <= 30 ? '#ff5a5f' : '#2f9bff'); s.append(r);
    const tx = document.createElementNS(ns, 'text'); tx.setAttribute('x', i * 60 + 30); tx.setAttribute('y', 114); tx.setAttribute('text-anchor', 'middle'); tx.setAttribute('font-size', '9'); tx.setAttribute('fill', 'currentColor'); tx.textContent = v.code; s.append(tx);
  });
  return s;
};

const views = {
  async dashboard() {
    const [d, vs] = await Promise.all([api('/dashboard'), api('/vehicles')]);
    const stat = (l, v) => h('div', { class: 'card' }, h('div', { class: 'mut' }, l), h('div', { class: 'big' }, v));
    const sim = vs.some((v) => v.data_source === 'SIMULATION');
    timer = setInterval(() => view === 'dashboard' && render(true), 5000);
    return [sim ? h('div', { class: 'banner' }, t('simnote')) : null,
      h('div', { class: 'grid stats' }, stat(t('total'), d.total), stat(t('online'), d.online), stat(t('open'), d.openFaults), stat(t('low'), d.lowBatteries)),
      h('h3', {}, t('battery') + ' %'), h('div', { class: 'card' }, barChart(vs)),
      h('h3', {}, t('fleet')), h('div', { class: 'grid' }, vs.map((v) => h('div', { class: 'card' },
        h('b', {}, v.code), ' ', badge(v.data_source), h('div', { class: 'mut' }, `${v.manufacturer || '-'} ${v.model || ''}`),
        h('div', {}, `${t('status')}: ${v.status}${v.online ? ' ●' : ''}`), h('div', {}, `${t('battery')}: ${v.battery_charge ?? '-'}%`),
        h('div', { class: 'mut' }, `${t('hours')}: ${v.hours.toFixed(1)} • ${t('last')}: ${fmt(v.last_seen)}`))))];
  },
  async fleet() {
    const [vs, ms] = await Promise.all([api('/vehicles'), api('/manufacturers')]);
    const msg = h('span', { class: 'err' });
    return [can('admin') ? form([field('code', t('code')), h('select', { name: 'manufacturer_id' }, ms.map((m) => h('option', { value: m.id }, m.name))), h('input', { name: 'model', placeholder: t('model') }), h('button', {}, t('add')), msg],
      (f) => api('/vehicles', { method: 'POST', body: { code: f.code, model: f.model, manufacturer_id: +f.manufacturer_id } }), msg) : null,
    can('admin') ? h('button', { class: 'alt', onclick: async () => { await api('/simulation/seed', { method: 'POST', body: {} }); render(); } }, t('seed')) : null,
    table([t('code'), t('source'), t('status'), t('battery'), t('last')], vs.map((v) => [v.code, badge(v.data_source), v.status, v.battery_code ? `${v.battery_code} ${v.battery_charge}%` : '-', fmt(v.last_seen)]))];
  },
  async batteries() {
    const bs = await api('/batteries'), msg = h('span', { class: 'err' });
    return [can('admin') ? form([field('code', t('code')), h('input', { name: 'charge', type: 'number', min: 0, max: 100, placeholder: '%' }), h('button', {}, t('add')), msg],
      (f) => api('/batteries', { method: 'POST', body: { code: f.code, charge: +f.charge || 0 } }), msg) : null,
    table([t('code'), '%', t('status'), t('vehicle'), 'Cycles'], bs.map((b) => [b.code, b.charge, b.state, b.vehicle_code || '-', b.cycles]))];
  },
  async faults() {
    const [fs, vs] = await Promise.all([api('/faults'), api('/vehicles')]), msg = h('span', { class: 'err' });
    return [can('operator') ? form([h('select', { name: 'vehicle_id' }, vs.map((v) => h('option', { value: v.id }, v.code))), field('type', t('type')),
      h('select', { name: 'severity' }, ['low', 'medium', 'high', 'critical'].map((s) => h('option', {}, s))), field('description', t('desc')), h('button', {}, t('report')), msg],
      (f) => api('/faults', { method: 'POST', body: { ...f, vehicle_id: +f.vehicle_id } }), msg) : null,
    table(['#', t('vehicle'), t('type'), t('severity'), t('status'), t('desc'), ''], fs.map((f) => [f.id, f.vehicle_code, f.type, h('span', { class: 'sev-' + f.severity }, f.severity), f.status, f.description,
      can('technician') && f.status !== 'closed' ? h('button', { onclick: async () => { const r = prompt(t('resolution')); if (r) { try { await api('/faults/' + f.id, { method: 'PATCH', body: { status: 'closed', resolution: r } }); render(); } catch (x) { alert(x.message); } } } }, t('close')) : f.resolution || ''])) ];
  },
  async maint() {
    const [ms, vs] = await Promise.all([api('/maintenance'), api('/vehicles')]), msg = h('span', { class: 'err' });
    return [can('technician') ? form([h('select', { name: 'vehicle_id' }, vs.map((v) => h('option', { value: v.id }, v.code))), field('kind', t('kind')), field('due', t('due'), 'date'), h('button', {}, t('add')), msg],
      (f) => api('/maintenance', { method: 'POST', body: { ...f, vehicle_id: +f.vehicle_id } }), msg) : null,
    table([t('vehicle'), t('kind'), t('due'), t('done')], ms.map((m) => [m.vehicle_code, m.kind, m.due, m.done_at ? fmt(m.done_at) : can('technician') ? h('button', { onclick: async () => { await api('/maintenance/' + m.id, { method: 'PATCH', body: {} }); render(); } }, t('done')) : '-']))];
  },
  async diag() {
    const vs = await api('/vehicles'), out = h('div', {});
    const sel = h('select', {}, vs.map((v) => h('option', { value: v.id }, v.code)));
    const run = async () => {
      if (!sel.value) return;
      const d = await api(`/vehicles/${sel.value}/diagnose`);
      out.replaceChildren(h('p', {}, badge(d.data_source)), ...d.findings.map((f) => h('div', { class: 'card', style: 'margin:8px 0' },
        h('b', { class: 'sev-' + f.severity }, `[${f.severity}] ${f.fault}`), h('div', { class: 'mut' }, `${t('hyp')} • ${t('conf')}: ${Math.round(f.confidence * 100)}%`),
        h('div', {}, `${t('causes')}: ${f.causes.join('; ') || '-'}`), h('div', {}, `${t('evidence')}: ${f.evidence.join('; ')}`),
        h('div', {}, `${t('steps')}: ${f.steps.join('; ')}`), h('div', {}, `${t('action')}: ${f.action}`))));
    };
    return [h('div', { class: 'row' }, sel, h('button', { onclick: run }, t('run'))), out];
  },
  async plc() {
    const [ps, vs] = await Promise.all([api('/protocols'), api('/vehicles')]), out = h('div', {});
    const sel = h('select', {}, vs.map((v) => h('option', { value: v.id }, v.code)));
    const load = async () => {
      if (!sel.value) return;
      const s = await api(`/vehicles/${sel.value}/signals`);
      out.replaceChildren(h('p', {}, badge(s.data_source)), s.signals.length ? table(['Signal', 'Kind', 'Value', t('source'), 'ts'], s.signals.map((x) => [x.signal, x.kind, x.value, badge(x.source), fmt(x.ts)])) : h('p', { class: 'mut' }, t('nosig')));
    };
    return [h('h3', {}, t('signals')), h('div', { class: 'row' }, sel, h('button', { onclick: load }, 'OK')), out,
      h('h3', {}, t('protocols')), table(['ID', 'Name', t('status'), 'Read-only'], ps.map((p) => [p.id, p.label, p.status, p.readOnly ? '✔' : '']))];
  },
  async mfr() {
    const ms = await api('/manufacturers'), msg = h('span', { class: 'err' });
    return [can('super_admin') ? form([field('name', t('name')), h('input', { name: 'country', placeholder: t('country') }), h('button', {}, t('add')), msg],
      (f) => api('/manufacturers', { method: 'POST', body: f }), msg) : null, table([t('name'), t('country'), t('proto')], ms.map((m) => [m.name, m.country, m.protocol]))];
  },
  async users() {
    const us = await api('/users'), msg = h('span', { class: 'err' });
    return [form([field('username', t('user')), field('password', t('pass'), 'password'), h('select', { name: 'role' }, Object.keys(RANK).map((r) => h('option', {}, r))), h('button', {}, t('add')), msg],
      (f) => api('/users', { method: 'POST', body: f }), msg), table(['#', t('user'), t('role'), 'Active'], us.map((u) => [u.id, u.username, u.role, u.active ? '✔' : '✘'])),
    h('button', { class: 'alt', onclick: async () => { const b = await api('/backup'); const a = h('a', { href: URL.createObjectURL(new Blob([JSON.stringify(b, null, 2)], { type: 'application/json' })), download: 'backup.json' }); a.click(); } }, t('backup'))];
  },
  async orders() {
    const [ws, vs] = await Promise.all([api('/work-orders'), api('/vehicles')]), msg = h('span', { class: 'err' });
    const patch = async (id, body) => { try { await api('/work-orders/' + id, { method: 'PATCH', body }); render(); } catch (x) { alert(x.message); } };
    return [can('technician') ? form([h('select', { name: 'vehicle_id' }, vs.map((v) => h('option', { value: v.id }, v.code))), field('title', t('desc')), h('input', { name: 'fault_type', placeholder: t('type') }), h('input', { name: 'technician', placeholder: t('tech') }),
      h('select', { name: 'priority' }, ['low', 'medium', 'high', 'critical'].map((s) => h('option', {}, s))), h('button', {}, t('add')), msg],
      (f) => api('/work-orders', { method: 'POST', body: { ...f, vehicle_id: +f.vehicle_id } }), msg) : null,
    table(['#', t('vehicle'), t('desc'), t('priority'), t('status'), t('tech'), ''], ws.map((w) => [w.id, w.vehicle_code, w.title, h('span', { class: 'sev-' + w.priority }, w.priority), w.status, w.technician || '-',
      can('technician') && !['completed', 'cancelled'].includes(w.status) ? h('span', {}, h('button', { class: 'alt', onclick: () => patch(w.id, { status: 'in_progress' }) }, '▶'),
        h('button', { onclick: () => { const a = prompt(t('actions')), r = prompt(t('repair')), d = prompt(t('downtime')); if (a) patch(w.id, { status: 'completed', actions: a, repair_min: +r, downtime_min: +d }); } }, t('done'))) : w.actions || '']))];
  },
  async reports() {
    const r = await api('/reports/summary');
    const csv = async () => { const x = await fetch('/api/reports/work-orders.csv', { headers: { Authorization: 'Bearer ' + token } }); const a = h('a', { href: URL.createObjectURL(await x.blob()), download: 'work-orders.csv' }); a.click(); };
    return [h('div', { class: 'row' }, h('button', { onclick: () => window.print() }, t('print')), h('button', { class: 'alt', onclick: csv }, t('csv'))), h('p', { class: 'mut' }, fmt(r.generated_at)),
      table([t('vehicle'), t('source'), t('faults'), t('downtime'), t('orders')], r.vehicles.map((v) => [v.code, badge(v.data_source), v.faults, v.fault_downtime_min, v.open_work_orders])),
      h('h3', {}, t('repeated')), table([t('vehicle'), t('type'), '#'], r.repeated_faults.map((x) => [x.vehicle, x.type, x.n])),
      h('h3', {}, t('techperf')), table([t('tech'), t('done'), 'avg ' + t('repair'), t('downtime')], r.technicians.map((x) => [x.technician, x.completed, x.avg_repair_min, x.downtime_min])),
      h('h3', {}, t('batteries')), table([t('code'), '%', 'sessions', 'avg Δ%', 'avg min', 'alerts'], r.batteries.map((b) => [b.code, b.charge, b.recorded_charge_sessions, b.avg_charge_delta_pct ?? '-', b.avg_charge_minutes ?? '-', b.alerts.join(', ') || '-']))];
  },
  async audit() { const a = await api('/audit'); return table(['ts', 'Actor', 'Action', 'Detail'], a.map((x) => [fmt(x.ts), x.actor, x.action, x.detail || ''])); },
};

async function render(soft) {
  document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr'; document.documentElement.dataset.theme = theme;
  clearInterval(timer);
  const root = document.getElementById('root');
  const tools = [h('button', { class: 'alt', onclick: () => { lang = lang === 'ar' ? 'en' : 'ar'; localStorage.setItem('lang', lang); render(); } }, lang === 'ar' ? 'EN' : 'ع'),
    h('button', { class: 'alt', onclick: () => { theme = theme === 'dark' ? 'light' : 'dark'; localStorage.setItem('theme', theme); render(); } }, theme === 'dark' ? (lang === 'ar' ? 'فاتح' : 'Light') : (lang === 'ar' ? 'داكن' : 'Dark'))];
  if (!token) {
    const msg = h('div', { class: 'err' });
    return root.replaceChildren(h('header', {}, h('b', {}, t('app')), tools), h('form', { class: 'card login', onsubmit: async (e) => {
      e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
      try { const r = await api('/login', { method: 'POST', body: f }); token = r.token; sessionStorage.setItem('tk', token); render(); } catch (x) { msg.textContent = x.message; } } },
      h('img', { src: '/logo.png', width: 64, alt: '' }), h('input', { name: 'username', placeholder: t('user'), required: 'required', autocomplete: 'username' }),
      h('input', { name: 'password', type: 'password', placeholder: t('pass'), required: 'required', autocomplete: 'current-password' }), h('button', {}, t('login')), msg));
  }
  try { me = await api('/me'); } catch { return; }
  const tabs = ['dashboard', 'fleet', 'batteries', 'faults', 'maint', 'orders', ...(can('admin') ? ['reports'] : []), 'diag', 'plc', 'mfr', ...(can('super_admin') ? ['users', 'audit'] : [])];
  const main = h('main', {});
  root.replaceChildren(h('header', {}, h('b', {}, t('app')), h('span', { class: 'mut' }, `${me.username} (${me.role})`), tools,
    h('button', { class: 'alt', onclick: async () => { try { await api('/logout', { method: 'POST', body: {} }); } catch {} token = null; sessionStorage.removeItem('tk'); render(); } }, t('logout'))),
    h('nav', {}, tabs.map((k) => h('button', { class: 'alt' + (k === view ? ' on' : ''), onclick: () => { view = k; render(); } }, t(k)))), main);
  try { main.replaceChildren(...(await views[view]()).flat().filter(Boolean)); } catch (x) { main.replaceChildren(h('p', { class: 'err' }, x.message)); }
}
render();
