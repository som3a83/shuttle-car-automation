// V4.0: legacy migration (field-app backup -> backend), notifications/FCM prep, change proposals.
// Follows the registerV3x({add,db,HttpError,str,oneOf,int,audit,getVehicle,now}) pattern.
import fs from 'node:fs';
import crypto from 'node:crypto';

export const MIGRATION_3 = `
CREATE TABLE notifications(id INTEGER PRIMARY KEY, kind TEXT NOT NULL, title TEXT NOT NULL, detail TEXT, vehicle_id INTEGER REFERENCES vehicles(id), level TEXT NOT NULL DEFAULT 'info', read INTEGER NOT NULL DEFAULT 0, ts TEXT NOT NULL);
CREATE TABLE notification_prefs(username TEXT PRIMARY KEY, kinds TEXT NOT NULL DEFAULT '["critical","high"]', updated_at TEXT NOT NULL);
CREATE TABLE proposals(id INTEGER PRIMARY KEY, title TEXT NOT NULL, detail TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_by TEXT, created_at TEXT NOT NULL, decided_by TEXT, decided_at TEXT, evidence TEXT);
CREATE TABLE snapshots(id INTEGER PRIMARY KEY, name TEXT NOT NULL, ts TEXT NOT NULL, payload TEXT NOT NULL);
`;

const SEVMAP = { critical: 'critical', high: 'high', watch: 'low', fixed: 'low' };
const STATUSMAP = { open: 'open', in_progress: 'in_progress', monitoring: 'open', closed: 'closed' };
const VSTATUS = { ready: 'idle', working: 'running', stopped: 'stopped', maintenance: 'fault' };
const BSTATE = (s, charge, thr) => (s === 'charging' ? 'charging' : (s === 'fault' || s === 'inspect') ? 'fault' : 'idle');

function planMigration(db, src) {
  if (!src || typeof src !== 'object' || !Array.isArray(src.vehicles) || !Array.isArray(src.batteries))
    throw new Error('not a shuttle-fleet backup (missing vehicles/batteries arrays)');
  const vehById = new Map((src.vehicles || []).map((v) => [v.id, v]));
  const makers = [...new Set((src.vehicles || []).map((v) => String(v.maker || '').trim()).filter(Boolean))];
  const existingMakers = new Set(db.prepare('SELECT name FROM manufacturers').all().map((r) => r.name));
  const existingVeh = new Set(db.prepare('SELECT code FROM vehicles').all().map((r) => r.code));
  const existingBat = new Set(db.prepare('SELECT code FROM batteries').all().map((r) => r.code));
  const vehicles = [], vehDupes = [], vehNoMaker = [];
  const seenVeh = new Set(existingVeh), seenBat = new Set(existingBat);
  for (const v of src.vehicles || []) {
    const code = String(v.number || v.code || '').trim();
    if (!code) { vehNoMaker.push('(missing code)'); continue; }
    if (seenVeh.has(code)) { vehDupes.push(code); continue; }
    seenVeh.add(code);
    vehicles.push(v);
  }
  const batteries = [], batDupes = [];
  for (const b of src.batteries || []) {
    const code = String(b.code || '').trim();
    if (!code) continue;
    if (seenBat.has(code)) { batDupes.push(code); continue; }
    seenBat.add(code);
    batteries.push(b);
  }
  const incompatible = [];
  if ((src.shifts || []).length) incompatible.push(`shifts: ${src.shifts.length} shift record(s) have no backend table yet — kept in the field app`);
  if ((src.users || []).length) incompatible.push(`users: ${src.users.length} account(s) never overwritten by migration (use POST /api/users)`);
  if ((src.links || []).length) incompatible.push(`links: ${(src.links || []).length} device-link record(s) have no backend table yet`);
  if ((src.readings || []).length) incompatible.push(`readings: ${(src.readings || []).length} field reading(s) — imported below as MANUAL where mappable`);
  return { makers: makers.filter((m) => !existingMakers.has(m)), makerCount: makers.length,
    vehicles, vehDupes, batteries, batDupes,
    faults: src.faults || [], maints: src.maints || [], cycles: src.cycles || [],
    activity: src.activity || [], readings: src.readings || [], incompatible, vehById };
}

export function registerV40({ add, db, HttpError, str, oneOf, int, audit, getVehicle, now }) {
  const need = (body, confirm) => {
    if (!body || typeof body !== 'object' || !body.backup) throw new HttpError(400, 'body.backup (field-app backup JSON) is required');
    if (confirm && body.confirm !== true) throw new HttpError(400, 'explicit confirmation required: {"confirm": true}');
    try { return planMigration(db, body.backup); } catch (e) { throw new HttpError(400, 'invalid backup: ' + e.message); }
  };

  add('POST', '/api/migrate/preview', 'super_admin', ({ body, user }) => {
    const p = need(body, false);
    audit(db, user.username, 'migrate_preview', `vehicles=${p.vehicles.length} batteries=${p.batteries.length} dupes=${p.vehDupes.length + p.batDupes.length}`);
    return { makers_to_create: p.makers, vehicles_to_create: p.vehicles.length, vehicle_dupes_skipped: p.vehDupes,
      batteries_to_create: p.batteries.length, battery_dupes_skipped: p.batDupes, faults: p.faults.length,
      maintenance: p.maints.length, cycles: p.cycles.length, activity_to_audit: p.activity.length,
      readings: p.readings.length, incompatible: p.incompatible,
      note: 'Preview only — nothing was written. Users and audit history are never overwritten.' };
  });

  add('POST', '/api/migrate/apply', 'super_admin', ({ body, user }) => {
    const p = need(body, true);
    const wantWO = body.createWorkOrders !== false;
    // automatic backup snapshot before any write
    const snapTables = ['manufacturers', 'vehicles', 'batteries', 'battery_history', 'battery_cycles', 'faults', 'work_orders', 'maintenance'];
    const snap = Object.fromEntries(snapTables.map((t) => [t, db.prepare(`SELECT * FROM ${t}`).all()]));
    const ins = { manufacturers: 0, vehicles: 0, batteries: 0, faults: 0, work_orders: 0, maintenance: 0, cycles: 0, audit: 0, readings: 0 };
    db.exec('BEGIN');
    try {
      db.prepare('INSERT INTO snapshots(name,ts,payload) VALUES(?,?,?)').run('pre-migrate ' + now(), now(), JSON.stringify(snap));
      const mid = {};
      for (const m of p.makers) {
        const r = db.prepare('INSERT INTO manufacturers(name,country,protocol) VALUES(?,?,?)').run(m, '', 'unverified');
        mid[m] = r.lastInsertRowid; ins.manufacturers++;
      }
      for (const r of db.prepare('SELECT id,name FROM manufacturers').all()) mid[r.name] = r.id;
      const vid = {};
      for (const v of p.vehicles) {
        const code = String(v.number).trim();
        const st = v.archived ? 'offline' : (VSTATUS[v.status] || 'idle');
        const r = db.prepare('INSERT INTO vehicles(code,manufacturer_id,model,status,hours,data_source,last_seen,created_at) VALUES(?,?,?,?,?,?,?,?)')
          .run(code, mid[String(v.maker || '').trim()] ?? null, String(v.model || '').slice(0, 80), st, +v.hours || 0, 'OFFLINE', v.lastUpdate || now(), now());
        vid[v.id] = r.lastInsertRowid; ins.vehicles++;
      }
      const bid = {};
      for (const b of p.batteries) {
        const code = String(b.code).trim();
        let vehicleId = null;
        if (b.vehicleId && vid[b.vehicleId]) vehicleId = vid[b.vehicleId];
        else if (b.vehicleId) {
          const srcVeh = p.vehById.get(b.vehicleId);
          if (srcVeh) { const row = db.prepare('SELECT id FROM vehicles WHERE code=?').get(String(srcVeh.number).trim()); if (row) vehicleId = row.id; }
        }
        const r = db.prepare('INSERT INTO batteries(code,charge,state,vehicle_id,health,cycles) VALUES(?,?,?,?,?,?)')
          .run(code, Math.max(0, Math.min(100, +b.charge || 0)), BSTATE(b.state), vehicleId, null, 0);
        bid[b.id] = r.lastInsertRowid; ins.batteries++;
        if (b.lastSwap || b.lastCharge || b.lastBy)
          db.prepare('INSERT INTO battery_history(battery_id,vehicle_id,event,actor,ts) VALUES(?,?,?,?,?)')
            .run(r.lastInsertRowid, vehicleId, 'migrated', String(b.lastBy || 'migration').slice(0, 80), b.lastSwap || b.lastCharge || now());
        ins.batteries += 0;
      }
      for (const f of p.faults) {
        let vehicleId = vid[f.vehicleId];
        if (!vehicleId && f.vehicleId) {
          const srcVeh = p.vehById.get(f.vehicleId);
          if (srcVeh) { const row = db.prepare('SELECT id FROM vehicles WHERE code=?').get(String(srcVeh.number).trim()); if (row) vehicleId = row.id; }
        }
        if (!vehicleId) continue;
        const status = STATUSMAP[f.status] || 'open';
        const res = status === 'closed' ? String(f.testResult || f.action || 'migrated as closed') : null;
        const r = db.prepare('INSERT INTO faults(vehicle_id,type,severity,description,status,assignee,resolution,reported_by,created_at,closed_at,downtime_min) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
          .run(vehicleId, String(f.type || 'general').slice(0, 80), SEVMAP[f.severity] || 'low', String(f.desc || '').slice(0, 500),
            status, String(f.technician || '').slice(0, 80) || null, res, String(f.createdBy || 'migration').slice(0, 80),
            f.createdAt || now(), status === 'closed' ? (f.endTime || f.createdAt || now()) : null, null);
        ins.faults++;
        if (wantWO && status !== 'closed') {
          db.prepare("INSERT INTO work_orders(vehicle_id,fault_id,title,fault_type,priority,status,technician,parts,created_by,created_at) VALUES(?,?,?,?,?,'open',?,'[]',?,?)")
            .run(vehicleId, r.lastInsertRowid, 'Migrated: ' + String(f.type || 'fault').slice(0, 60), String(f.type || '').slice(0, 80),
              f.severity === 'critical' ? 'critical' : f.severity === 'high' ? 'high' : 'medium',
              String(f.technician || '').slice(0, 80) || null, 'migration', now());
          ins.work_orders++;
        }
      }
      for (const m of p.maints) {
        let vehicleId = vid[m.vehicleId];
        if (!vehicleId && m.vehicleId) {
          const srcVeh = p.vehById.get(m.vehicleId);
          if (srcVeh) { const row = db.prepare('SELECT id FROM vehicles WHERE code=?').get(String(srcVeh.number).trim()); if (row) vehicleId = row.id; }
        }
        if (!vehicleId) continue;
        db.prepare('INSERT INTO maintenance(vehicle_id,kind,due,done_at,technician,notes) VALUES(?,?,?,?,?,?)')
          .run(vehicleId, String(m.kind || '').slice(0, 80), String(m.dueDate || '').slice(0, 40) || now().slice(0, 10),
            m.doneDate || null, String(m.tech || '').slice(0, 80) || null, String(m.notes || '').slice(0, 300) || null);
        ins.maintenance++;
      }
      for (const c of p.cycles) {
        const brow = c.batteryCode ? db.prepare('SELECT id FROM batteries WHERE code=?').get(String(c.batteryCode)) : null;
        const bdb = c.batteryId && bid[c.batteryId] ? bid[c.batteryId] : brow?.id;
        if (!bdb) continue;
        db.prepare('INSERT INTO battery_cycles(battery_id,vehicle_id,kind,start_pct,end_pct,started_at,ended_at,source,actor) VALUES(?,?,?,?,?,?,?,?,?)')
          .run(bdb, null, c.kind === 'discharge' ? 'discharge' : 'charge', Math.max(0, Math.min(100, +c.startPct || 0)),
            Math.max(0, Math.min(100, +c.endPct || 0)), c.startedAt || now(), c.endedAt || now(), 'MANUAL', String(c.by || 'migration').slice(0, 80));
        ins.cycles++;
      }
      for (const a of p.activity.slice(-500)) {
        db.prepare('INSERT INTO audit(actor,action,detail,ts) VALUES(?,?,?,?)')
          .run(String(a.user || 'migration').slice(0, 80), 'migrated: ' + String(a.action || '').slice(0, 120), String(a.details || '').slice(0, 300) || null, a.time || now());
        ins.audit++;
      }
      for (const r of p.readings.slice(-500)) {
        let vehicleId = vid[r.vehicleId];
        if (!vehicleId) continue;
        db.prepare('INSERT INTO readings(vehicle_id,signal,kind,value,source,ts) VALUES(?,?,?,?,?,?)')
          .run(vehicleId, 'battery_pct', 'analog_in', r.batteryPct ?? null, r.source === 'live' ? 'MANUAL' : 'MANUAL', r.time || now());
        ins.readings++;
      }
      const bad = db.prepare('PRAGMA foreign_key_check').all();
      if (bad.length) throw new HttpError(400, 'integrity check failed in ' + bad[0].table);
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e instanceof HttpError ? e : new HttpError(400, 'migration failed: ' + e.message); }
    audit(db, user.username, 'migrate_apply', Object.entries(ins).map(([k, v]) => `${k}=${v}`).join(' '));
    return { ok: true, inserted: ins, snapshot: 'pre-migrate backup stored in snapshots', note: 'Users and audit history were never overwritten; shifts/links/settings reported as incompatible, kept in the field app.' };
  });

  // ---- notifications ----
  const LEVELS = ['info', 'low', 'medium', 'high', 'critical'];
  add('GET', '/api/notifications', 'technician', ({ user }) => {
    const prefs = db.prepare('SELECT kinds FROM notification_prefs WHERE username=?').get(user.username);
    const kinds = prefs ? JSON.parse(prefs.kinds) : ['critical', 'high'];
    return db.prepare('SELECT n.*, v.code AS vehicle_code FROM notifications n LEFT JOIN vehicles v ON v.id=n.vehicle_id WHERE n.read=0 ORDER BY n.id DESC LIMIT 200').all()
      .filter((n) => kinds.includes(n.level) || kinds.includes('all'));
  });
  add('POST', '/api/notifications/read', 'technician', ({ body, user }) => {
    const ids = Array.isArray(body.ids) ? body.ids.map((x) => parseInt(x, 10)).filter(Number.isInteger) : [];
    if (!ids.length) throw new HttpError(400, 'ids required');
    db.prepare(`UPDATE notifications SET read=1 WHERE id IN (${ids.map(() => '?').join(',')})`).run(...ids);
    audit(db, user.username, 'notifications_read', ids.length + ' items');
    return { ok: true, marked: ids.length };
  });
  add('GET', '/api/notifications/history', 'technician', () =>
    db.prepare('SELECT n.*, v.code AS vehicle_code FROM notifications n LEFT JOIN vehicles v ON v.id=n.vehicle_id ORDER BY n.id DESC LIMIT 500').all());
  add('GET', '/api/notifications/prefs', 'technician', ({ user }) =>
    db.prepare('SELECT kinds FROM notification_prefs WHERE username=?').get(user.username) ?? { kinds: '["critical","high"]' });
  add('PUT', '/api/notifications/prefs', 'technician', ({ body, user }) => {
    const kinds = Array.isArray(body.kinds) ? body.kinds.filter((k) => LEVELS.includes(k) || k === 'all') : null;
    if (!kinds || !kinds.length) throw new HttpError(400, 'kinds required');
    db.prepare('INSERT INTO notification_prefs(username,kinds,updated_at) VALUES(?,?,?) ON CONFLICT(username) DO UPDATE SET kinds=excluded.kinds, updated_at=excluded.updated_at')
      .run(user.username, JSON.stringify(kinds), now());
    audit(db, user.username, 'notification_prefs', kinds.join(','));
    return { ok: true, kinds };
  });
  const fcmStatus = () => {
    const cred = process.env.FCM_SERVICE_ACCOUNT_JSON, pid = process.env.FCM_PROJECT_ID;
    if (!cred || !pid) return { fcm: 'not_configured', reason: 'Set FCM_SERVICE_ACCOUNT_JSON (path to service-account file) and FCM_PROJECT_ID on the server. Nothing is sent until then.' };
    try { const j = JSON.parse(fs.readFileSync(cred, 'utf8')); if (j.type !== 'service_account') throw 0; return { fcm: 'ready', project: pid, note: 'Server-side only. Service-account file is never served to clients.' }; }
    catch { return { fcm: 'misconfigured', reason: 'Service-account file unreadable or invalid.' }; }
  };
  add('GET', '/api/notify/status', 'viewer', () => ({ ...fcmStatus(), background: 'not_running', backgroundNote: 'Continuous monitoring needs a deployed always-on backend + gateway (see docs/INTEGRATION.md).' }));
  add('POST', '/api/notify/test', 'super_admin', async ({ body }) => {
    const st = fcmStatus();
    if (st.fcm !== 'ready') throw new HttpError(501, st.reason || 'FCM not configured');
    const token = str(body.token, 300);
    const { token: access } = await fcmAccessToken();
    const pid = process.env.FCM_PROJECT_ID;
    const r = await fetch(`https://fcm.googleapis.com/v1/projects/${pid}/messages:send`, {
      method: 'POST', headers: { Authorization: 'Bearer ' + access, 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: { token, notification: { title: 'Shuttle Control test', body: 'Push channel works.' } } }),
    });
    if (!r.ok) throw new HttpError(502, 'FCM send failed: ' + (await r.text()).slice(0, 200));
    return { ok: true };
  });
  async function fcmAccessToken() {
    const fs = await import('node:fs');
    const jwt = JSON.parse(fs.readFileSync(process.env.FCM_SERVICE_ACCOUNT_JSON, 'utf8'));
    const header = Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })).toString('base64url');
    const iat = Math.floor(Date.now() / 1000);
    const claim = Buffer.from(JSON.stringify({ iss: jwt.client_email, scope: 'https://www.googleapis.com/auth/firebase.messaging', aud: 'https://oauth2.googleapis.com/token', iat, exp: iat + 3600 })).toString('base64url');
    const sign = crypto.sign('RSA-SHA256', Buffer.from(header + '.' + claim), jwt.private_key).toString('base64url');
    const r = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=' + header + '.' + claim + '.' + sign });
    const j = await r.json();
    if (!j.access_token) throw new Error('token exchange failed');
    return { token: j.access_token };
  }

  // ---- change proposals (controlled dev pipeline; execution happens in dev, never direct prod writes) ----
  add('GET', '/api/proposals', 'admin', () =>
    db.prepare('SELECT * FROM proposals ORDER BY id DESC LIMIT 200').all());
  add('POST', '/api/proposals', 'admin', ({ body, user }) => {
    const r = db.prepare('INSERT INTO proposals(title,detail,status,created_by,created_at) VALUES(?,?,?, ?,?)')
      .run(str(body.title, 120), str(body.detail, 2000), 'pending', user.username, now());
    audit(db, user.username, 'proposal_create', String(r.lastInsertRowid));
    return db.prepare('SELECT * FROM proposals WHERE id=?').get(r.lastInsertRowid);
  });
  add('POST', '/api/proposals/:id/decision', 'super_admin', ({ params, body, user }) => {
    const p = db.prepare('SELECT * FROM proposals WHERE id=?').get(params.id);
    if (!p) throw new HttpError(404, 'not found');
    if (p.status !== 'pending') throw new HttpError(409, 'already decided');
    const d = oneOf(str(body.decision, 20), ['approved', 'rejected']);
    db.prepare('UPDATE proposals SET status=?, decided_by=?, decided_at=? WHERE id=?').run(d, user.username, now(), p.id);
    audit(db, user.username, 'proposal_' + d, String(p.id));
    return db.prepare('SELECT * FROM proposals WHERE id=?').get(p.id);
  });
  add('POST', '/api/proposals/:id/applied', 'super_admin', ({ params, body, user }) => {
    const p = db.prepare('SELECT * FROM proposals WHERE id=?').get(params.id);
    if (!p) throw new HttpError(404, 'not found');
    if (p.status !== 'approved') throw new HttpError(409, 'only approved proposals can be marked applied');
    db.prepare('UPDATE proposals SET status=?, evidence=? WHERE id=?').run('applied', str(body.evidence, 2000), p.id);
    audit(db, user.username, 'proposal_applied', String(p.id));
    return db.prepare('SELECT * FROM proposals WHERE id=?').get(p.id);
  });
}
