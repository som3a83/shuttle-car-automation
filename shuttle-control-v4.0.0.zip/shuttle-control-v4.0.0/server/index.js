import { createApp } from './app.js';
const port = +(process.env.PORT || 8080), host = process.env.HOST || '127.0.0.1';
createApp().listen(port, host, () => console.log(`Shuttle Control listening on http://${host}:${port}`));
