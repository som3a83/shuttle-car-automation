# Shuttle Control v4.0.0 — Shuttle Car Automation Platform

Unified project: a field-first Arabic PWA for daily shuttle-car operation **plus** a zero-dependency Node.js backend for control-room use (multi-user, audit, diagnostics, migration, notifications, proposals).

This is a Shuttle Car automation system only — not an ERP, warehouse, or accounting system.

## Parts

| Path | What | Run |
|---|---|---|
| `src/` + `dist/` | Field app (React + Vite PWA, Arabic RTL, offline-first, localStorage). This is also the APK source. | `pnpm install`, `pnpm dev`, `pnpm build` → `dist/` |
| `server/` | Backend (Node ≥ 22.13, **no npm packages**): auth/RBAC/audit, REST API, rule-based diagnostics, simulator, protocol registry (all `not_implemented`), migration, notifications, proposals | `cd server && npm start` (or `ADMIN_PASSWORD=... npm start`) |
| `backend-test/` | Backend tests (Node built-in runner, 27 tests) | `cd server && DB_PATH=/tmp/t.db ADMIN_PASSWORD=x npm test` |
| `docs/` | API, integration, limitations, changelog, migration, deploy, test report | read |
| `tools/visual-check.py` | Optional Playwright layout check (adopted from v3.1) | see script header |

## Quick start

Field app: `pnpm install && pnpm dev` → preview. Production: `pnpm build` → serve `dist/`.

Backend: `cd server && ADMIN_PASSWORD='...' npm start` → http://127.0.0.1:8080 (vanilla UI + API).
First run creates super-admin `admin`. Env: `PORT`, `HOST` (default 127.0.0.1), `DB_PATH` (default `data/shuttle.db`), `SIMULATION=0` to disable the simulator ticker, `FCM_SERVICE_ACCOUNT_JSON` + `FCM_PROJECT_ID` for push (off unless set).

## Deployment modes

1. **Field / APK (current):** static `dist/` (or the ZIP in `downloads/`), no server. Data stays on the device (localStorage). Works offline after first load.
2. **Control room:** Node backend + SQLite behind HTTPS reverse proxy, `HOST=127.0.0.1`, persistent `DB_PATH`. Migrate field data via `POST /api/migrate/*` (preview first, explicit `confirm:true`, auto-snapshot, users/audit never overwritten).

## Security notes

- No passwords or API keys in code. Service-account files stay on the server, never served.
- Login throttling, scrypt passwords, hashed sessions (8 h), role minimums per endpoint, audit on sensitive actions.
- Migration never overwrites users or audit history. Restore is atomic with integrity check.

See `docs/LIMITATIONS.md` before production use.
