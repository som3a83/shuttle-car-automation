import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server/app.js';

process.env.ADMIN_PASSWORD = 'TestPass12345';
let base, server, tok;
const call = async (p, o = {}, t = tok) => {
  const r = await fetch(base + p, { method: o.method || 'GET', headers: { 'Content-Type': 'application/json', ...(t ? { Authorization: 'Bearer ' + t } : {}) }, body: o.body ? JSON.stringify(o.body) : undefined });
  return { status: r.status, body: await r.json() };
};
const backup = () => ({
  vehicles: [
    { id: 'v1', number: 'SH-T9', maker: 'TestMakerZ', model: 'ISAT', location: 'A', status: 'working', batteryId: 'b1', hours: 3, lastUpdate: '2026-11-14T10:00:00.000Z', archived: false },
    { id: 'v9', number: 'SH-T9', maker: 'TestMakerZ', model: 'ISAT', location: 'A', status: 'ready', batteryId: null, hours: 0, lastUpdate: '2026-11-14T10:00:00.000Z' },
  ],
  batteries: [{ id: 'b1', code: 'BAT-T9', location: 'SH-T9', vehicleId: 'v1', charge: 82, health: 'good', state: 'mounted', lastCharge: '2026-11-14', lastSwap: '2026-11-14', lastBy: 'tech1' }],
  shifts: [{ id: 's1' }], users: [{ id: 'u1' }],
  faults: [{ id: 'f1', vehicleId: 'v1', type: 'battery', desc: 'low voltage observed', severity: 'high', status: 'open', technician: 'tech1', action: '', parts: '', startTime: '2026-11-14', endTime: '', testResult: '', approvedReturn: false, createdAt: '2026-11-14T09:00:00.000Z', createdBy: 'tech1' }],
  maints: [{ id: 'm1', vehicleId: 'v1', kind: 'inspection', dueDate: '2026-11-20', doneDate: '', status: 'scheduled', tech: 'tech1', notes: '' }],
  cycles: [{ batteryCode: 'BAT-T9', kind: 'charge', startPct: 20, endPct: 82, startedAt: '2026-11-14T08:00:00.000Z', endedAt: '2026-11-14T10:00:00.000Z', by: 'tech1' }],
  activity: [{ id: 'a1', user: 'tech1', action: 'test action', time: '2026-11-14T10:00:00.000Z', details: '' }],
  readings: [],
});

test('setup login', async () => {
  const app = createApp({ dbPath: ':memory:', simulation: false });
  await new Promise((res) => { server = app.listen(0, '127.0.0.1', res); });
  base = `http://127.0.0.1:${server.address().port}`;
  const r = await call('/api/login', { method: 'POST', body: { username: 'admin', password: 'TestPass12345' } }, null);
  assert.equal(r.status, 200); tok = r.body.token;
});

test('migrate preview reports plan without writing', async () => {
  const r = await call('/api/migrate/preview', { method: 'POST', body: { backup: backup() } });
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.makers_to_create, ['TestMakerZ']);
  assert.equal(r.body.vehicles_to_create, 1);
  assert.deepEqual(r.body.vehicle_dupes_skipped, ['SH-T9']);
  assert.equal(r.body.batteries_to_create, 1);
  assert.ok(r.body.incompatible.some((s) => s.startsWith('shifts:')));
  assert.ok(r.body.incompatible.some((s) => s.startsWith('users:')));
});

test('migrate apply needs explicit confirmation', async () => {
  const r = await call('/api/migrate/apply', { method: 'POST', body: { backup: backup() } });
  assert.equal(r.status, 400);
});

test('migrate apply inserts, snapshots, skips dupes, creates work order', async () => {
  const r = await call('/api/migrate/apply', { method: 'POST', body: { backup: backup(), confirm: true } });
  assert.equal(r.status, 200);
  assert.equal(r.body.inserted.vehicles, 1);
  assert.equal(r.body.inserted.batteries, 1);
  assert.equal(r.body.inserted.faults, 1);
  assert.equal(r.body.inserted.work_orders, 1);
  assert.equal(r.body.inserted.maintenance, 1);
  const v = await call('/api/vehicles');
  assert.ok(v.body.some((x) => x.code === 'SH-T9' && x.data_source === 'OFFLINE'));
  const r2 = await call('/api/migrate/apply', { method: 'POST', body: { backup: backup(), confirm: true } });
  assert.equal(r2.body.inserted.vehicles, 0);
  assert.deepEqual(r2.body.inserted && r2.status, 200);
});

test('notifications prefs + queue readable', async () => {
  const p = await call('/api/notifications/prefs', { method: 'PUT', body: { kinds: ['critical', 'high', 'info'] } });
  assert.equal(p.status, 200);
  const q = await call('/api/notifications');
  assert.equal(q.status, 200);
  assert.ok(Array.isArray(q.body));
});

test('notify status is honest without credentials', async () => {
  const r = await call('/api/notify/status');
  assert.equal(r.status, 200);
  assert.equal(r.body.fcm, 'not_configured');
  assert.equal(r.body.background, 'not_running');
});

test('proposals pipeline with approval gate', async () => {
  const c = await call('/api/proposals', { method: 'POST', body: { title: 'Add manufacturer', detail: 'Add vendor X with protocol docs' } });
  assert.equal(c.status, 200);
  assert.equal(c.body.status, 'pending');
  const ap = await call(`/api/proposals/${c.body.id}/applied`, { method: 'POST', body: { evidence: 'x' } });
  assert.equal(ap.status, 409);
  const d = await call(`/api/proposals/${c.body.id}/decision`, { method: 'POST', body: { decision: 'approved' } });
  assert.equal(d.status, 200);
  const a2 = await call(`/api/proposals/${c.body.id}/applied`, { method: 'POST', body: { evidence: 'checkpoint 12, tests green' } });
  assert.equal(a2.status, 200);
  assert.equal(a2.body.status, 'applied');
});

test('teardown', async () => { await new Promise((res) => server.close(res)); });
