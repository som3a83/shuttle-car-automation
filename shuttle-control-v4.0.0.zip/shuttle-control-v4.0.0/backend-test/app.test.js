import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server/app.js';
import { diagnose } from '../server/diagnostics.js';

process.env.ADMIN_PASSWORD = 'TestPass12345';
let base, server, tok;
const call = async (p, o = {}, t = tok) => {
  const r = await fetch(base + p, { method: o.method || 'GET', headers: { 'Content-Type': 'application/json', ...(t ? { Authorization: 'Bearer ' + t } : {}) }, body: o.body ? JSON.stringify(o.body) : undefined });
  return { s: r.status, j: await r.json().catch(() => ({})) };
};
const login = async (username, password) => (await call('/api/login', { method: 'POST', body: { username, password } }, null));

test.before(async () => {
  server = createApp({ dbPath: ':memory:', simulation: false });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + server.address().port;
  tok = (await login('admin', 'TestPass12345')).j.token;
});
test.after(() => { server.closeAllConnections(); server.close(); });

test('health is public; api requires auth', async () => {
  assert.equal((await call('/api/health', {}, null)).s, 200);
  assert.equal((await call('/api/vehicles', {}, null)).s, 401);
});
test('login rejects wrong password and works with right one', async () => {
  assert.equal((await login('admin', 'wrong-password')).s, 401);
  assert.ok(tok);
});
test('static files served, path traversal blocked', async () => {
  assert.equal((await fetch(base + '/')).status, 200);
  assert.equal((await fetch(base + '/..%2fpackage.json')).status, 404);
  assert.equal((await fetch(base + '/%2e%2e/package.json')).status, 404);
});
test('RBAC: viewer read-only, operator reports faults, technician cannot create vehicles', async () => {
  for (const role of ['viewer', 'operator', 'technician']) {
    assert.equal((await call('/api/users', { method: 'POST', body: { username: role + '1', password: 'LongPassword123', role } })).s, 200);
  }
  const v = (await login('viewer1', 'LongPassword123')).j.token;
  const o = (await login('operator1', 'LongPassword123')).j.token;
  const t = (await login('technician1', 'LongPassword123')).j.token;
  assert.equal((await call('/api/vehicles', {}, v)).s, 200);
  assert.equal((await call('/api/vehicles', { method: 'POST', body: { code: 'X' } }, t)).s, 403);
  assert.equal((await call('/api/users', {}, t)).s, 403);
  const veh = (await call('/api/vehicles', { method: 'POST', body: { code: 'SH-01', model: 'm' } })).j;
  assert.equal(veh.data_source, 'OFFLINE');
  assert.equal((await call('/api/faults', { method: 'POST', body: { vehicle_id: veh.id, type: 'electrical', severity: 'high', description: 'x' } }, v)).s, 403);
  const f = (await call('/api/faults', { method: 'POST', body: { vehicle_id: veh.id, type: 'electrical', severity: 'high', description: 'sensor' } }, o)).j;
  assert.equal(f.status, 'open');
  assert.equal((await call('/api/faults/' + f.id, { method: 'PATCH', body: { status: 'closed' } }, t)).s, 400, 'cannot close without resolution');
  const closed = await call('/api/faults/' + f.id, { method: 'PATCH', body: { status: 'closed', resolution: 'replaced sensor, tested OK', downtime_min: 30 } }, t);
  assert.equal(closed.j.status, 'closed');
});
test('validation: bad inputs rejected', async () => {
  assert.equal((await call('/api/vehicles', { method: 'POST', body: {} })).s, 400);
  assert.equal((await call('/api/users', { method: 'POST', body: { username: 'a', password: 'short', role: 'viewer' } })).s, 400);
  assert.equal((await call('/api/batteries', { method: 'POST', body: { code: 'B1', charge: 500 } })).s, 400);
  assert.equal((await call('/api/vehicles', { method: 'POST', body: { code: 'SH-01' } })).s, 409);
});
test('manual status change allowed only on OFFLINE source', async () => {
  const list = (await call('/api/vehicles')).j;
  const id = list.find((v) => v.code === 'SH-01').id;
  assert.equal((await call('/api/vehicles/' + id, { method: 'PATCH', body: { status: 'stopped' } })).j.status, 'stopped');
});
test('battery assignment keeps history', async () => {
  const id = (await call('/api/vehicles')).j.find((v) => v.code === 'SH-01').id;
  const b = (await call('/api/batteries', { method: 'POST', body: { code: 'B-01', charge: 20, health: 60 } })).j;
  assert.equal((await call('/api/batteries/' + b.id, { method: 'PATCH', body: { vehicle_id: id } })).s, 200);
  const h = (await call(`/api/batteries/${b.id}/history`)).j;
  assert.equal(h[0].event, 'installed');
});
test('simulation data is labeled SIMULATION, never REAL', async () => {
  assert.equal((await call('/api/simulation/seed', { method: 'POST', body: {} })).j.created, 3);
  await call('/api/simulation/tick', { method: 'POST', body: {} });
  const sims = (await call('/api/vehicles')).j.filter((v) => v.code.startsWith('SIM-'));
  assert.equal(sims.length, 3);
  assert.ok(sims.every((v) => v.data_source === 'SIMULATION'));
  const sig = (await call('/api/vehicles/' + sims[0].id + '/signals')).j;
  assert.ok(sig.signals.length === 4 && sig.signals.every((s) => s.source === 'SIMULATION'));
  const dash = (await call('/api/dashboard')).j;
  assert.ok(dash.bySource.SIMULATION === 3 && !dash.bySource.REAL);
});
test('diagnostics always require technician verification and never claim confirmation', async () => {
  const id = (await call('/api/vehicles')).j.find((v) => v.code === 'SH-01').id;
  const d = (await call(`/api/vehicles/${id}/diagnose`)).j;
  assert.ok(d.findings.length > 0);
  for (const f of d.findings) {
    assert.equal(f.verificationRequired, true);
    assert.match(f.status, /not a confirmed/);
    for (const k of ['fault', 'causes', 'severity', 'evidence', 'steps', 'action', 'confidence']) assert.ok(k in f, k);
  }
  assert.ok(d.findings.some((f) => f.code === 'BATTERY_LOW'));
  assert.ok(d.findings.some((f) => f.code === 'NO_LIVE_DATA'));
});
test('diagnose: comm loss and repeated faults', () => {
  const old = new Date(Date.now() - 600000).toISOString();
  const f = diagnose({ vehicle: { data_source: 'REAL', last_seen: old }, battery: null, faults: [1, 2, 3].map((i) => ({ id: i, type: 'sensor', severity: 'low', status: 'closed', description: 'd', created_at: new Date().toISOString() })) });
  assert.ok(f.some((x) => x.code === 'COMM_LOSS') && f.some((x) => x.code === 'REPEATED_FAULT'));
});
test('protocol adapters are honestly not implemented', async () => {
  const p = (await call('/api/protocols')).j;
  assert.ok(p.length >= 7 && p.every((x) => x.status === 'not_implemented' && x.readOnly));
});
test('audit log records actions; backup excludes password hashes', async () => {
  const a = (await call('/api/audit')).j;
  assert.ok(a.some((x) => x.action === 'login') && a.some((x) => x.action === 'forbidden') && a.some((x) => x.action === 'fault_create'));
  const b = JSON.stringify((await call('/api/backup')).j);
  assert.ok(!b.includes('pass_hash') && !b.includes('scrypt'));
});
test('self-demotion blocked; disabled user loses access', async () => {
  const users = (await call('/api/users')).j;
  const me = users.find((u) => u.username === 'admin');
  assert.equal((await call('/api/users/' + me.id, { method: 'PATCH', body: { role: 'viewer' } })).s, 409);
  const v = users.find((u) => u.username === 'viewer1');
  const vt = (await login('viewer1', 'LongPassword123')).j.token;
  await call('/api/users/' + v.id, { method: 'PATCH', body: { active: false } });
  assert.equal((await call('/api/vehicles', {}, vt)).s, 401);
});
test('login throttling after repeated failures', async () => {
  for (let i = 0; i < 5; i++) await login('technician1', 'bad-bad-bad-1');
  assert.equal((await login('technician1', 'LongPassword123')).s, 429);
});
