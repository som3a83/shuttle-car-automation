# API v4 addendum (all JSON, `Authorization: Bearer <token>`; errors `{ "error": "..." }`)

Min roles: V=viewer O=operator T=technician A=admin S=super_admin.

## Legacy migration (field-app backup → backend)
- `POST /api/migrate/preview` (S): body `{backup: <shuttle-fleet-v1 JSON>}` → plan: makers/vehicles/batteries to create, dupes skipped, faults/maintenance/cycles/activity counts, incompatible lists. Writes nothing.
- `POST /api/migrate/apply` (S): body `{backup, confirm: true, createWorkOrders?: true}` → auto snapshot → insert in FK order → integrity check → commit/rollback. Never overwrites users or audit history.

## Notifications
- `GET /api/notifications` (T): unread queue filtered by my prefs.
- `POST /api/notifications/read` (T): `{ids: [...]}`.
- `GET /api/notifications/history` (T).
- `GET|PUT /api/notifications/prefs` (T): `{kinds: [...]}`.
- `GET /api/notify/status` (V): `{fcm: not_configured|ready|misconfigured, background: not_running, ...}` — honest by design.
- `POST /api/notify/test` (S): `{token}` — 501 until FCM env is set.

## Change proposals (controlled dev pipeline)
- `GET /api/proposals` (A), `POST /api/proposals` (A) `{title, detail}` → pending.
- `POST /api/proposals/:id/decision` (S) `{decision: approved|rejected}`.
- `POST /api/proposals/:id/applied` (S) `{evidence}` — only after approved; execution happens in the dev workspace with checkpoints, never direct prod writes.
