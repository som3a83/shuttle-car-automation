# LIMITATIONS — v4.0.0 (honest status, 2026-11-15)

## Implemented and tested here
Auth/RBAC/audit, fleet, batteries (+assignment history, +cycles API and field-app cycle forms), faults (+closure rule + downtime), work orders, maintenance, rule-based diagnostics (hypothesis only, technician verification required), simulator (everything tagged SIMULATION), protocol registry, backup export, JSON restore (backend, atomic, users/audit never overwritten) + field-app restore with preview and auto-backup, legacy migration (preview/confirm/snapshot/duplicates), notifications queue + prefs, proposals pipeline, reports (summary + CSV + real XLSX + print), AR/EN backend + vanilla UI, dark/light field UI, offline-first field app.

## NOT implemented
- Real PLC/Modbus/OPC UA/MQTT/BLE communication; no signal history beyond the simulator ring; no control writes ever.
- Continuous background monitoring, FCM delivery (needs deployed always-on backend + gateway + service account).
- English field-app UI (Arabic-first); no migration of shifts/links/settings into backend tables (kept in the field app by design).
- AI development assistant as in-app automation (proposals pipeline + documented procedure instead; execution stays in the dev workspace).

## NOT executed
Load tests, real-phone Bluetooth/WebView field tests beyond capability detection, print-preview tests, anything hardware-dependent. Only the listed suites were run.

## Safety rules (enforced)
Read-only integration posture; no undocumented register/signal mapping; no PLC writes; E-stop and interlocks never bypassed; every diagnostic output is a hypothesis requiring verification.
