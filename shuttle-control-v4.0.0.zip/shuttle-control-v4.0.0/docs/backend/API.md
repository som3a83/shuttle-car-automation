# REST API (JSON, `Authorization: Bearer <token>`; errors `{ "error": "..." }`)
Min role: V=viewer O=operator T=technician A=admin S=super_admin

| Method & path | Role | Notes |
|---|---|---|
| GET /api/health | public | version |
| POST /api/login `{username,password}` | public | returns `{token,user}`; throttled |
| POST /api/logout · GET /api/me | V | |
| GET /api/dashboard | V | totals, byStatus, bySource, open faults, low batteries |
| GET/POST /api/vehicles · PATCH /api/vehicles/:id | V / A / A | manual status only for `OFFLINE` source |
| GET /api/vehicles/:id/signals | V | latest DI/DO/AI/AO with `source` |
| GET /api/vehicles/:id/diagnose | V | findings: fault, causes, severity, evidence, steps, action, confidence, verificationRequired |
| GET/POST /api/batteries · PATCH /api/batteries/:id · GET /api/batteries/:id/history | V / A / T / V | assignment writes history |
| GET/POST /api/faults · PATCH /api/faults/:id | V / O / T | closing requires `resolution` |
| GET/POST /api/maintenance · PATCH /api/maintenance/:id | V / T / T | PATCH marks done |
| GET/POST /api/manufacturers | V / S | `protocol`, `register_map` (object) supplied by admin from manufacturer docs |
| GET /api/protocols | V | adapter registry (all `not_implemented`) |
| GET/POST /api/users · PATCH /api/users/:id | S | password >= 10 chars |
| GET /api/audit · GET /api/backup | S | |
| POST /api/simulation/seed · POST /api/simulation/tick | A | SIMULATION rows only |

## Added in v3.1
| Method & path | Role | Notes |
|---|---|---|
| GET /api/batteries/analytics | V | per battery: recorded sessions, avg charge delta/minutes, installs, alerts (no health is estimated) |
| GET/POST /api/batteries/:id/cycles | V / T | `{kind: charge|discharge, start_pct, end_pct, started_at?, ended_at?, vehicle_id?}` source is always MANUAL |
| GET/POST /api/work-orders · PATCH /api/work-orders/:id | V / T / T | status open→in_progress→completed/cancelled; completing needs `actions`, `repair_min`, `downtime_min`; `parts:[{name,ref,qty}]`; completing closes the linked fault |
| GET /api/reports/summary · GET /api/reports/work-orders.csv | A | CSV neutralises spreadsheet formulas |
| POST /api/restore | S | body = a `/api/backup` file |
