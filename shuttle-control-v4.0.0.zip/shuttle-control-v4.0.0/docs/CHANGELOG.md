# CHANGELOG — v4.0.0 (2026-11-15)

Unified build: field PWA (React, v2.1.0 code base) + adopted Node backend (from v3.1.0, unchanged behavior, 19/19 tests still green) + new v4 work below. Nothing was blindly overwritten; legacy files were preserved (see `docs/backend-CHANGELOG-v3.md` for v3 history).

## Added and tested
1. **Legacy migration** (`POST /api/migrate/preview|apply`, super_admin): maps the field-app backup (`shuttle-fleet-v1` JSON) to backend tables — manufacturers, vehicles (OFFLINE source), batteries + assignment history, faults (+ auto work-order per open fault), maintenance, battery cycles (MANUAL), activity→audit, readings (MANUAL). Duplicate detection (incl. duplicates *inside* one file — bug found and fixed during testing), incompatible list (shifts/users/links/settings stay in the field app), explicit `confirm:true`, automatic pre-migrate snapshot, FK integrity check with rollback. Users and audit history are never overwritten. 8 new tests.
2. **Battery cycles in the field app**: charge/discharge session form (start/end %, actor), stored in `cycles[]`, included in backups, feeds the backend migrator.
3. **Restore with preview in the field app**: JSON restore shows current-vs-file counts, auto-downloads a pre-restore backup, needs explicit typed confirmation.
4. **Real XLSX export**: dynamic-import SheetJS (main bundle untouched), sheets for fleet/faults/shifts; CSV + print retained.
5. **Fault downtime**: recorded on close (`downtimeMin`) and shown; close still requires action + test result + approval.
6. **Notifications architecture**: queue/history/preferences tables + technician endpoints; FCM sender implemented server-side but **disabled** until `FCM_SERVICE_ACCOUNT_JSON` + `FCM_PROJECT_ID` are set; `/api/notify/status` honestly reports `not_configured`; background monitoring documented as not running until deployed always-on.
7. **Change proposals** (`/api/proposals*`, admin/super_admin): natural-language requests → pending → approved/rejected → applied-with-evidence. Execution happens in the dev workspace with checkpoints; never direct prod writes.
8. **Docs**: root README, API v4 addendum, migration guide, deploy guide, updated limitations, this changelog, test report.

## Fixed during validation
- Migration planner missed duplicates inside a single backup file (now caught; test covers it).
- Backend test isolation: tests now use a temp DB path so the workspace is never polluted.
- Backend static/VERSION paths made self-contained under `server/` (one-line change; all 19 adopted tests still pass).
- Field-app test script used a non-owner address; corrected to owner test domain.

## Honestly not done
- Real PLC/Modbus/OPC UA/MQTT/BLE communication (registry stays `not_implemented`; no register invented).
- Continuous background monitoring/FCM delivery (architecture ready, needs deployed backend + gateway + service account).
- English UI for the field app (Arabic-first per owner context; backend API + vanilla UI are bilingual).
- Wi-Fi/RF/vendor gateways (need manufacturer docs + hardware).
- Load tests, real-phone Safari tests, print-preview tests.
