# Test report — v4.0.0 (2026-11-15)

## Backend (`node --test backend-test/*.test.js`, temp DB)
**27/27 pass, 0 fail.** 19 adopted (app.test.js 14 + v31.test.js 5) + 8 new (v40.test.js):
auth, RBAC, validation, manual-status rule, battery history, SIMULATION labeling, diagnostics hypothesis rule, comm-loss/repeat findings, protocol registry honesty, audit, backup excludes hashes, self-demotion, throttling, cycles, swap history, work orders + fault linkage, reports/CSV, restore round-trip + tamper + non-super-admin, migrate preview/apply/duplicates/snapshot, notifications prefs, notify honesty, proposals gate.

## Backend live smoke (fresh server, throwaway DB)
Login, `/api/health` (version 4.0.0), `/api/notify/status` (`not_configured`, background `not_running`), migrate preview on empty backup, proposal create — all 200 OK. Server stopped, DB deleted after.

## Frontend (`pnpm verify`)
Build PASS, names PASS, page opens PASS (post-change run).

## Field-app UI checks (headless Chrome, phone 390x844, this release)
- Batteries → cycle form renders; empty submit fires validation alert (no silent write). Save path uses the same audited-update pattern as swap/charge.
- Reports → “real Excel” button triggers a download with no JS errors; the same SheetJS path was validated to emit a well-formed .xlsx (3 sheets from live data).
- Main sections (batteries/shifts/reports) open with data; cycle filter, shift flow, assistant intents re-verified this cycle.
- Restore preview + auto-backup + typed confirm implemented; destructive paths require explicit confirmation (not click-tested to protect data).

## Fixed in this cycle
Migration planner ignored duplicates inside one backup (now skipped + reported, tested). Backend paths made self-contained (all adopted tests still green). Test isolation to temp DB. Field test address corrected to owner domain.

## Not executed (see LIMITATIONS.md)
Load tests, real-phone BLE/WebView field tests beyond capability detection, print preview, Safari, hardware-dependent paths.
