# Migration guide — field app → backend

Source: the field app's backup JSON (`shuttle-fleet-v1`: vehicles, batteries, shifts, faults, maints, cycles, readings, activity, users, settings). Export it from the app: More → Management → Backup.

## Steps
1. `POST /api/migrate/preview` with `{backup}`. Review: to-create counts, dupes skipped, incompatible lists.
2. Fix source dupes if any (duplicate vehicle codes / battery codes inside the file are reported and skipped).
3. `POST /api/migrate/apply` with `{backup, confirm: true}` (add `createWorkOrders: false` to skip auto work orders for open faults).
4. The server stores a pre-migrate snapshot (table `snapshots`) automatically and audits the run.

## Mapping (compatible fields)
manufacturers by name (protocol `unverified`); vehicles by code (status mapped, archived → `offline`, source `OFFLINE`); batteries by code (+ assignment + history); faults by resolved vehicle (severity/status mapped, closed ones need their stored resolution); maintenance; battery cycles as MANUAL; activity → audit; readings as MANUAL.

## Never migrated
Users and audit history (use `/api/users`); shifts, device links, settings (no backend tables — stay in the field app); anything failing validation (reported, whole apply rolls back).
