# CHANGELOG

## v3.1.0 (2026-11-15) — built on v3.0.0; `legacy/` untouched; no existing function removed
### Done and tested
1. **Visual/layout check** (headless Chromium, Playwright): mobile 390x844 and tablet 820x1180 x Arabic RTL/English LTR x dark/light x all 12 screens. Automated checks: no horizontal overflow, correct `dir`/theme, no console/JS errors = 0 issues. Found and fixed by looking at screenshots: unreadable theme-toggle glyph, oversized battery chart on phones, one-column stat cards. Added print stylesheet. Script: `tools/visual-check.py`.
2. **Battery cycles**: record charge/discharge sessions (manual source), usage/installation history incl. "removed" entries when a battery is swapped between shuttles, analytics + alerts. No health/SoH is derived or invented.
3. **Work orders**: technician, fault type, priority, parts used, repair time, downtime, actions, status workflow; completing links back and closes the fault. UI tab + API.
4. **Reports (partial)**: summary per shuttle (faults, downtime, open orders), repeated faults, technician performance, battery analytics; print from the UI; work-order CSV export (formula-injection safe).
5. **Restore**: `POST /api/restore` from the backup JSON — validated against the schema, whitelisted tables/columns, integrity check, atomic with rollback; users/audit never overwritten. Tested with a real round-trip, tampered payloads and a non-super-admin.
### Tests
`npm test`: **19/19 pass** (14 from v3.0.0 unchanged + 5 new files-of-tests for cycles, swap history, work orders, reports/CSV, backup/restore). Visual check: 0 issues. Re-run from a clean unzip before packaging.
### NOT done (honest status)
- 6. **Legacy data migration tool** — not built. The legacy data lives in the browser's localStorage (`shuttle-fleet-v1`); I have only seen its structure through the minified bundle, not a real export file, so a migrator would be guesswork.
- 7. **AI development assistant** (dev environment, checkpoints, approval, rollback) — not built.
- 8. **Notifications / background monitoring / FCM** — not built.
- 9. **PLC/protocol modules** — unchanged from v3.0.0 (registry of read-only adapters, all `not_implemented`). No real connection has been made or claimed.
- Gaps inside finished items: no UI forms for recording battery cycles or uploading a restore file (API only); reports have no date filters and no PDF/XLSX (print + CSV only); the diagnostics engine is still rule-based.
- Not tested: real phones/Safari, print preview, load, anything hardware-dependent.
### Needed from the real world
- FCM: a Firebase project, service-account key, app registration + device tokens, an always-on HTTPS backend. 
- PLC: official protocol/register documentation per model, a gateway or PLC on the network, a test unit, and written safety sign-off before any write command is ever considered.
