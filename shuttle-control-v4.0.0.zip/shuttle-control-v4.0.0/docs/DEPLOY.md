# Deploy guide

## Field app / APK (current field mode)
- Build: `pnpm install && pnpm build` → serve `dist/` statically (any static host) or wrap in an HTML-to-APK tool with `index.html` as entry, `logo.png` as icon.
- No server, no database to deploy. Data lives on the device (localStorage), offline after first load.
- WebView note: Web Bluetooth is unavailable inside Android WebView — direct BLE reading works only in Chrome for Android. Everything else works in the wrapper.

## Backend (control room)
- Requires Node.js ≥ 22.13. No `npm install` needed (zero dependencies).
- `cd server && ADMIN_PASSWORD='<strong>' npm start` → http://127.0.0.1:8080
- Env: `PORT`, `HOST` (keep 127.0.0.1), `DB_PATH` (persistent path), `SIMULATION=0` to stop the ticker, `FCM_SERVICE_ACCOUNT_JSON` + `FCM_PROJECT_ID` for push.
- Run behind an HTTPS reverse proxy (nginx/Caddy); never expose plain HTTP on a network. Run under systemd/PM2.
- Backup: stop server, copy `data/shuttle.db` (+ `-wal`/`-shm`); or `GET /api/backup` (super_admin). Restore: `POST /api/restore` (atomic, users/audit preserved).
- Migrate field data: see `docs/MIGRATION.md`.
