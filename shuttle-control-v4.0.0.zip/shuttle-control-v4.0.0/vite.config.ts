import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig, type Plugin } from 'vite';

// Link previews read og:title and og:description (X falls back to them), so
// they are copied from the <title> and description in index.html. A tag the
// page sets itself is kept.
function shareTags(): Plugin {
  return {
    name: 'share-tags',
    transformIndexHtml(html: string) {
      const values: Record<string, string | undefined> = {
        'og:title': /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1],
        'og:description': /<meta\s+name=["']description["']\s+content=(["'])([\s\S]*?)\1/i.exec(html)?.[2],
      };
      let tags = '';
      for (const [property, value] of Object.entries(values)) {
        if (!value?.trim() || new RegExp(`["']${property}["']`).test(html)) continue;
        tags += `    <meta property="${property}" content="${value.trim().replace(/"/g, '&quot;')}" />\n`;
      }
      return tags ? html.replace(/[ \t]*<\/head>/i, `${tags}  </head>`) : html;
    },
  };
}

export default defineConfig({
  // Relative asset paths so the built files also run from file:// and inside
  // offline APK wrappers, not only from a hosted domain root.
  base: './',
  plugins: [react(), tailwindcss(), shareTags()],
  resolve: {
    // `@/lib/utils` is `src/lib/utils` (tsconfig.json carries the same path).
    alias: { '@': '/src' },
    // Keep one React instance when dependencies add peers.
    dedupe: ['react', 'react-dom'],
  },
  optimizeDeps: {
    // Bundled at start, so the first page that imports them does not make Vite
    // bundle again and reload, which briefly ran two Reacts ("dispatcher.useContext").
    include: [
      'react', 'react-dom', 'react-dom/client', 'react/jsx-runtime', 'react/jsx-dev-runtime',
      'lucide-react', 'motion/react', 'radix-ui', 'clsx', 'tailwind-merge',
      'class-variance-authority', 'embla-carousel-react', 'sonner',
    ],
  },
  build: {
    // Reporting compressed sizes slows builds without changing their output.
    reportCompressedSize: false,
  },
  server: {
    // The platform supplies the proxied host and exact port.
    allowedHosts: true,
    strictPort: true,
    // Update these paths if the entry files change.
    warmup: {
      clientFiles: ['./src/main.tsx', './src/App.tsx'],
    },
    // Folders whose names start with a dot hold the platform's saved versions
    // and working files, not the site: watching them reloaded the page.
    watch: {
      ignored: ['**/.*/**'],
    },
  },
});
